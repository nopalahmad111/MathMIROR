//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BA-oqNMM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/cermin",
			"/panduan",
			"/belajar/$lessonId",
			"/jalur/$jalurId",
			"/latihan/$jalurId"
		],
		preloads: [
			"/assets/index-D1HaMkzs.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/utils-4Q6DS6if.js",
			"/assets/preload-helper-BK14Wbhh.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D1HaMkzs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B7nfl8bD.js",
			"/assets/arrow-right-UusSuUsH.js",
			"/assets/button-aTDg0muz.js",
			"/assets/content-DE9R9Qhs.js",
			"/assets/progress-uygNVnRW.js",
			"/assets/use-hydrated-BDmC1QpF.js",
			"/assets/progress-CP71CUCD.js"
		]
	},
	"/cermin": {
		filePath: "/workspace/src/routes/cermin.tsx",
		children: void 0,
		preloads: [
			"/assets/cermin-BYiIe35R.js",
			"/assets/content-DE9R9Qhs.js",
			"/assets/progress-uygNVnRW.js",
			"/assets/use-hydrated-BDmC1QpF.js"
		]
	},
	"/panduan": {
		filePath: "/workspace/src/routes/panduan.tsx",
		children: void 0,
		preloads: ["/assets/panduan-B6pVHwZx.js", "/assets/content-DE9R9Qhs.js"]
	},
	"/belajar/$lessonId": {
		filePath: "/workspace/src/routes/belajar.$lessonId.tsx",
		children: void 0,
		preloads: [
			"/assets/belajar._lessonId-BojjsBcy.js",
			"/assets/arrow-right-UusSuUsH.js",
			"/assets/practice-quiz-D1Z5Vuh2.js",
			"/assets/button-aTDg0muz.js",
			"/assets/content-DE9R9Qhs.js",
			"/assets/progress-uygNVnRW.js"
		]
	},
	"/jalur/$jalurId": {
		filePath: "/workspace/src/routes/jalur.$jalurId.tsx",
		children: void 0,
		preloads: [
			"/assets/jalur._jalurId-DBbM3vG6.js",
			"/assets/arrow-right-UusSuUsH.js",
			"/assets/check-6Jy3goJ0.js",
			"/assets/button-aTDg0muz.js",
			"/assets/content-DE9R9Qhs.js",
			"/assets/progress-uygNVnRW.js",
			"/assets/progress-CP71CUCD.js"
		]
	},
	"/latihan/$jalurId": {
		filePath: "/workspace/src/routes/latihan.$jalurId.tsx",
		children: void 0,
		preloads: [
			"/assets/latihan._jalurId-B4V-Qp0k.js",
			"/assets/practice-quiz-D1Z5Vuh2.js",
			"/assets/button-aTDg0muz.js",
			"/assets/content-DE9R9Qhs.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
