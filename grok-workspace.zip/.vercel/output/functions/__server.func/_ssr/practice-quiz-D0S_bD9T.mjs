import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Lightbulb, c as Check, s as ChevronRight } from "../_libs/lucide-react.mjs";
import { o as cn } from "./router-BpXJR4av.mjs";
import { t as Button } from "./button-CSTjc5OR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice-quiz-D0S_bD9T.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-border bg-bg-elevated px-3 text-base text-fg shadow-none transition-colors placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:opacity-50", className),
		...props
	});
}
function gcd(a, b) {
	a = Math.abs(Math.trunc(a));
	b = Math.abs(Math.trunc(b));
	while (b !== 0) {
		const t = b;
		b = a % b;
		a = t;
	}
	return a;
}
function lcm(a, b) {
	if (a === 0 || b === 0) return 0;
	return Math.abs(a * b) / gcd(a, b);
}
function isPrime(n) {
	const x = Math.trunc(n);
	if (x < 2) return false;
	if (x % 2 === 0) return x === 2;
	for (let i = 3; i * i <= x; i += 2) if (x % i === 0) return false;
	return true;
}
function factorsOf(n) {
	n = Math.abs(Math.trunc(n));
	if (n === 0) return [];
	const small = [];
	const large = [];
	for (let i = 1; i * i <= n; i++) if (n % i === 0) {
		small.push(i);
		if (i * i !== n) large.push(n / i);
	}
	return small.concat(large.reverse());
}
function primeFactors(n) {
	n = Math.abs(Math.trunc(n));
	const out = [];
	for (let p = 2; p * p <= n; p++) while (n % p === 0) {
		out.push(p);
		n /= p;
	}
	if (n > 1) out.push(n);
	return out;
}
function simplifyFrac(n, d) {
	if (d === 0) return {
		n,
		d
	};
	const g = gcd(n, d);
	let nn = n / g;
	let dd = d / g;
	if (dd < 0) {
		nn = -nn;
		dd = -dd;
	}
	return {
		n: nn,
		d: dd
	};
}
function roundToPlace(n, place) {
	if (place <= 0) return n;
	return Math.round(n / place) * place;
}
function digitsOf(n, width = 6) {
	return Math.abs(Math.trunc(n)).toString().padStart(width, "0").slice(-width).split("").map(Number);
}
function fromDigits(digits) {
	return digits.reduce((acc, d) => acc * 10 + d, 0);
}
var ONES = [
	"",
	"satu",
	"dua",
	"tiga",
	"empat",
	"lima",
	"enam",
	"tujuh",
	"delapan",
	"sembilan"
];
function threeToWords(n) {
	if (n <= 0) return "";
	const r = Math.floor(n / 100);
	const t = n % 100;
	const parts = [];
	if (r === 1) parts.push("seratus");
	else if (r > 1) parts.push(`${ONES[r]} ratus`);
	if (t === 0) return parts.join(" ");
	if (t === 10) parts.push("sepuluh");
	else if (t === 11) parts.push("sebelas");
	else if (t < 10) parts.push(ONES[t] ?? "");
	else if (t < 20) parts.push(`${ONES[t - 10]} belas`);
	else {
		const pul = Math.floor(t / 10);
		const sat = t % 10;
		parts.push(`${ONES[pul]} puluh${sat ? ` ${ONES[sat]}` : ""}`);
	}
	return parts.join(" ");
}
function numberToWordsId(n) {
	if (n === 0) return "nol";
	if (n < 0) return `negatif ${numberToWordsId(-n)}`;
	if (n >= 1e6) return formatId(n);
	const ribu = Math.floor(n / 1e3);
	const sisa = n % 1e3;
	const parts = [];
	if (ribu === 1) parts.push("seribu");
	else if (ribu > 0) parts.push(`${threeToWords(ribu)} ribu`);
	if (sisa > 0) parts.push(threeToWords(sisa));
	return parts.join(" ");
}
function formatId(n) {
	return (n < 0 ? "-" : "") + Math.trunc(Math.abs(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
function parseIdNumber(raw) {
	const t = raw.trim().replace(/\s/g, "").replace(/\./g, "").replace(/_/g, "");
	if (!/^-?\d+$/.test(t)) return null;
	const n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function parseFrac(raw) {
	const t = raw.trim().replace(/\s+/g, " ");
	const mixed = t.match(/^(-?\d+)\s+(\d+)\s*\/\s*(\d+)$/);
	if (mixed) {
		const w = Number(mixed[1]);
		const n = Number(mixed[2]);
		const d = Number(mixed[3]);
		if (!d || !Number.isFinite(w + n + d)) return null;
		return {
			n: (w < 0 ? -1 : 1) * (Math.abs(w) * d + n),
			d
		};
	}
	const f = t.match(/^(-?\d+)\s*\/\s*(-?\d+)$/);
	if (f) {
		const n = Number(f[1]);
		const d = Number(f[2]);
		if (!d || !Number.isFinite(n + d)) return null;
		return {
			n,
			d
		};
	}
	const whole = parseIdNumber(t);
	if (whole !== null) return {
		n: whole,
		d: 1
	};
	return null;
}
function fracEqual(a, b) {
	return a.n * b.d === b.n * a.d;
}
function formatFrac(n, d, mixed = false) {
	const s = simplifyFrac(n, d);
	if (s.d === 1) return String(s.n);
	if (mixed && Math.abs(s.n) > s.d) {
		const w = Math.trunc(s.n / s.d);
		const r = Math.abs(s.n % s.d);
		if (r === 0) return String(w);
		return `${w} ${r}/${s.d}`;
	}
	return `${s.n}/${s.d}`;
}
function placeLabels(width = 6) {
	return [
		{
			key: "ratusan-ribu",
			short: "Ratus rb",
			long: "Ratusan ribu",
			value: 1e5
		},
		{
			key: "puluhan-ribu",
			short: "Puluh rb",
			long: "Puluhan ribu",
			value: 1e4
		},
		{
			key: "ribuan",
			short: "Ribu",
			long: "Ribuan",
			value: 1e3
		},
		{
			key: "ratusan",
			short: "Ratus",
			long: "Ratusan",
			value: 100
		},
		{
			key: "puluhan",
			short: "Puluh",
			long: "Puluhan",
			value: 10
		},
		{
			key: "satuan",
			short: "Satuan",
			long: "Satuan",
			value: 1
		}
	].slice(6 - width);
}
function expandedForm(n) {
	const parts = [];
	const digits = digitsOf(n, 6);
	const labels = placeLabels(6);
	digits.forEach((d, i) => {
		if (d === 0) return;
		parts.push(formatId(d * labels[i].value));
	});
	return parts.length ? parts.join(" + ") : "0";
}
function euclidSteps(a, b) {
	let x = Math.abs(Math.trunc(a));
	let y = Math.abs(Math.trunc(b));
	const steps = [];
	while (y !== 0) {
		const q = Math.floor(x / y);
		const r = x % y;
		steps.push({
			a: x,
			b: y,
			q,
			r
		});
		x = y;
		y = r;
	}
	return steps;
}
function normalizeText(s) {
	return s.trim().toLowerCase().replace(/\s+/g, " ").replace(/[.]/g, "").replace(/[–—]/g, "-");
}
function answersMatch(expected, given, equivalentOk = false) {
	const e = expected.trim();
	const g = given.trim();
	if (!g) return false;
	if (normalizeText(e) === normalizeText(g)) return true;
	const ne = parseIdNumber(e);
	const ng = parseIdNumber(g);
	if (ne !== null && ng !== null && !e.includes("/") && !g.includes("/")) return ne === ng;
	const fe = parseFrac(e);
	const fg = parseFrac(g);
	if (fe && fg) {
		if (equivalentOk) return fracEqual(fe, fg);
		const se = simplifyFrac(fe.n, fe.d);
		return fg.n === se.n && fg.d === se.d;
	}
	return false;
}
function PracticeQuiz({ items, onDone }) {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [correctCount, setCorrectCount] = (0, import_react.useState)(0);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	const [ok, setOk] = (0, import_react.useState)(null);
	const [hintOn, setHintOn] = (0, import_react.useState)(false);
	const [tried, setTried] = (0, import_react.useState)(false);
	const item = items[index];
	if (!item) return null;
	const last = index === items.length - 1;
	const submit = (value) => {
		const match = answersMatch(item.answer, value, item.equivalentOk);
		setOk(match);
		setRevealed(true);
		if (match && !tried) setCorrectCount((c) => c + 1);
		setTried(true);
	};
	const goNext = () => {
		if (last) {
			onDone(correctCount, items.length);
			return;
		}
		setIndex((i) => i + 1);
		setSelected(null);
		setTyped("");
		setRevealed(false);
		setOk(null);
		setHintOn(false);
		setTried(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs font-medium uppercase tracking-wide text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Soal ",
					index + 1,
					" / ",
					items.length
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums",
					children: ["Tepat ", correctCount]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-snug",
				children: item.prompt
			}),
			item.kind === "mc" && item.options ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: item.options.map((opt) => {
					const show = revealed && selected === opt;
					const isAns = revealed && answersMatch(item.answer, opt, item.equivalentOk);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: revealed && ok === true,
						onClick: () => {
							setSelected(opt);
							if (!revealed) submit(opt);
							else if (!ok) submit(opt);
						},
						className: cn("min-h-12 rounded-lg border px-4 py-3 text-left text-sm leading-snug transition-colors", isAns ? "border-primary bg-success-soft" : show && !ok ? "border-danger bg-danger-soft" : "border-border bg-bg-elevated hover:bg-surface"),
						children: opt
					}, opt);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-2 sm:flex-row",
				onSubmit: (e) => {
					e.preventDefault();
					submit(typed);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: typed,
					onChange: (e) => setTyped(e.target.value),
					placeholder: item.placeholder ?? "Jawaban",
					disabled: revealed && ok === true,
					autoComplete: "off"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "secondary",
					disabled: !typed.trim() || revealed && ok === true,
					children: "Periksa"
				})]
			}),
			hintOn && !revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-border bg-warn-soft px-3 py-2 text-sm text-warn",
				children: item.hint
			}) : null,
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-lg border px-4 py-3 text-sm leading-normal", ok ? "border-primary/30 bg-success-soft" : "border-danger/30 bg-danger-soft"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 font-medium",
					children: ok ? "Tepat." : `Belum. Jawaban: ${item.answer}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-fg/90",
					children: item.why
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					!revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setHintOn(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }), "Petunjuk"]
					}) : null,
					revealed && !ok && item.kind === "input" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => {
							setRevealed(false);
							setOk(null);
						},
						children: "Coba lagi"
					}) : null,
					revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: goNext,
						children: last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Selesai", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Lanjut", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })] })
					}) : null
				]
			})
		]
	});
}
//#endregion
export { roundToPlace as _, expandedForm as a, formatId as c, isPrime as d, lcm as f, primeFactors as g, placeLabels as h, euclidSteps as i, fromDigits as l, parseIdNumber as m, PracticeQuiz as n, factorsOf as o, numberToWordsId as p, digitsOf as r, formatFrac as s, Input as t, gcd as u, simplifyFrac as v };
