//#region node_modules/.nitro/vite/services/ssr/assets/content-pItgeMuQ.js
var BILANGAN_LESSONS = [
	{
		id: "bilangan-1",
		jalurId: "bilangan",
		order: 1,
		title: "Wajah sebuah bilangan",
		intent: "Setiap digit punya 'rumah'. Nol bukan kosong tanpa arti — ia menjaga rumah itu tetap ada.",
		mindful: {
			notice: "Lihat bilangan 305.042. Jangan hitung dulu. Apa yang pertama kali kamu perhatikan?",
			prompt: "Tuliskan atau pilih satu hal kecil yang kamu lihat.",
			chips: [
				"Ada angka nol di tengah",
				"Angkanya panjang, enam digit",
				"Bagian kiri lebih 'berat' dari kanan",
				"Aku belum yakin cara membacanya"
			]
		},
		story: {
			title: "Halaman perpustakaan",
			body: [
				"Bu Aisyah, pustakawati madrasah, sedang menghitung seluruh halaman buku di rak kelas 5. Hasilnya: 305.042 halaman.",
				"Hana membaca, \"Tiga puluh lima ribu empat puluh dua.\" Rafi menyahut, \"Tiga ratus lima ribu empat puluh dua.\"",
				"Keduanya melihat angka yang sama. Yang berbeda adalah cara mereka menempatkan setiap digit di rumahnya."
			],
			ask: "Menurutmu, siapa yang lebih dekat ke pembacaan yang benar — dan mengapa nol di angka itu tidak boleh dihilangkan?"
		},
		explore: {
			lab: "place-value",
			mode: "build",
			start: 305042,
			caption: "Susun 305.042 di papan nilai tempat. Ubah satu digit, lalu perhatikan: mana yang berubah banyak, mana yang hampir tidak terasa?"
		},
		practice: [
			{
				id: "b1-1",
				prompt: "Bagaimana cara membaca 305.042 yang tepat?",
				kind: "mc",
				options: [
					"Tiga puluh lima ribu empat puluh dua",
					"Tiga ratus lima ribu empat puluh dua",
					"Tiga ratus lima puluh ribu empat puluh dua",
					"Tiga juta lima ribu empat puluh dua"
				],
				answer: "Tiga ratus lima ribu empat puluh dua",
				hint: "Mulai dari kiri. Digit pertama duduk di rumah ratusan ribu.",
				why: "3 ada di ratusan ribu, 0 di puluhan ribu, 5 di ribuan, lalu 042. Jadi seratus-an ribu: tiga ratus lima ribu empat puluh dua."
			},
			{
				id: "b1-2",
				prompt: "Pada 482.716, berapa nilai tempat angka 8?",
				kind: "mc",
				options: [
					"8",
					"80",
					"8.000",
					"80.000"
				],
				answer: "80.000",
				hint: "Hitung rumah dari kanan: satuan, puluhan, ratusan, ribuan, puluhan ribu, ratusan ribu.",
				why: "Angka 8 berada di puluhan ribu, jadi nilainya 8 × 10.000 = 80.000. Bukan sekadar 'delapan'."
			},
			{
				id: "b1-3",
				prompt: "Tulis bentuk standar dari: 6 ratusan ribu + 0 puluhan ribu + 4 ribuan + 9 ratusan + 0 puluhan + 2 satuan.",
				kind: "input",
				answer: "604902",
				placeholder: "Contoh: 604.902",
				hint: "Rumah yang kosong tetap ditulis nol, supaya rumah di sebelahnya tidak bergeser.",
				why: "Tanpa nol, 6492 akan terbaca sebagai ribuan — wajah bilangannya berubah total. Nol adalah penjaga tempat."
			},
			{
				id: "b1-4",
				prompt: "Nilai tempat angka 5 pada 250.083 adalah 50.000. Benar atau tidak?",
				kind: "mc",
				options: [
					"Benar",
					"Tidak, nilainya 5.000",
					"Tidak, nilainya 500"
				],
				answer: "Tidak, nilainya 5.000",
				hint: "Pisahkan: 250.083 → 2 | 5 | 0 | 0 | 8 | 3.",
				why: "5 duduk di ribuan (bukan puluhan ribu). Puluhan ribu-nya justru 0. Jadi 5 × 1.000 = 5.000."
			}
		],
		reflect: {
			prompts: ["Kalau nol di 305.042 dihapus, jadi 35.42 atau 3542 — apa yang sebenarnya hilang?", "Bagaimana kamu akan menjelaskan 'nilai tempat' ke adik kelas 2 dengan satu kalimat?"],
			takeaway: "Digit itu huruf pada wajah bilangan. Rumahnya (nilai tempat) yang memberi makna."
		}
	},
	{
		id: "bilangan-2",
		jalurId: "bilangan",
		order: 2,
		title: "Mana yang lebih besar?",
		intent: "Membandingkan bukan melihat 'yang kelihatan banyak digit', melainkan berjalan dari kiri, rumah demi rumah.",
		mindful: {
			notice: "99.999 dan 100.000. Secara perasaan, mana yang 'jauh lebih besar'? Selisihnya sebenarnya berapa?",
			prompt: "Apa yang kamu sadari tentang dua bilangan yang hampir sama wajahnya?",
			chips: [
				"Selisihnya cuma 1, meski kelihatan beda jauh",
				"Yang satu 5 digit, yang satu 6 digit",
				"Rumah paling kiri yang menentukan",
				"Aku sering tertipu oleh digit pertama yang kelihatan"
			]
		},
		story: {
			title: "Beras zakat dua kelas",
			body: [
				"Kelas 5A mengumpulkan 12.450 kg beras zakat. Kelas 5B 12.405 kg. Panitia ingin mengumumkan kelas mana yang mengumpulkan lebih banyak.",
				"Seorang siswa bilang, \"Sama saja, dua-duanya dua belas ribu.\" Siswa lain menunjuk angka paling belakang, \"5B lebih besar karena 5 > 0.\"",
				"Hana mengusulkan: bandingkan dari rumah yang paling kiri, baru jalan ke kanan sampai ketemu yang berbeda."
			],
			ask: "Di rumah mana 12.450 dan 12.405 baru berbeda — dan kelas mana yang lebih banyak?"
		},
		explore: {
			lab: "place-value",
			mode: "compare",
			start: 12450,
			other: 12405,
			caption: "Bandingkan dua bilangan. Warna akan menandai rumah pertama yang berbeda, dihitung dari kiri. Coba ganti angkanya."
		},
		practice: [
			{
				id: "b2-1",
				prompt: "Manakah yang paling besar?",
				kind: "mc",
				options: [
					"98.765",
					"99.076",
					"99.067",
					"98.976"
				],
				answer: "99.076",
				hint: "Semua masih puluhan ribu. Bandingkan ratusan ribu dulu (sama: 0), lalu puluhan ribu, lalu ribuan.",
				why: "99.076 dan 99.067 sama sampai ratusan. Di puluhan: 7 > 6, jadi 99.076 yang terbesar."
			},
			{
				id: "b2-2",
				prompt: "Urutkan dari terkecil: 45.230 ; 44.980 ; 45.203",
				kind: "mc",
				options: [
					"44.980 ; 45.203 ; 45.230",
					"44.980 ; 45.230 ; 45.203",
					"45.203 ; 44.980 ; 45.230",
					"45.230 ; 45.203 ; 44.980"
				],
				answer: "44.980 ; 45.203 ; 45.230",
				hint: "Yang puluhan ribunya 4 lebih kecil dari yang 5. Lalu bandingkan ratusan: 203 vs 230.",
				why: "44.980 kalah di puluhan ribu. 45.203 dan 45.230 sama sampai ratusan: 2 = 2, lalu puluhan 0 < 3."
			},
			{
				id: "b2-3",
				prompt: "Selisih 100.000 − 99.999 adalah…",
				kind: "input",
				answer: "1",
				placeholder: "Bilangan",
				hint: "Bayangkan garis bilangan. Satu langkah dari 99.999 ke mana?",
				why: "Wajahnya berubah dramatis (5 digit menjadi 6 digit), tapi nilainya hanya bertambah 1. Wajah ≠ jarak."
			},
			{
				id: "b2-4",
				prompt: "Benarkah 8.076 > 8.706 karena 8.076 punya angka 8 di depan?",
				kind: "mc",
				options: [
					"Benar, digit depan menentukan",
					"Tidak, 8.706 lebih besar",
					"Sama besar"
				],
				answer: "Tidak, 8.706 lebih besar",
				hint: "Keduanya ribuan. Rumah ratusan: 0 vs 7.",
				why: "Digit '8' di depan sama. Yang membedakan adalah ratusan: 0 < 7, jadi 8.076 < 8.706."
			}
		],
		reflect: {
			prompts: ["Kapan dua bilangan yang 'kelihatan mirip' sebenarnya berjauhan, dan kapan yang 'kelihatan beda' ternyata dekat?", "Mengapa kita membandingkan dari kiri, bukan dari kanan seperti saat menjumlah?"],
			takeaway: "Membandingkan = berjalan dari rumah terbesar. Menjumlah = berjalan dari rumah terkecil. Arahnya sadar, bukan kebiasaan buta."
		}
	},
	{
		id: "bilangan-3",
		jalurId: "bilangan",
		order: 3,
		title: "Menyimpan dan meminjam, bukan sulap",
		intent: "Teknik menyimpan dan meminjam adalah menukar nama: sepuluh satuan = satu puluhan. Bukan angka yang hilang.",
		mindful: {
			notice: "Saat kamu 'menyimpan 1', apa yang sebenarnya kamu simpan? Angka 1, atau sepuluh yang sudah diganti nama?",
			prompt: "Pilih yang paling dekat dengan pemahamanmu sekarang.",
			chips: [
				"Menyimpan 1 artinya membawa 10 ke rumah sebelah",
				"Meminjam artinya merename 1 puluhan menjadi 10 satuan",
				"Aku hafal caranya, tapi belum yakin artinya",
				"Tanpa nilai tempat, menyimpan/meminjam jadi hafalan"
			]
		},
		story: {
			title: "Kas infak Jumat",
			body: [
				"Minggu ini kotak infak masjid madrasah berisi Rp 47.682. Minggu lalu sisa Rp 28.759. Pak Imam ingin tahu jumlahnya jika digabung, dan berapa yang terpakai jika diambil Rp 19.075 untuk beras dhuafa.",
				"Hana menjumlah dari satuan dan menulis '11' di kolom satuan. Rafi bilang, \"Tidak boleh, satu rumah hanya 0–9.\"",
				"Bu Guru tersenyum: \"11 satuan itu 1 puluhan dan 1 satuan. Kamu tidak membuang 10 — kamu pindahkan ke rumah puluhan.\""
			],
			ask: "Jika 7 + 9 pada rumah puluhan menghasilkan 16, apa yang ditulis di puluhan, dan apa yang pindah ke ratusan?"
		},
		explore: {
			lab: "place-value",
			mode: "operate",
			start: 47682,
			other: 28759,
			op: "+",
			caption: "Jumlahkan kolom dari kanan. Jika hasil ≥ 10, ikat 10 menjadi 1 di rumah berikutnya. Kurangi dengan tombol operasi."
		},
		practice: [
			{
				id: "b3-1",
				prompt: "47.682 + 28.759 =",
				kind: "input",
				answer: "76441",
				placeholder: "Hasil",
				hint: "Satuan: 2+9=11 → tulis 1, simpan 1 puluhan. Lanjutkan rumah demi rumah.",
				why: "2+9=11, 8+5+1=14, 6+7+1=14, 7+8+1=16, 4+2+1=7. Jadi 76.441. Setiap 'simpan 1' adalah 10 yang berganti rumah."
			},
			{
				id: "b3-2",
				prompt: "Saat menghitung 5.030 − 1.784, pada rumah puluhan kita perlu meminjam. Setelah meminjam, puluhan menjadi…",
				kind: "mc",
				options: [
					"0",
					"10",
					"12",
					"13"
				],
				answer: "12",
				hint: "Satuan sudah meminjam 1 dari puluhan (3 menjadi 2). Puluhan 2 masih kurang dari 8, jadi pinjam dari ratusan — yang juga 0, maka dari ribuan. Puluhan menerima 10: 2+10=12.",
				why: "Rantai pinjam: ribuan 5→4, ratusan 0→10→9, puluhan 2→12. Setelah merename, 12 puluhan dikurangi 8. Bukan 13, karena satuan sudah mengambil 1 puluhan lebih dulu."
			},
			{
				id: "b3-3",
				prompt: "120.405 − 78.256 =",
				kind: "input",
				answer: "42149",
				placeholder: "Hasil",
				hint: "Jika rumah 0, pinjam terus ke kiri sampai ketemu yang tidak nol, lalu 'turunkan' ke kanan sebagai 10.",
				why: "120.405 − 78.256 = 42.149. Meminjam berantai dari ratusan ribu sampai satuan adalah merename, bukan menghapus nilai."
			},
			{
				id: "b3-4",
				prompt: "Mengapa 999 + 1 = 1.000, bukan 9910?",
				kind: "mc",
				options: [
					"Karena 9+1=10, semua rumah penuh lalu jadi 1.000",
					"Karena kita selalu menambah 0 di belakang",
					"Karena 999 dibulatkan"
				],
				answer: "Karena 9+1=10, semua rumah penuh lalu jadi 1.000",
				hint: "Bayangkan abakus: setiap tiang yang penuh (10) dikosongkan dan menambah 1 di tiang kiri.",
				why: "Satuan 9+1=10 → 0 satuan + 1 puluhan. Puluhan 9+1=10 → 0 puluhan + 1 ratusan. Ratusan 9+1=10 → 0 ratusan + 1 ribuan. Wajah baru: 1.000."
			}
		],
		reflect: {
			prompts: ["Dengan kalimatmu sendiri: apa bedanya 'menyimpan 1' dengan 'menulis 1 di rumah sebelah tanpa alasan'?", "Kapan kamu akan menjumlah dengan taksiran, dan kapan harus persis?"],
			takeaway: "Algoritma penjumlahan/pengurangan adalah cerita tentang menukar 10. Kalau kamu paham tukarannya, kamu tidak perlu takut angka besar."
		}
	},
	{
		id: "bilangan-4",
		jalurId: "bilangan",
		order: 4,
		title: "Kelompok dan bagi rata",
		intent: "Perkalian adalah menjumlah kelompok sama. Pembagian adalah mencari berapa kelompok, atau berapa isi tiap kelompok.",
		mindful: {
			notice: "12 × 4 bisa dibayangkan 12 kelompok berisi 4, atau 4 kelompok berisi 12. Jumlahnya sama. Apa yang berubah?",
			prompt: "Apa yang tetap dan apa yang berubah ketika kamu membalik 12 × 4 menjadi 4 × 12?",
			chips: [
				"Jumlah total tetap, susunan berubah",
				"Ceritanya berubah (siapa kelompoknya)",
				"Aku biasanya hanya menghafal hasilnya",
				"Pembagian adalah pertanyaan terbalik dari perkalian"
			]
		},
		story: {
			title: "Paket kurma Ramadan",
			body: [
				"Panitia Ramadan menyiapkan 1.248 kurma. Akan dikemas 8 kurma per kantong untuk takjil. Hana bertanya, \"Berapa kantong yang terbentuk?\"",
				"Rafi melihat 1.248 sebagai 1.200 + 48. \"1.200 ÷ 8 = 150, 48 ÷ 8 = 6, jadi 156 kantong.\" Ia memecah yang sulit menjadi yang mudah.",
				"Bu Guru menambahkan: kalau yang diketahui 156 kantong dan tiap kantong 8, kita kembali ke perkalian. Dua arah, satu makna."
			],
			ask: "1.248 ÷ 8 mencari apa: banyaknya kantong, atau banyaknya kurma per kantong? Mengapa pecah 1.200 + 48 membantu?"
		},
		explore: {
			lab: "factor",
			mode: "rectangles",
			start: 24,
			caption: "Susun 24 titik menjadi persegi panjang. Tiap susunan (baris × kolom) adalah cara lain mengatakan perkalian. Coba angka lain."
		},
		practice: [
			{
				id: "b4-1",
				prompt: "1.248 ÷ 8 =",
				kind: "input",
				answer: "156",
				placeholder: "Hasil",
				hint: "Pecah: 1.200 ÷ 8 dan 48 ÷ 8, lalu jumlahkan.",
				why: "1.248 = 1.200 + 48. 1.200 ÷ 8 = 150, 48 ÷ 8 = 6. Jadi 156 kantong. Memecah adalah strategi bermakna, bukan trik."
			},
			{
				id: "b4-2",
				prompt: "Sebuah aula menampung 36 baris, tiap baris 28 siswa. Berapa siswa?",
				kind: "input",
				answer: "1008",
				placeholder: "Jumlah siswa",
				hint: "36 × 28 = 36 × 20 + 36 × 8, atau 36 × 30 − 36 × 2.",
				why: "36 × 30 = 1.080, kurang 36 × 2 = 72, hasil 1.008. Atau 30×28=840 plus 6×28=168. Beberapa jalan, satu jumlah."
			},
			{
				id: "b4-3",
				prompt: "120 ÷ 5 bisa berarti…",
				kind: "mc",
				options: [
					"Hanya: 120 dibagi jadi 5 kelompok, isi tiap kelompok dicari",
					"Hanya: tiap kelompok isi 5, berapa banyak kelompok",
					"Keduanya mungkin, tergantung ceritanya"
				],
				answer: "Keduanya mungkin, tergantung ceritanya",
				hint: "Pembagian punya dua wajah: partisi (bagi rata ke n kelompok) dan kuotisi (kelompok berukuran n).",
				why: "120 kue untuk 5 anak → tiap anak 24 (partisi). 120 kue, tiap kotak 5 → 24 kotak (kuotisi). Hasil sama, makna cerita berbeda. Itu pembelajaran berkesadaran."
			},
			{
				id: "b4-4",
				prompt: "Manakah yang sama nilainya dengan 15 × 12?",
				kind: "mc",
				options: [
					"15 × 10 + 15 × 2",
					"15 × 10 + 2",
					"12 × 10 + 15",
					"15 + 12 × 10"
				],
				answer: "15 × 10 + 15 × 2",
				hint: "Sifat distributif: a × (b+c) = a×b + a×c.",
				why: "12 = 10 + 2, jadi 15 × 12 = 150 + 30 = 180. Menghafal 15×12 tanpa melihat pecahan 10+2 membuatmu rapuh saat angkanya 15 × 12.000."
			}
		],
		reflect: {
			prompts: ["Ceritakan satu pembagian di rumah atau madrasah: itu partisi atau kuotisi?", "Mengapa memecah 36 × 28 lebih 'dalam' daripada hanya menekan kalkulator?"],
			takeaway: "Kali dan bagi adalah dua arah pintu yang sama. Yang dalam adalah bisa memilih pecahan yang memudahkan, bukan hanya hasil."
		}
	},
	{
		id: "bilangan-5",
		jalurId: "bilangan",
		order: 5,
		title: "Membulat karena ada tujuan",
		intent: "Pembulatan adalah pilihan sadar: mendekati supaya mudah dipikir, bukan mengganti kebenaran angka.",
		mindful: {
			notice: "Harga buku Rp 48.750. Kalau kamu menaksir, kamu akan bilang 49.000 atau 50.000? Tergantung untuk apa.",
			prompt: "Pembulatan itu 'benar' atau 'berguna'?",
			chips: [
				"Berguna, asalkan aku tahu angkanya dibulatkan",
				"Tergantung tujuan: belanja, laporan, atau hitung persis",
				"Aku sering menghafal aturan 5 ke atas tanpa tahu untuk apa",
				"Angka di tengah (5) adalah pilihan kesepakatan, bukan hukum alam"
			]
		},
		story: {
			title: "Koperasi sekolah",
			body: [
				"Hana membawa Rp 50.000 ke koperasi. Ia ingin beli 3 alat tulis @ Rp 12.350 dan 2 buku @ Rp 18.700.",
				"Antrian panjang. Ia tidak sempat hitung persis. \"Tiga kali kira-kira 12.000 = 36.000, dua kali kira-kira 19.000 = 38.000. Wah, 74.000, uangku kurang.\"",
				"Rafi menaksir berbeda: 12.000 dan 18.000. Hasilnya 72.000 — masih terasa kurang. Di kasir, total sebenarnya Rp 74.450.",
				"Taksiran Hana menyelamatkannya dari malu di kasir. Taksiran bukan malas — ia sadar kapan cukup dekat."
			],
			ask: "Mengapa taksiran ke atas lebih aman saat berbelanja? Kapan taksiran ke bawah justru lebih cocok?"
		},
		explore: {
			lab: "round",
			start: 48750,
			caption: "Geser satuan pembulatan. Perhatikan garis: titik tengah memutuskan. Coba angka yang tepat di tengah, lalu yang hampir di tengah."
		},
		practice: [
			{
				id: "b5-1",
				prompt: "48.750 dibulatkan ke puluhan ribu terdekat menjadi…",
				kind: "mc",
				options: [
					"40.000",
					"50.000",
					"49.000",
					"48.000"
				],
				answer: "50.000",
				hint: "Puluhan ribu terdekat: lihat 8.750 dibanding 5.000 (titik tengah antara 40.000 dan 50.000).",
				why: "48.750 lebih dekat ke 50.000 daripada ke 40.000 (jarak 1.250 vs 8.750). Aturan '5 ke atas' sejalan di sini, tapi yang dalam adalah jarak di garis."
			},
			{
				id: "b5-2",
				prompt: "352.480 dibulatkan ke ratusan ribu terdekat =",
				kind: "input",
				answer: "400000",
				placeholder: "Hasil",
				hint: "Ratusan ribu: 300.000 atau 400.000. Tengok digit puluhan ribu dan sisanya: 52.480 vs 50.000.",
				why: "Titik tengah 350.000. 352.480 sedikit di atas tengah, jadi 400.000. Selisihnya 47.520 ke 400.000 vs 52.480 ke 300.000."
			},
			{
				id: "b5-3",
				prompt: "Untuk memastikan uang cukup di kasir, taksiran yang bijak adalah…",
				kind: "mc",
				options: [
					"Selalu bulatkan ke bawah agar terlihat hemat",
					"Bulatkan harga ke atas, lalu jumlahkan",
					"Abaikan satuan dan puluhan tanpa pikir"
				],
				answer: "Bulatkan harga ke atas, lalu jumlahkan",
				hint: "Tujuan menentukan arah. Belanja: jangan sampai kurang. Perkiraan luas kebun: boleh ke terdekat.",
				why: "Pembulatan tidak netral. Ia alat. Mindful learning: pilih aturan sesuai konteks, jangan jalankan aturan secara membabi buta."
			},
			{
				id: "b5-4",
				prompt: "67.500 ke ribuan terdekat menurut kesepakatan '5 ke atas' menjadi…",
				kind: "input",
				answer: "68000",
				placeholder: "Hasil",
				hint: "Ribuan: lihat ratusan. 500 tepat di tengah. Kesepakatan sekolah biasanya naik.",
				why: "67.500 tepat di tengah 67.000 dan 68.000. Tidak ada yang 'lebih dekat'. Kita sepakat naik ke 68.000 agar semua orang menulis hasil yang sama."
			}
		],
		reflect: {
			prompts: ["Berilah contoh di luar soal: kapan kamu sengaja membulatkan, dan untuk tujuan apa?", "Apa bahayanya kalau seseorang menyajikan angka bulat seolah-olah itu angka asli?"],
			takeaway: "Membulat adalah keputusan. Yang dalam: tahu jarak, tahu tujuan, tahu bahwa 5 di tengah adalah kesepakatan."
		}
	}
];
var FPB_LESSONS = [
	{
		id: "fpb-1",
		jalurId: "fpb-kpk",
		order: 1,
		title: "Faktor adalah cara menyusun",
		intent: "Faktor bukan daftar hafalan. Ia cara menyusun benda menjadi persegi panjang yang rapi, tanpa sisa.",
		mindful: {
			notice: "24 siswa akan baris untuk upacara. Barisan 'rapi' artinya tiap baris sama banyak, tidak ada yang menyendiri. Ada berapa cara?",
			prompt: "Sebelum menghitung, kira-kira berapa banyak cara menyusun 24?",
			chips: [
				"Lebih dari dua cara",
				"Hanya 1 baris atau 2 baris",
				"Tiap cara adalah pasangan kali yang hasilnya 24",
				"Aku belum terbiasa menggambarnya"
			]
		},
		story: {
			title: "Barisan upacara",
			body: [
				"Pak Ustadz meminta kelas 5 berbaris rapi: 24 siswa, semua baris sama panjang, tidak ada sisa.",
				"Hana mencoba 5 sebaris. Sisa 4 orang. \"Tidak pas.\" Rafi mencoba 6 sebaris: 4 baris, pas. Kemudian 8 sebaris: 3 baris, juga pas.",
				"Bu Guru: \"Setiap susunan yang pas adalah faktor. 1, 2, 3, 4, 6, 8, 12, 24 — itu semua cara 24 mau disusun.\""
			],
			ask: "Mengapa 5 bukan faktor 24, padahal 5 'kelihatan rapi'? Apa arti 'sisa' di sini?"
		},
		explore: {
			lab: "factor",
			mode: "rectangles",
			start: 24,
			caption: "Ubah jumlah titik. Coba semua lebar. Yang bisa jadi persegi panjang tanpa lubang — itulah faktor. Perhatikan pasangan (3×8 dan 8×3): sama atau beda?"
		},
		practice: [
			{
				id: "f1-1",
				prompt: "Faktor dari 24 adalah…",
				kind: "mc",
				options: [
					"1, 2, 3, 4, 6, 8, 12, 24",
					"2, 4, 6, 8, 12",
					"1, 24, 48",
					"4, 6, 8, 10, 12"
				],
				answer: "1, 2, 3, 4, 6, 8, 12, 24",
				hint: "Cari semua bilangan yang membagi 24 tegak lurus, tanpa sisa. Jangan lupa 1 dan 24.",
				why: "1×24, 2×12, 3×8, 4×6. Empat pasangan, delapan faktor. 5, 7, 9, 10 menyisakan sisa — bukan faktor."
			},
			{
				id: "f1-2",
				prompt: "Kelipatan 6 yang ada di antara 1 dan 40, ada berapa buah?",
				kind: "input",
				answer: "6",
				placeholder: "Banyaknya",
				hint: "Kelipatan 6: 6, 12, 18, … sampai yang masih ≤ 40. Jangan hitung 0.",
				why: "6, 12, 18, 24, 30, 36. (42 sudah > 40). Ada 6 bilangan. Kelipatan = loncatan sama panjang di garis."
			},
			{
				id: "f1-3",
				prompt: "Manakah pernyataan yang benar?",
				kind: "mc",
				options: [
					"Setiap faktor 18 juga faktor 36",
					"Setiap kelipatan 18 juga kelipatan 36",
					"18 bukan kelipatan 6"
				],
				answer: "Setiap faktor 18 juga faktor 36",
				hint: "Faktor 'masuk ke dalam'. Kelipatan 'meloncat ke luar'. Arahnya berlawanan.",
				why: "Faktor 18: 1,2,3,6,9,18 — semuanya membagi 36. Tapi kelipatan 18 (18,36,54,…) tidak semuanya kelipatan 36 (18 bukan)."
			},
			{
				id: "f1-4",
				prompt: "36 siswa. Banyak cara berbaris rapi (baris sama panjang, termasuk 1 baris dan 36 baris) adalah…",
				kind: "input",
				answer: "9",
				placeholder: "Banyak cara",
				hint: "Hitung banyak faktor 36.",
				why: "Faktor 36: 1,2,3,4,6,9,12,18,36 — sembilan cara. Setiap faktor = satu lebar barisan."
			}
		],
		reflect: {
			prompts: ["Apa beda faktor dan kelipatan kalau dijelaskan dengan barisan siswa, bukan dengan rumus?", "Mengapa 1 dan bilangan itu sendiri selalu faktor?"],
			takeaway: "Faktor = cara menyusun tanpa sisa. Kelipatan = loncatan berulang. Dua arah pandang pada hubungan 'habis dibagi'."
		}
	},
	{
		id: "fpb-2",
		jalurId: "fpb-kpk",
		order: 2,
		title: "Prima: yang tidak bisa jadi kotak",
		intent: "Bilangan prima hanya punya dua faktor. Artinya, ia hanya bisa disusun sebagai satu garis — bukan kotak yang lebih gemuk.",
		mindful: {
			notice: "Coba susun 7 kue menjadi persegi panjang selain 1×7. Ada yang berhasil?",
			prompt: "Apa perasaanmu ketika sebuah angka 'menolak' disusun?",
			chips: [
				"Itu justru ciri khususnya",
				"Aku mengira semua angka bisa disusun banyak cara",
				"Prima bukan 'aneh', hanya hemat faktor",
				"1 bukan prima — ia terlalu istimewa dengan hanya satu faktor"
			]
		},
		story: {
			title: "Kue tujuh loyang",
			body: [
				"Ibu guru membawa 7 kue untuk ditata di loyang persegi panjang, lebih dari satu baris, rata.",
				"Hana mencoba 2 baris: sisa 1. Tiga baris: sisa 1. Empat, lima, enam: tidak ada yang pas.",
				"\"Tujuh hanya mau jadi satu baris.\" Bu Guru menyebutnya prima: hanya 1 dan dirinya yang menjadi faktor.",
				"Rafi bertanya, \"Kalau 1?\" — \"Satu hanya punya satu faktor, yaitu 1. Ia tidak prima dan tidak majemuk. Ia pintu awal.\""
			],
			ask: "Mengapa 9 bukan prima, padahal ganjil? Mengapa 2 prima, padahal genap?"
		},
		explore: {
			lab: "factor",
			mode: "prime",
			start: 7,
			caption: "Uji beberapa angka. Yang hanya punya susunan 1 × n adalah prima. Bandingkan 9, 11, 12, 15, 17. Jangan hafal dulu — lihat susunannya."
		},
		practice: [
			{
				id: "f2-1",
				prompt: "Manakah himpunan yang semuanya prima?",
				kind: "mc",
				options: [
					"2, 3, 5, 7, 11",
					"1, 3, 5, 7, 9",
					"2, 4, 5, 7, 11",
					"3, 9, 11, 13, 15"
				],
				answer: "2, 3, 5, 7, 11",
				hint: "Buang yang punya faktor lain. 1 bukan prima. 9 = 3×3. 4 = 2×2. 15 = 3×5.",
				why: "Prima: tepat dua faktor. 2 adalah satu-satunya prima genap, karena semua genap lain punya faktor 2."
			},
			{
				id: "f2-2",
				prompt: "Faktorisasi prima 36 adalah…",
				kind: "mc",
				options: [
					"2 × 2 × 3 × 3",
					"4 × 9",
					"6 × 6",
					"2 × 18"
				],
				answer: "2 × 2 × 3 × 3",
				hint: "Pecah terus sampai semua faktornya prima. 4 dan 9 masih majemuk.",
				why: "36 = 6×6 = (2×3)×(2×3) = 2² × 3². Faktorisasi prima adalah 'bahan baku' — tidak bisa dipecah lagi."
			},
			{
				id: "f2-3",
				prompt: "Berapa banyak bilangan prima di antara 10 dan 20 (tidak termasuk 10 dan 20)?",
				kind: "input",
				answer: "4",
				placeholder: "Banyaknya",
				hint: "Cek 11, 12, 13, 14, 15, 16, 17, 18, 19.",
				why: "11, 13, 17, 19. Empat buah. 15 kelihatan 'ganjil dan kesepian' tapi 3×5."
			},
			{
				id: "f2-4",
				prompt: "Pernyataan yang benar tentang 1:",
				kind: "mc",
				options: [
					"1 prima karena hanya dibagi 1",
					"1 bukan prima dan bukan majemuk",
					"1 majemuk karena sangat kecil"
				],
				answer: "1 bukan prima dan bukan majemuk",
				hint: "Prima butuh tepat dua faktor berbeda. Majemuk butuh lebih dari dua.",
				why: "1 hanya punya satu faktor. Definisi ini kesepakatan agar teorema unik faktorisasi prima berlaku rapi — setiap bilangan > 1 punya satu 'resep' prima."
			}
		],
		reflect: {
			prompts: ["Kalau prima adalah 'bahan baku', apa analoginya di dapur atau di bangunan?", "Mengapa menghafal daftar prima sampai 20 saja tidak cukup untuk paham?"],
			takeaway: "Prima = tidak bisa disusun jadi kotak selain garis. Faktorisasi prima = resep bahan baku sebuah bilangan."
		}
	},
	{
		id: "fpb-3",
		jalurId: "fpb-kpk",
		order: 3,
		title: "FPB: berbagi paling adil dan paling besar",
		intent: "FPB adalah ukuran kelompok terbesar yang bisa membagi dua kumpulan tanpa sisa. Bukan sekadar 'cari faktor lalu ambil yang besar'.",
		mindful: {
			notice: "18 kurma dan 24 biskuit, dibagikan ke kelompok sama banyak, tidak ada sisa, kelompok sebanyak-banyaknya. Yang dicari: ukuran kelompok, atau banyak kelompok?",
			prompt: "Dalam cerita berbagi, FPB menjawab pertanyaan yang mana?",
			chips: [
				"Banyaknya kelompok terbesar",
				"Isi tiap kantong jika kantongnya harus sama",
				"Aku sering tertukar dengan KPK",
				"FPB adalah irisan faktor, yang terbesar"
			]
		},
		story: {
			title: "Bekal dua nampan",
			body: [
				"Ibu menyiapkan 18 kurma dan 24 biskuit untuk pengajian. Setiap anak mendapat kurma sama banyak dan biskuit sama banyak. Tidak boleh sisa. Ibu ingin sebanyak mungkin anak yang kebagian.",
				"Kalau 2 anak: mudah, tapi banyak sisa kesempatan. Kalau 9 anak: kurma pas (2 masing-masing), biskuit? 24 tidak habis dibagi 9.",
				"Hana menulis faktor 18 dan 24, lalu mencari yang muncul di keduanya, lalu yang terbesar: 6. Enam anak, tiap anak 3 kurma dan 4 biskuit."
			],
			ask: "Mengapa 3 (juga faktor persekutuan) tidak dipilih? Apa arti 'terbesar' bagi Ibu?"
		},
		explore: {
			lab: "gcd-lcm",
			mode: "gcd",
			a: 18,
			b: 24,
			caption: "Lihat faktor yang beririsan, lalu langkah Euclid: sisa bagi. Sisa terakhir yang bukan nol — itulah FPB. Ganti angkanya."
		},
		practice: [
			{
				id: "f3-1",
				prompt: "FPB 18 dan 24 adalah…",
				kind: "input",
				answer: "6",
				placeholder: "FPB",
				hint: "Faktor 18: 1,2,3,6,9,18. Faktor 24: 1,2,3,4,6,8,12,24. Irisan terbesar?",
				why: "Irisan: 1,2,3,6. Terbesar 6. Euclid: 24=1×18+6, 18=3×6+0, jadi 6. Dua jalan, satu makna: ukuran berbagi terbesar."
			},
			{
				id: "f3-2",
				prompt: "Pita 36 cm dan 60 cm dipotong jadi potongan sama panjang, sepanjang mungkin, tanpa sisa. Panjang tiap potong?",
				kind: "input",
				answer: "12",
				placeholder: "cm",
				hint: "Ini berbagi panjang. Yang dicari FPB, bukan KPK.",
				why: "FPB(36,60)=12. Tiap potong 12 cm: 3 potong dari pita pertama, 5 dari kedua. Kalau 6 cm juga habis, tapi tidak 'sepanjang mungkin'."
			},
			{
				id: "f3-3",
				prompt: "FPB 7 dan 15 adalah 1. Apa artinya?",
				kind: "mc",
				options: [
					"Dua bilangan itu tidak bisa dibagi apa pun",
					"Mereka tidak punya faktor persekutuan selain 1 (relatif prima)",
					"Salah satu dari mereka prima, jadi FPB selalu 1"
				],
				answer: "Mereka tidak punya faktor persekutuan selain 1 (relatif prima)",
				hint: "7 prima, 15 = 3×5. Tidak ada bahan baku yang sama.",
				why: "Relatif prima = resep primanya tidak berbagi. 8 dan 9 juga FPB 1, padahal keduanya bukan prima. Jadi bukan 'karena ada yang prima'."
			},
			{
				id: "f3-4",
				prompt: "FPB 48 dan 36 =",
				kind: "input",
				answer: "12",
				placeholder: "FPB",
				hint: "36 ke 48: 48=1×36+12, 36=3×12+0.",
				why: "Euclid cepat: sisa 12, lalu 36 habis dibagi 12. Faktorisasi: 48=2⁴×3, 36=2²×3², irisan 2²×3=12."
			}
		],
		reflect: {
			prompts: ["Buat cerita berbagimu sendiri yang jawabannya FPB — jangan meniru kurma dan biskuit.", "Mengapa 'terbesar' penting? Apa yang terjadi jika kita memakai faktor persekutuan yang lebih kecil?"],
			takeaway: "FPB = cara berbagi dua kumpulan ke kelompok sebanyak-banyaknya, rata, tanpa sisa."
		}
	},
	{
		id: "fpb-4",
		jalurId: "fpb-kpk",
		order: 4,
		title: "KPK: kapan dua loncatan bertemu",
		intent: "KPK adalah pertemuan pertama dua kelipatan. Di kehidupan: dua jadwal, dua pola, dua putaran.",
		mindful: {
			notice: "Hana mengaji tiap 4 hari, Rafi tiap 6 hari, mulai hari yang sama. Kapan mereka ketemu lagi di masjid yang sama?",
			prompt: "Bayangkan dua orang meloncat di garis. Apa yang kamu cari?",
			chips: [
				"Titik pertama yang diinjak berdua",
				"Bukan FPB, karena ini soal waktu bertemu",
				"Kelipatan 4: 4,8,12,16,20,24… Kelipatan 6: 6,12,18,24…",
				"Aku sering menghitung FPB padahal ceritanya 'ketemu'"
			]
		},
		story: {
			title: "Jadwal mengaji",
			body: [
				"Sabtu ini Hana dan Rafi mengaji bersama. Hana datang lagi setiap 4 hari. Rafi setiap 6 hari.",
				"Hana: hari ke-4, 8, 12, 16, 20, 24. Rafi: hari ke-6, 12, 18, 24.",
				"Titik yang sama: 12, 24, 36, … yang terkecil 12. Hari ke-12 mereka ketemu lagi.",
				"Bu Guru: \"Itu KPK. Bukan karena rumus 'kali lalu bagi FPB', tapi karena itu loncatan yang beririsan.\""
			],
			ask: "Kalau Hana setiap 4 hari dan Rafi setiap 8 hari, apakah ketemu lebih cepat atau lebih lambat dari 4 dan 6? Mengapa?"
		},
		explore: {
			lab: "gcd-lcm",
			mode: "lcm",
			a: 4,
			b: 6,
			caption: "Dua baris loncatan. Titik yang menyala di kedua baris adalah kelipatan persekutuan. Yang paling kiri (selain 0) adalah KPK. Ganti langkahnya."
		},
		practice: [
			{
				id: "f4-1",
				prompt: "KPK 4 dan 6 =",
				kind: "input",
				answer: "12",
				placeholder: "KPK",
				hint: "Kelipatan 4: 4,8,12,16,20,24. Kelipatan 6: 6,12,18,24. Terkecil yang sama?",
				why: "12. Rumus KPK = a×b / FPB juga jalan: 4×6 / 2 = 12. Rumus itu ringkasan dari irisan kelipatan, bukan pengganti makna."
			},
			{
				id: "f4-2",
				prompt: "Lampu A berkedip tiap 8 detik, lampu B tiap 12 detik, mulai bersama. Mereka berkedip bersama lagi setelah … detik.",
				kind: "input",
				answer: "24",
				placeholder: "detik",
				hint: "Pertemuan dua pola waktu = KPK.",
				why: "KPK(8,12)=24. FPB-nya 4, itu ukuran 'yang bisa membagi keduanya', bukan saat mereka ketemu."
			},
			{
				id: "f4-3",
				prompt: "KPK 7 dan 5 = 35. Ini karena…",
				kind: "mc",
				options: [
					"Semua dua prima dikalikan saja",
					"Mereka relatif prima, jadi KPK = hasil kali",
					"KPK selalu lebih besar dari kedua bilangan"
				],
				answer: "Mereka relatif prima, jadi KPK = hasil kali",
				hint: "FPB(7,5)=1, maka KPK=7×5/1=35. Tidak semua KPK = hasil kali (KPK 6 dan 8 = 24, bukan 48).",
				why: "Hanya jika FPB=1, KPK=hasil kali. KPK 6 dan 9 = 18, bukan 54. Menghafal 'kali saja' adalah pembelajaran tanpa kesadaran."
			},
			{
				id: "f4-4",
				prompt: "KPK 9 dan 12 =",
				kind: "input",
				answer: "36",
				placeholder: "KPK",
				hint: "Kelipatan 9: 9,18,27,36. Kelipatan 12: 12,24,36.",
				why: "36. 9=3², 12=2²×3, KPK ambil pangkat tertinggi tiap prima: 2²×3²=36."
			}
		],
		reflect: {
			prompts: ["Selain jadwal, di mana lagi dua pola berulang bertemu? (contoh: packing, bunyi, keliling lapangan)", "Mengapa 0 bukan jawaban KPK, padahal 0 kelipatan semua bilangan?"],
			takeaway: "KPK = pertemuan pertama dua loncatan. Di soal cerita, biasanya 'kapan bersama lagi' atau 'kapan cukup untuk keduanya'."
		}
	},
	{
		id: "fpb-5",
		jalurId: "fpb-kpk",
		order: 5,
		title: "Memilih: ini FPB atau KPK?",
		intent: "Yang sulit bukan menghitung — melainkan membaca cerita: sedang berbagi, atau sedang menunggu pertemuan?",
		mindful: {
			notice: "Dua soal bisa memakai angka 12 dan 18, tapi satu menjawab 6 dan satu menjawab 36. Angkanya sama, pertanyaannya yang beda.",
			prompt: "Kata kunci apa yang akan kamu cari dalam soal cerita?",
			chips: [
				"Berbagi, potong, kelompok terbesar → FPB",
				"Bersamaan, bertemu, cukup untuk keduanya → KPK",
				"Aku tidak boleh langsung hitung sebelum paham pertanyaan",
				"Kadang aku tertipu karena angkanya familiar"
			]
		},
		story: {
			title: "Dua soal, satu pasangan angka",
			body: [
				"Soal A: 12 pensil dan 18 penghapus dibagikan ke kotak-kotak sama, rata, sebanyak mungkin. Isi tiap jenis per kotak boleh beda, tapi banyak kotaknya sama.",
				"Soal B: Bus A tiap 12 menit, bus B tiap 18 menit, berangkat bersama pukul 07.00. Kapan berangkat bersama lagi?",
				"Angkanya 12 dan 18. Jawaban A: 6 kotak (FPB). Jawaban B: 36 menit (KPK), pukul 07.36.",
				"Hana belajar menandai pertanyaan sebelum menyentuh pensil hitung. Itu berkesadaran."
			],
			ask: "Buat tanda 'berbagi' atau 'bertemu' pada soal di sekitarmu. Apa yang terjadi jika kamu tertukar?"
		},
		explore: {
			lab: "gcd-lcm",
			mode: "choose",
			a: 12,
			b: 18,
			story: "Dua cerita, angka sama. Pilih dulu: ini berbagi (FPB) atau pertemuan (KPK)? Baru hitung. Salah pilih, hitung seakurat apa pun tetap salah makna.",
			caption: "Pilih mode FPB atau KPK, amati hasilnya, lalu cocokkan ke cerita. Ganti angka dan rasakan kapan hasilnya 'masuk akal'."
		},
		practice: [
			{
				id: "f5-1",
				prompt: "Ubin 16 cm × 20 cm akan menutup kotak tanpa dipotong, memakai ubin persegi sebesar mungkin. Sisi ubin persegi?",
				kind: "mc",
				options: [
					"FPB = 4 cm",
					"KPK = 80 cm",
					"FPB = 2 cm",
					"KPK = 16 cm"
				],
				answer: "FPB = 4 cm",
				hint: "Ubin persegi harus membagi kedua sisi. Sebesar mungkin → FPB.",
				why: "Sisi persegi harus faktor dari 16 dan 20. Terbesar 4. KPK 80 justru lebih panjang dari kedua sisi — tidak muat sebagai 'satu ubin'."
			},
			{
				id: "f5-2",
				prompt: "Lari keliling lapangan: Hana 8 menit per putaran, Rafi 12 menit. Mereka start bersama. Bertemu lagi di garis start setelah … menit.",
				kind: "input",
				answer: "24",
				placeholder: "menit",
				hint: "Pertemuan dua putaran = KPK.",
				why: "KPK(8,12)=24. Dalam 24 menit Hana 3 putaran, Rafi 2 putaran, kembali bersama. FPB=4 tidak menjawab 'kapan'."
			},
			{
				id: "f5-3",
				prompt: "36 kue cokelat dan 24 kue keju, dikemas identik, rata, sisa 0, paket sebanyak mungkin. Banyak paket?",
				kind: "input",
				answer: "12",
				placeholder: "paket",
				hint: "Banyak paket = FPB. Isi tiap paket: 3 cokelat dan 2 keju.",
				why: "FPB(36,24)=12 paket. Kalau 6 paket juga rata, tapi bukan sebanyak mungkin — Ibu masih bisa memekarkan ke 12."
			},
			{
				id: "f5-4",
				prompt: "Pernyataan paling bijak:",
				kind: "mc",
				options: [
					"Soal yang angkanya besar pasti KPK",
					"Baca dulu: berbagi atau bertemu, baru pilih alat",
					"FPB selalu lebih kecil jadi lebih mudah, kerjakan itu dulu"
				],
				answer: "Baca dulu: berbagi atau bertemu, baru pilih alat",
				hint: "Alat mengikuti pertanyaan, bukan sebaliknya.",
				why: "Deep learning: pilih representasi sesuai tujuan. Menghitung FPB dengan sempurna pada soal KPK adalah paham prosedur, bukan paham masalah."
			}
		],
		reflect: {
			prompts: ["Tulis satu soal cerita FPB dan satu KPK yang kamu buat sendiri, memakai angka 8 dan 12.", "Apa tanda di tubuh atau pikiranmu saat kamu hampir tertukar — dan bagaimana kamu menahannya?"],
			takeaway: "Hitung adalah langkah kedua. Langkah pertama: sadar apakah ceritanya berbagi atau bertemu."
		}
	}
];
var PECAHAN_LESSONS = [
	{
		id: "pecahan-1",
		jalurId: "pecahan",
		order: 1,
		title: "Pecahan adalah hubungan, bukan dua angka tumpuk",
		intent: "Pembilang menghitung bagian yang diambil. Penyebut menghitung seberapa halus utuh itu dipotong. Keduanya saling merujuk.",
		mindful: {
			notice: "1/4 roti dan 1/4 jam. Angkanya sama. Apakah 'besarnya' sama?",
			prompt: "Apa yang sama dan apa yang tidak pada dua 'seperempat' itu?",
			chips: [
				"Sama perbandingannya, beda utuhnya",
				"Seperempat jam = 15 menit, seperempat roti tergantung rotinya",
				"Tanpa utuh yang jelas, pecahan menggantung",
				"Aku dulu mengira penyebut 'angka bawah' tanpa makna"
			]
		},
		story: {
			title: "Roti berbagi setelah zuhur",
			body: [
				"Empat sahabat membagi satu roti sama rata. Hana mendapat seperempat. Di jam dinding, jarum sudah berjalan seperempat jam sejak adzan.",
				"Rafi bilang, \"Dua-duanya 1/4, jadi sama.\" Hana menatap roti di tangan dan menit di jam: \"Sama namanya, beda utuhnya.\"",
				"Bu Guru: \"Pecahan selalu bertanya: utuh yang mana? Bagian yang mana? Tanpa dua pertanyaan itu, 1/4 hanyalah coretan.\""
			],
			ask: "Jika rotinya dua (bukan satu), dan Hana tetap mendapat seperempat dari seluruh roti, apakah bagiannya lebih besar?"
		},
		explore: {
			lab: "fraction",
			mode: "shade",
			a: [1, 4],
			caption: "Ubah penyebut (halusnya potongan) dan pembilang (berapa yang diarsir). Perhatikan: 2/8 dan 1/4 bisa menutupi luas yang sama — nama berbeda, hubungan sama."
		},
		practice: [
			{
				id: "p1-1",
				prompt: "Pada pecahan 3/8, angka 8 menyatakan…",
				kind: "mc",
				options: [
					"Bagian yang diambil",
					"Banyaknya potongan sama besar pada utuh",
					"Hasil bagi 3 : 8 dalam bentuk desimal saja"
				],
				answer: "Banyaknya potongan sama besar pada utuh",
				hint: "Penyebut = nama potongan (perdelapan). Pembilang = berapa potong yang dihitung.",
				why: "3/8 = tiga potong dari delapan potong sama besar. Tanpa 'sama besar', pecahan curang."
			},
			{
				id: "p1-2",
				prompt: "Mana yang mewakili 3/4 dari sebatang pensil?",
				kind: "mc",
				options: [
					"Pensil dibagi 3, diambil 4",
					"Pensil dibagi 4 sama panjang, diambil 3 bagian",
					"Pensil dibagi 4, diambil 1 bagian"
				],
				answer: "Pensil dibagi 4 sama panjang, diambil 3 bagian",
				hint: "Utuh dulu, potong sama, baru hitung.",
				why: "Pembilang tidak boleh lebih dulu dari penyebut dalam makna 'potong'. Kita potong 4, ambil 3. (Pecahan tidak biasa 4/3 adalah 1 utuh + 1/3 — itu cerita lain.)"
			},
			{
				id: "p1-3",
				prompt: "Seperempat jam sama dengan … menit.",
				kind: "input",
				answer: "15",
				placeholder: "menit",
				hint: "Utuhnya 60 menit. Seperempat dari 60.",
				why: "1/4 × 60 = 15. Di sini pecahan menempel pada utuh '1 jam'. Makna muncul karena utuhnya jelas."
			},
			{
				id: "p1-4",
				prompt: "Gambar 2/5 yang benar adalah utuh yang dibagi … bagian sama, lalu … bagian diarsir.",
				kind: "mc",
				options: [
					"2, lalu 5",
					"5, lalu 2",
					"2, lalu 2",
					"7, lalu 2"
				],
				answer: "5, lalu 2",
				hint: "Penyebut dulu (potong), pembilang kemudian (ambil).",
				why: "Selalu: tentukan kehalusan (5), baru hitung yang diambil (2). Tertukar artinya menggambar 5/2 — lebih dari satu utuh."
			}
		],
		reflect: {
			prompts: ["Sebutkan dua 'seperempat' dalam hidupmu yang utuhnya berbeda.", "Mengapa 1/4 dari halaman buku tidak sama dengan 1/4 dari isi gelas, meski angkanya identik?"],
			takeaway: "Pecahan = hubungan bagian terhadap utuh yang jelas, dengan potongan sama besar."
		}
	},
	{
		id: "pecahan-2",
		jalurId: "pecahan",
		order: 2,
		title: "Nama berbeda, jumlah sama",
		intent: "Pecahan senilai adalah beberapa nama untuk jumlah yang sama. Menyederhanakan = mencari nama paling hemat.",
		mindful: {
			notice: "Hana memotong kue jadi 2, makan 1. Rafi memotong kue yang sama jadi 4, makan 2. Siapa lebih kenyang?",
			prompt: "Apa yang tetap, apa yang berubah?",
			chips: [
				"Jumlah kue yang dimakan tetap, potongannya berubah",
				"2/4 hanya 1/2 yang ditulis lebih ramai",
				"Membagi pembilang dan penyebut dengan bilangan sama tidak mengubah nilai",
				"Aku sering 'coret' tanpa tahu mengapa boleh"
			]
		},
		story: {
			title: "Dua cara memotong kue",
			body: [
				"Kue yang sama. Hana: dua potong, makan satu — 1/2. Rafi ingin terlihat makan lebih banyak: ia minta dipotong 4, lalu makan 2.",
				"Teman-teman tertawa: piring Rafi lebih ramai, perutnya sama.",
				"Bu Guru menuliskan 1/2 = 2/4 = 3/6 = 4/8. \"Bukan sulap. Setiap kali potongan diperhalus dua kali, jumlah potong yang diambil juga dikali dua.\""
			],
			ask: "Jika Rafi memotong jadi 8 dan ingin makan sama banyak dengan Hana, berapa potong yang harus ia ambil?"
		},
		explore: {
			lab: "fraction",
			mode: "equiv",
			a: [1, 2],
			caption: "Geser pengali. Batang atas tetap 1/2. Batang bawah terpecah lebih halus. Luas arsiran tidak boleh berubah — kalau berubah, namanya tidak senilai."
		},
		practice: [
			{
				id: "p2-1",
				prompt: "Pecahan 6/8 dalam bentuk paling sederhana adalah…",
				kind: "input",
				answer: "3/4",
				placeholder: "a/b",
				hint: "Bagi pembilang dan penyebut dengan FPB-nya.",
				why: "FPB(6,8)=2, jadi 6/8=3/4. Menyederhanakan = membatalkan potongan yang terlalu halus, kembali ke nama hemat."
			},
			{
				id: "p2-2",
				prompt: "Manakah yang senilai dengan 2/5?",
				kind: "mc",
				options: [
					"4/10",
					"3/5",
					"2/10",
					"5/2"
				],
				answer: "4/10",
				hint: "Kali pembilang dan penyebut dengan bilangan sama.",
				why: "2/5 × 2/2 = 4/10. 3/5 hanya pembilangnya yang berubah — itu menambah, bukan menamai ulang."
			},
			{
				id: "p2-3",
				prompt: "Tulis pecahan senilai 4/6 yang penyebutnya 12.",
				kind: "input",
				answer: "8/12",
				placeholder: "a/b",
				equivalentOk: true,
				hint: "6 × ? = 12. Kali pembilang dengan ? yang sama.",
				why: "Penyebut dikali 2, pembilang dikali 2: 8/12. Nilai tetap karena kita memperhalus potongan dan mengambil dua kali lebih banyak."
			},
			{
				id: "p2-4",
				prompt: "Mengapa 5/5 = 1, bukan 0 atau 10?",
				kind: "mc",
				options: [
					"Karena semua bagian utuh diambil",
					"Karena 5−5=0",
					"Karena 5+5=10"
				],
				answer: "Karena semua bagian utuh diambil",
				hint: "Pembilang = penyebut berarti 'seluruhnya'.",
				why: "5 dari 5 potong = seluruh kue. a/a = 1 untuk a ≠ 0. Mengurangkan atau menambah pembilang-penyebut adalah miskonsepsi klasik."
			}
		],
		reflect: {
			prompts: ["Kapan nama yang lebih ramai (4/8) lebih berguna daripada nama hemat (1/2)?", "Apa hubungan FPB dengan menyederhanakan pecahan?"],
			takeaway: "Senilai = nama lain untuk jumlah yang sama. Sederhana = nama dengan potongan paling kasar yang masih jujur."
		}
	},
	{
		id: "pecahan-3",
		jalurId: "pecahan",
		order: 3,
		title: "Membandingkan: samakan dulu potongannya",
		intent: "Tidak adil membandingkan 2/5 dan 1/3 sebelum potongannya sama halusnya. Penyebut persekutuan adalah kesetaraan.",
		mindful: {
			notice: "2/5 vs 1/3. Digit 2 > 1, jadi 2/5 lebih besar? Atau 5 > 3, jadi 2/5 lebih kecil karena dipotong lebih halus?",
			prompt: "Jebakan mana yang paling sering menjeratmu?",
			chips: [
				"Membandingkan pembilang saja",
				"Membandingkan penyebut saja (yang penyebutnya besar kukira selalu kecil)",
				"Perlu potongan sama dulu",
				"Bisa juga bandingkan ke 1/2 sebagai jangkar"
			]
		},
		story: {
			title: "Siapa makan lebih banyak?",
			body: [
				"Hana makan 2/5 loyang brownies. Rafi 1/3 loyang yang sama. Keduanya kenyang, keduanya yakin dirinyalah yang lebih banyak.",
				"Bu Guru memotong loyang imajiner jadi 15 potong sama (KPK 5 dan 3). 2/5 = 6/15, 1/3 = 5/15.",
				"Hana 6 potong, Rafi 5. Selisihnya satu perlimabelas — kecil, tapi bukan imajinasi."
			],
			ask: "Mengapa 15? Apa yang terjadi jika kita pakai 30 (juga kelipatan persekutuan) — apakah pemenangnya berubah?"
		},
		explore: {
			lab: "fraction",
			mode: "compare",
			a: [2, 5],
			b: [1, 3],
			caption: "Dua batang. Tombol 'samakan potongan' memotong keduanya ke penyebut persekutuan. Pemenang tidak boleh berubah hanya karena kita memperhalus."
		},
		practice: [
			{
				id: "p3-1",
				prompt: "Manakah yang lebih besar: 2/5 atau 1/3?",
				kind: "mc",
				options: [
					"2/5",
					"1/3",
					"Sama"
				],
				answer: "2/5",
				hint: "Samakan penyebut: 15. Atau bandingkan ke 1/2: 2/5 < 1/2 < ? cek 1/3.",
				why: "2/5=6/15, 1/3=5/15. Jangkar 1/2 juga: 2/5=0,4 < 0,5 dan 1/3≈0,33, jadi 2/5 lebih dekat ke setengah."
			},
			{
				id: "p3-2",
				prompt: "Urutkan dari terkecil: 1/2 , 2/3 , 3/8",
				kind: "mc",
				options: [
					"3/8 ; 1/2 ; 2/3",
					"1/2 ; 3/8 ; 2/3",
					"3/8 ; 2/3 ; 1/2",
					"2/3 ; 1/2 ; 3/8"
				],
				answer: "3/8 ; 1/2 ; 2/3",
				hint: "Penyebut persekutuan 24: 12/24, 16/24, 9/24.",
				why: "3/8=9/24, 1/2=12/24, 2/3=16/24. 3/8 di bawah setengah, 2/3 di atas setengah. Jangkar 1/2 mempercepat."
			},
			{
				id: "p3-3",
				prompt: "Benarkah 4/9 > 5/11 karena 9 < 11 (potongan lebih gemuk)?",
				kind: "mc",
				options: [
					"Benar, penyebut kecil selalu lebih besar",
					"Tidak selalu; harus dicek. 4/9 dan 5/11 hampir sama",
					"Tidak, 5/11 selalu lebih besar karena pembilangnya 5"
				],
				answer: "Tidak selalu; harus dicek. 4/9 dan 5/11 hampir sama",
				hint: "KPK 9 dan 11 = 99. 4/9=44/99, 5/11=45/99.",
				why: "5/11 sedikit lebih besar. Aturan 'penyebut kecil = pecahan besar' hanya adil jika pembilangnya sama (1/3 > 1/4). Di sini pembilang berbeda."
			},
			{
				id: "p3-4",
				prompt: "Pecahan yang terletak di antara 1/3 dan 1/2 adalah…",
				kind: "mc",
				options: [
					"1/6",
					"2/5",
					"3/4",
					"1/2"
				],
				answer: "2/5",
				hint: "1/3≈0,33 ; 1/2=0,5. 2/5=0,4. 1/6≈0,17 terlalu kecil. 3/4=0,75 terlalu besar.",
				why: "2/5=0,4 duduk di antara. Menyisip pecahan di celah adalah latihan nalar, bukan menghafal daftar."
			}
		],
		reflect: {
			prompts: ["Mengapa menyamakan penyebut mirip dengan menyamakan satuan saat membandingkan 2 meter dan 150 cm?", "Kapan membandingkan ke 0, ke 1/2, atau ke 1 lebih cepat daripada KPK?"],
			takeaway: "Membandingkan pecahan = menyamakan bahasa potongan, atau memakai jangkar (0, 1/2, 1) dengan sadar."
		}
	},
	{
		id: "pecahan-4",
		jalurId: "pecahan",
		order: 4,
		title: "Menjumlah: gabung yang sebahasa",
		intent: "Menjumlah pecahan adalah menggabungkan potongan sejenis. 1/2 + 1/3 bukan 2/5 — itu mencampur bahasa.",
		mindful: {
			notice: "Banyak teman menulis 1/2 + 1/3 = 2/5. Dari mana 2 dan 5? Mereka menambah atas dengan atas, bawah dengan bawah.",
			prompt: "Mengapa cara itu terasa masuk akal — dan mengapa ia salah?",
			chips: [
				"Karena terlihat rapi, dua-dua dijumlah",
				"Tapi potongan setengah dan sepertiga tidak sejenis",
				"Harus diubah ke perenam dulu: 3/6 + 2/6 = 5/6",
				"Aku sendiri pernah melakukan itu"
			]
		},
		story: {
			title: "Resep bubur",
			body: [
				"Resep bubur Hana: 1/2 gelas susu + 1/3 gelas air. Ia menulis 2/5 gelas 'cairan' dan adonannya terlalu kental.",
				"Ibunya tertawa pelan: \"Setengah gelas dan sepertiga gelas tidak bisa dijumlah seperti pensil. Samakan takarannya.\"",
				"Mereka memakai gelas penakar perenam: 3/6 + 2/6 = 5/6 gelas cairan. Bubur pun kentalnya pas."
			],
			ask: "Jika Hana menambah lagi 1/6 gelas madu, berapa total cairan? Apakah 5/6 + 1/6 membuat utuh?"
		},
		explore: {
			lab: "fraction",
			mode: "add",
			a: [1, 2],
			b: [1, 3],
			caption: "Dua batang, lalu 're-potong' ke penyebut persekutuan, lalu gabung. Jika jumlah ≥ 1, lihat kelebihan di batang kedua. Lawan jebakan 2/5."
		},
		practice: [
			{
				id: "p4-1",
				prompt: "1/2 + 1/3 =",
				kind: "input",
				answer: "5/6",
				placeholder: "a/b",
				equivalentOk: true,
				hint: "Penyebut persekutuan 6. 3/6 + 2/6.",
				why: "Bukan 2/5. 2/5 = 0,4, sedangkan 1/2 saja sudah 0,5 — jumlahnya tidak mungkin lebih kecil dari salah satu suku. Cek masuk akal ini adalah nalar mendalam."
			},
			{
				id: "p4-2",
				prompt: "5/6 − 1/3 =",
				kind: "input",
				answer: "1/2",
				placeholder: "a/b",
				equivalentOk: true,
				hint: "1/3 = 2/6. 5/6 − 2/6 = 3/6 = 1/2.",
				why: "Kurangi potongan sejenis, lalu sederhanakan. 3/6 adalah nama ramai untuk 1/2."
			},
			{
				id: "p4-3",
				prompt: "2/5 + 3/5 =",
				kind: "input",
				answer: "1",
				placeholder: "hasil",
				equivalentOk: true,
				hint: "Penyebut sudah sama. Jumlah pembilang. 5/5 = ?",
				why: "5/5 = 1 utuh. Ketika pembilang mencapai penyebut, kita 'pulang' ke satu. Tidak perlu menulis 5/5 kecuali diminta."
			},
			{
				id: "p4-4",
				prompt: "Mengapa 1/4 + 1/4 + 1/4 + 1/4 = 1, bukan 4/16?",
				kind: "mc",
				options: [
					"Karena 4×1 / 4×4 = 4/16 lalu disederhanakan kebetulan 1/4 — itu salah jalan",
					"Karena empat seperempat adalah seluruhnya; penyebut tetap 4, pembilang 4",
					"Karena semua pecahan jika dijumlah empat kali jadi 1"
				],
				answer: "Karena empat seperempat adalah seluruhnya; penyebut tetap 4, pembilang 4",
				hint: "Menjumlah sejenis: penyebut diam, pembilang bertambah.",
				why: "4/4=1. Jebakan 4/16 muncul dari mengali penyebut tanpa alasan — itu bahasa senilai yang salah pakai saat menjumlah."
			}
		],
		reflect: {
			prompts: ["Bagaimana kamu akan menjelaskan ke teman bahwa 1/2+1/3 ≠ 2/5, dengan satu gambar dan satu cek nalar?", "Kapan hasil jumlah pecahan bisa lebih dari 1, dan apa artinya di resep atau di waktu?"],
			takeaway: "Jumlahkan hanya potongan sebahasa. Jika bahasanya beda, terjemahkan dulu (KPK penyebut), baru gabung."
		}
	},
	{
		id: "pecahan-5",
		jalurId: "pecahan",
		order: 5,
		title: "Pecahan di kehidupan madrasah",
		intent: "Memindahkan pecahan ke waktu, berbagi, resep, dan jarak — supaya ia tidak tinggal di halaman buku.",
		mindful: {
			notice: "Zakat pertanian sepersepuluh (1/10) hasil. Waktu belajar 3/4 jam. Jalan 2/5 kilometer. Tiga utuh berbeda, satu bahasa pecahan.",
			prompt: "Di bagian hidupmu yang mana pecahan paling sering muncul tanpa kamu sadari?",
			chips: [
				"Waktu (seperempat jam, setengah jam)",
				"Makanan dan resep",
				"Berbagi tugas atau uang jajan",
				"Jarak dan peta"
			]
		},
		story: {
			title: "Tiga soal, satu bahasa",
			body: [
				"Pagi: Hana mengaji 1/4 jam, lalu mengerjakan PR 1/2 jam. Berapa menit total?",
				"Siang: 2/3 nampan kue diberikan ke kelas 4, sisanya ke kelas 5. Jika nampan berisi 24 kue, berapa untuk kelas 5?",
				"Sore: kebun madrasah panen 40 kg timun. 1/10 disisihkan untuk sedekah. Berapa kg yang disedekahkan?",
				"Tiga cerita. Yang sama: tentukan utuh, potong, ambil. Yang berbeda: satuan menit, buah, kilogram."
			],
			ask: "Pilih satu cerita. Di mana kamu bisa salah jika lupa menuliskan utuhnya?"
		},
		explore: {
			lab: "fraction",
			mode: "life",
			a: [1, 4],
			b: [1, 2],
			caption: "Mainkan tiga konteks: waktu, berbagi, sedekah. Ubah pecahannya. Lihat satuan yang ikut berubah. Jangan lepas pecahan dari utuhnya."
		},
		practice: [
			{
				id: "p5-1",
				prompt: "1/4 jam + 1/2 jam = … menit",
				kind: "input",
				answer: "45",
				placeholder: "menit",
				hint: "Samakan ke jam dulu: 1/4+2/4=3/4 jam. 3/4 dari 60 menit.",
				why: "3/4 × 60 = 45 menit. Bisa juga 15+30. Dua representasi: pecahan jam, atau menit. Yang dalam bisa berpindah di antara keduanya."
			},
			{
				id: "p5-2",
				prompt: "2/3 dari 24 kue diberikan. Sisa untuk kelas 5?",
				kind: "input",
				answer: "8",
				placeholder: "kue",
				hint: "Yang diberikan 16, atau langsung 1/3 dari 24.",
				why: "Sisa = 1 − 2/3 = 1/3. 1/3 × 24 = 8. Menghitung sisa sering lebih cepat daripada menghitung yang diberikan lalu mengurangi."
			},
			{
				id: "p5-3",
				prompt: "1/10 dari 40 kg = … kg",
				kind: "input",
				answer: "4",
				placeholder: "kg",
				hint: "Sepersepuluh = bagi 10.",
				why: "40/10=4 kg. Sepersepuluh adalah 'satu dari sepuluh bagian sama'. Pada 40 kg, tiap bagian 4 kg."
			},
			{
				id: "p5-4",
				prompt: "Hana sudah jalan 3/5 km dari 2 km. Sisa jarak?",
				kind: "mc",
				options: [
					"2/5 km",
					"7/5 km",
					"1 2/5 km",
					"3/5 km"
				],
				answer: "1 2/5 km",
				hint: "Utuhnya 2 km = 10/5 km. Sudah 3/5. Sisa 7/5 = 1 2/5 km.",
				why: "Jebakan: 2 − 3/5 disangka 2/5 (mengurangkan 2 dengan 3, 5 tetap). Padahal 2 = 10/5, 10/5 − 3/5 = 7/5 km. Utuh harus sebahasa dulu."
			}
		],
		reflect: {
			prompts: ["Tulis satu soal pecahan dari kehidupan rumah atau madrasahmu, lengkap dengan utuh dan satuannya.", "Pelajaran pecahan mana yang paling mengubah caramu melihat angka tumpuk a/b?"],
			takeaway: "Pecahan hidup ketika utuh dan satuan ikut serta. Lepaskan dari konteks, ia kembali jadi coretan."
		}
	}
];
var JALUR = [
	{
		id: "bilangan",
		title: "Bilangan cacah",
		subtitle: "Hingga ratusan ribu",
		blurb: "Membaca wajah angka, membandingkan dari kiri, dan memakai operasi sebagai penukaran sepuluh — bukan hafalan langkah.",
		why: "Supaya 305.042 bukan deret digit, melainkan tiga ratus lima ribu yang bisa ditaksir, dijumlah, dan diceritakan.",
		pillar: "Nilai tempat adalah rumah makna."
	},
	{
		id: "fpb-kpk",
		title: "FPB dan KPK",
		subtitle: "Berbagi dan bertemu",
		blurb: "Faktor menyusun, prima adalah bahan baku, FPB berbagi paling besar, KPK adalah loncatan yang berpapasan.",
		why: "Supaya kamu tidak tertukar rumus: soal berbagi memakai FPB, soal pertemuan memakai KPK.",
		pillar: "Pilih alat setelah paham pertanyaan."
	},
	{
		id: "pecahan",
		title: "Bilangan pecahan",
		subtitle: "Bagian dari utuh",
		blurb: "Pecahan adalah hubungan. Senilai, banding, jumlah — semuanya soal menyamakan bahasa potongan.",
		why: "Supaya 1/2 + 1/3 tidak pernah lagi menjadi 2/5, dan seperempat jam punya satuan.",
		pillar: "Tanpa utuh yang jelas, pecahan menggantung."
	}
];
var ALL_LESSONS = [
	...BILANGAN_LESSONS,
	...FPB_LESSONS,
	...PECAHAN_LESSONS
];
function lessonsFor(jalurId) {
	return ALL_LESSONS.filter((l) => l.jalurId === jalurId).sort((a, b) => a.order - b.order);
}
function getLesson(id) {
	return ALL_LESSONS.find((l) => l.id === id);
}
function getJalur(id) {
	return JALUR.find((j) => j.id === id);
}
function nextLesson(id) {
	const current = getLesson(id);
	if (!current) return void 0;
	return lessonsFor(current.jalurId).find((l) => l.order === current.order + 1);
}
var PILLARS = [
	{
		id: "mindful",
		title: "Berkesadaran",
		body: "Berhenti sejenak. Perhatikan apa yang kamu lihat, bukan yang biasa kamu lakukan. Bahasa bersyarat: 'bisa jadi', 'tergantung'."
	},
	{
		id: "meaningful",
		title: "Bermakna",
		body: "Setiap ide menempel pada cerita: pasar, masjid, resep, barisan. Pengetahuan baru mengait pada yang sudah kamu tahu."
	},
	{
		id: "deep",
		title: "Mendalam",
		body: "Bukan menghafal langkah. Menggali mengapa, memakai beberapa gambar, dan memindahkan ide ke soal yang belum pernah dilihat."
	}
];
//#endregion
export { lessonsFor as a, getLesson as i, PILLARS as n, nextLesson as o, getJalur as r, JALUR as t };
