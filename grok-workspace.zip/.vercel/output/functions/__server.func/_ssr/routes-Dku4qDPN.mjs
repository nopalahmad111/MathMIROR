import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { u as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as Mark } from "./router-BpXJR4av.mjs";
import { t as Button } from "./button-CSTjc5OR.mjs";
import { a as lessonsFor, n as PILLARS, t as JALUR } from "./content-pItgeMuQ.mjs";
import { n as useProgress, t as mindfulDoneToday } from "./progress-COz1HOFS.mjs";
import { n as useHydrated, t as BrandSplash } from "./use-hydrated-N5N-U9NQ.mjs";
import { a as CardHeader, i as CardDescription, n as Card, o as CardTitle, r as CardContent, s as Progress, t as Badge } from "./progress-DZx-qzbq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dku4qDPN.js
var import_jsx_runtime = require_jsx_runtime();
function greetingId(date = /* @__PURE__ */ new Date()) {
	const h = date.getHours();
	if (h < 11) return "Selamat pagi";
	if (h < 15) return "Selamat siang";
	if (h < 18) return "Selamat sore";
	return "Selamat malam";
}
function Home() {
	const hydrated = useHydrated();
	const onboardingDone = useProgress((s) => s.onboardingDone);
	const learnerName = useProgress((s) => s.learnerName);
	const niat = useProgress((s) => s.niat);
	const completed = useProgress((s) => s.completed);
	const lastMindfulAt = useProgress((s) => s.lastMindfulAt);
	const markMindful = useProgress((s) => s.markMindful);
	const reflections = useProgress((s) => s.reflections);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandSplash, {});
	if (!onboardingDone) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {});
	const totalLessons = JALUR.reduce((n, j) => n + lessonsFor(j.id).length, 0);
	const doneCount = Object.keys(completed).length;
	const greeted = `${greetingId()}${learnerName ? `, ${learnerName}` : ""}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "star-field -mx-4 rounded-none px-4 py-8 sm:-mx-0 sm:rounded-2xl sm:border sm:border-border sm:px-10 sm:py-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-[0.18em]",
							children: "Kelas 5 MI"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-5 font-display text-4xl leading-tight tracking-tight sm:text-5xl",
						children: [greeted, "."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-base leading-normal text-muted",
						children: niat || "Belajar berkesadaran, bermakna, dan mendalam."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex justify-between text-xs font-medium uppercase tracking-wide text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Kedalaman jalur" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									doneCount,
									"/",
									totalLessons,
									" pelajaran"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: totalLessons ? doneCount / totalLessons * 100 : 0 })]
					})
				]
			}),
			!mindfulDoneToday(lastMindfulAt) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 rounded-xl border border-border bg-bg-elevated p-5 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-normal text-muted",
					children: "Satu napas sebelum angka. Pikiran yang tenang lebih mudah paham."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: markMindful,
					children: "Sudah kuambil"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Tiga jalur"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Bilangan cacah, FPB & KPK, pecahan — kurikulum kelas 5."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-4 md:grid-cols-3",
						children: JALUR.map((j) => {
							const lessons = lessonsFor(j.id);
							const done = lessons.filter((l) => completed[l.id]).length;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/jalur/$jalurId",
								params: { jalurId: j.id },
								className: "group block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
									className: "h-full transition-colors group-hover:border-border-strong",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											children: [
												done,
												"/",
												lessons.length
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
											className: "mt-3",
											children: j.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: j.subtitle })
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm leading-normal text-muted",
											children: j.blurb
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
											className: "mt-5",
											value: done / lessons.length * 100
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary",
											children: ["Masuk jalur", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
										})
									] })]
								})
							}, j.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-14 grid gap-8 md:grid-cols-3",
				children: PILLARS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg",
					children: p.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-normal text-muted",
					children: p.body
				})] }, p.id))
			}),
			reflections[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Cermin terakhir"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/cermin",
						className: "text-sm font-medium text-primary",
						children: "Semua"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-normal whitespace-pre-wrap",
						children: reflections[0].text
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-subtle",
						children: new Date(reflections[0].at).toLocaleDateString("id-ID", {
							day: "numeric",
							month: "long"
						})
					})]
				}) })]
			}) : null
		]
	});
}
//#endregion
export { Home as component };
