import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Route } from "./router-BpXJR4av.mjs";
import { t as Button } from "./button-CSTjc5OR.mjs";
import { _ as roundToPlace, c as formatId, f as lcm, n as PracticeQuiz, o as factorsOf, p as numberToWordsId, u as gcd, v as simplifyFrac } from "./practice-quiz-D0S_bD9T.mjs";
import { r as getJalur } from "./content-pItgeMuQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/latihan._jalurId-BdI6cw6n.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function pick(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}
function randInt(min, max) {
	return min + Math.floor(Math.random() * (max - min + 1));
}
function generatePractice(jalurId, n = 6) {
	const items = [];
	for (let i = 0; i < n; i++) if (jalurId === "bilangan") items.push(genBilangan(i));
	else if (jalurId === "fpb-kpk") items.push(genFpb(i));
	else items.push(genPecahan(i));
	return items;
}
function genBilangan(i) {
	const kind = i % 4;
	if (kind === 0) {
		const n = randInt(1e4, 999999);
		return {
			id: `g-b-${i}-${n}`,
			prompt: `Tuliskan ${formatId(n)} dengan angka saja (tanpa titik).`,
			kind: "input",
			answer: String(n),
			placeholder: "Angka",
			hint: "Titik hanya pemisah ribuan. Hapus titik, jangan geser digit.",
			why: `${formatId(n)} dibaca ${numberToWordsId(n)}. Bentuk standarnya ${n}.`
		};
	}
	if (kind === 1) {
		const a = randInt(1e4, 8e4);
		const b = randInt(1e4, 8e4);
		const [x, y] = a === b ? [a, a + 125] : [a, b];
		const bigger = Math.max(x, y);
		return {
			id: `g-b-${i}-${x}`,
			prompt: `Manakah yang lebih besar: ${formatId(x)} atau ${formatId(y)}?`,
			kind: "mc",
			options: [formatId(x), formatId(y)],
			answer: formatId(bigger),
			hint: "Bandingkan dari rumah paling kiri.",
			why: `${formatId(bigger)} lebih besar. Selisihnya ${formatId(Math.abs(x - y))}.`
		};
	}
	if (kind === 2) {
		const a = randInt(12e3, 45e3);
		const b = randInt(8e3, 2e4);
		return {
			id: `g-b-${i}-add`,
			prompt: `${formatId(a)} + ${formatId(b)} =`,
			kind: "input",
			answer: String(a + b),
			placeholder: "Hasil",
			hint: "Jumlahkan dari satuan. Ikat 10 menjadi 1 di rumah sebelah.",
			why: `${formatId(a)} + ${formatId(b)} = ${formatId(a + b)}.`
		};
	}
	const n = randInt(12500, 98e3);
	const place = pick([
		10,
		100,
		1e3,
		1e4
	]);
	const names = {
		10: "puluhan",
		100: "ratusan",
		1e3: "ribuan",
		1e4: "puluhan ribu"
	};
	const rounded = roundToPlace(n, place);
	return {
		id: `g-b-${i}-r`,
		prompt: `${formatId(n)} dibulatkan ke ${names[place]} terdekat =`,
		kind: "input",
		answer: String(rounded),
		placeholder: "Hasil",
		hint: `Lihat digit di kanan ${names[place]}. 5 atau lebih → naik.`,
		why: `${formatId(n)} → ${formatId(rounded)} pada ${names[place]} terdekat.`
	};
}
function genFpb(i) {
	if (i % 2 === 0) {
		const g = pick([
			2,
			3,
			4,
			5,
			6,
			8,
			12
		]);
		let x = g * pick([
			2,
			3,
			4,
			5,
			6,
			7,
			8
		]);
		let y = g * pick([
			3,
			4,
			5,
			6,
			9
		]);
		if (x === y) y += g;
		const ans = gcd(x, y);
		return {
			id: `g-f-${i}-g`,
			prompt: `FPB ${x} dan ${y} =`,
			kind: "input",
			answer: String(ans),
			placeholder: "FPB",
			hint: `Faktor ${x}: ${factorsOf(x).join(", ")}. Irisan terbesar dengan faktor ${y}?`,
			why: `FPB(${x}, ${y}) = ${ans}. Itu ukuran berbagi terbesar tanpa sisa.`
		};
	}
	const a = pick([
		4,
		6,
		8,
		9,
		10,
		12
	]);
	const b = pick([
		6,
		8,
		10,
		12,
		15,
		18
	]);
	const ans = lcm(a, b);
	return {
		id: `g-f-${i}-l`,
		prompt: `KPK ${a} dan ${b} =`,
		kind: "input",
		answer: String(ans),
		placeholder: "KPK",
		hint: "Cari kelipatan yang pertama kali sama. Atau a×b / FPB.",
		why: `KPK(${a}, ${b}) = ${ans}. Pertemuan pertama dua loncatan.`
	};
}
function genPecahan(i) {
	const kind = i % 3;
	if (kind === 0) {
		const n = pick([
			2,
			4,
			6,
			8,
			9,
			10,
			12
		]);
		const d = pick([
			8,
			10,
			12,
			16,
			18
		]);
		const s = simplifyFrac(n, d);
		return {
			id: `g-p-${i}-s`,
			prompt: `Sederhanakan ${n}/${d}.`,
			kind: "input",
			answer: `${s.n}/${s.d}`,
			placeholder: "a/b",
			hint: "Bagi pembilang dan penyebut dengan FPB.",
			why: `${n}/${d} = ${s.n}/${s.d}. Nama hemat untuk jumlah yang sama.`
		};
	}
	if (kind === 1) {
		const a = pick([
			1,
			2,
			3
		]);
		const b = pick([
			4,
			5,
			6
		]);
		const c = pick([1, 2]);
		const d = pick([
			3,
			4,
			8
		]);
		const left = a * d + c * b;
		const right = b * d;
		const s = simplifyFrac(left, right);
		return {
			id: `g-p-${i}-a`,
			prompt: `${a}/${b} + ${c}/${d} = (bentuk sederhana)`,
			kind: "input",
			answer: s.d === 1 ? String(s.n) : `${s.n}/${s.d}`,
			placeholder: "a/b",
			equivalentOk: true,
			hint: "Samakan penyebut, jumlahkan pembilang, sederhanakan.",
			why: `Penyebut ${b * d}. Hasil ${s.d === 1 ? s.n : `${s.n}/${s.d}`}. Bukan ${a + c}/${b + d}.`
		};
	}
	const n = pick([
		1,
		2,
		3,
		4
	]);
	const d = pick([
		2,
		4,
		5,
		8
	]);
	const whole = pick([
		12,
		20,
		24,
		30,
		40
	]);
	const ans = n * whole / d;
	if (!Number.isInteger(ans)) {
		const half = whole / 2;
		return {
			id: `g-p-${i}-of`,
			prompt: `1/2 dari ${whole} =`,
			kind: "input",
			answer: String(half),
			placeholder: "Hasil",
			hint: `Bagi ${whole} menjadi 2 bagian sama, ambil 1.`,
			why: `1/2 × ${whole} = ${half}. Utuhnya ${whole}.`
		};
	}
	return {
		id: `g-p-${i}-of`,
		prompt: `${n}/${d} dari ${whole} =`,
		kind: "input",
		answer: String(ans),
		placeholder: "Hasil",
		hint: `Bagi ${whole} menjadi ${d} bagian sama, ambil ${n}.`,
		why: `${n}/${d} × ${whole} = ${ans}. Utuhnya ${whole}.`
	};
}
function LatihanPage() {
	const { jalurId } = Route.useParams();
	const jalur = getJalur(jalurId);
	const [seed, setSeed] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(null);
	const items = (0, import_react.useMemo)(() => jalur ? generatePractice(jalur.id, 6) : [], [jalur, seed]);
	if (!jalur) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl",
			children: "Jalur tidak ada"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-block text-sm text-primary",
			children: "Beranda"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
				children: "Latihan campuran"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-3xl tracking-tight",
				children: jalur.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Soal baru setiap putaran. Baca penjelasan meski sudah tepat — itu bagian mendalamnya."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 rounded-xl border border-border bg-bg-elevated p-5",
				children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xl",
						children: [
							done.correct,
							" dari ",
							done.total,
							" tepat."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								setDone(null);
								setSeed((s) => s + 1);
							},
							children: "Putaran baru"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/jalur/$jalurId",
								params: { jalurId: jalur.id },
								children: "Kembali ke jalur"
							})
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PracticeQuiz, {
					items,
					onDone: (correct, total) => setDone({
						correct,
						total
					})
				})
			})
		]
	});
}
//#endregion
export { LatihanPage as component };
