import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as PILLARS } from "./content-pItgeMuQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panduan-BJ8k5Uvq.js
var import_jsx_runtime = require_jsx_runtime();
function PanduanPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
				children: "Untuk guru dan orang tua"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight",
				children: "Tiga napas belajar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-normal text-muted",
				children: "Bening mengikuti pembelajaran mendalam: berkesadaran (mindful), bermakna (meaningful), dan menggali mengapa (deep). Anak kelas 5 MI tidak hanya dilatih cepat — ia dilatih melihat."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-12 space-y-10",
				children: PILLARS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: p.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-base leading-normal text-fg/90",
					children: p.body
				})] }, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Bagaimana sebuah pelajaran berjalan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-3 pl-5 text-sm leading-normal text-fg/90",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Niat."
						}), " Anak memperhatikan sesuatu yang kecil — sering kali miskonsepsi — sebelum rumus muncul."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Cerita."
						}), " Hana dan Rafi di madrasah: zakat, barisan, resep, jadwal mengaji. Pengetahuan menempel pada kehidupan."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Gali."
						}), " Papan nilai tempat, loncatan KPK, batang pecahan. Anak mengubah-ubah, memperhatikan apa yang tetap dan apa yang berubah."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Latihan."
						}), " Sedikit soal, banyak penjelasan. Salah bukan gagal — pintu ke mengapa."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Cermin."
						}), " Dua pertanyaan metakognitif. Jejaknya tersimpan di perangkat ini, bukan di akun."] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Cakupan materi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2 text-sm leading-normal text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Bilangan cacah hingga ratusan ribu — nilai tempat, banding, operasi, pembulatan." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "FPB dan KPK — faktor, prima, berbagi vs bertemu, memilih alat." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pecahan — makna, senilai, banding, jumlah-kurang, konteks kehidupan." })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-12 text-sm leading-normal text-muted",
				children: "Progres tersimpan hanya di peramban ini. Cocok untuk stasiun kelas, belajar mandiri, atau pendampingan di rumah. Tidak perlu akun."
			})
		]
	});
}
//#endregion
export { PanduanPage as component };
