import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as getLesson } from "./content-pItgeMuQ.mjs";
import { n as useProgress } from "./progress-COz1HOFS.mjs";
import { n as useHydrated, t as BrandSplash } from "./use-hydrated-N5N-U9NQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cermin-DcMsV3bD.js
var import_jsx_runtime = require_jsx_runtime();
function CerminPage() {
	const hydrated = useHydrated();
	const reflections = useProgress((s) => s.reflections);
	const resetAll = useProgress((s) => s.resetAll);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandSplash, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
				children: "Berkesadaran"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight",
				children: "Cermin"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-base leading-normal text-muted",
				children: "Catatan yang kamu tulis setelah belajar. Bukan nilai. Jejak nalar."
			}),
			reflections.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-sm text-muted",
				children: "Belum ada refleksi. Selesaikan satu pelajaran sampai langkah Cermin."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10 space-y-4",
				children: reflections.map((r) => {
					const lesson = getLesson(r.lessonId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-wide text-muted",
								children: lesson?.title ?? r.lessonId
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 whitespace-pre-wrap text-sm leading-normal",
								children: r.text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-subtle",
									children: new Date(r.at).toLocaleDateString("id-ID", {
										day: "numeric",
										month: "long",
										year: "numeric"
									})
								}), lesson ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/belajar/$lessonId",
									params: { lessonId: lesson.id },
									className: "text-xs font-medium text-primary",
									children: "Buka lagi"
								}) : null]
							})
						]
					}) }) }, r.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-16 text-xs text-subtle underline-offset-4 hover:text-muted hover:underline",
				onClick: () => {
					if (window.confirm("Hapus nama, niat, dan semua jejak belajar di perangkat ini?")) resetAll();
				},
				children: "Mulai ulang jejak di perangkat ini"
			})
		]
	});
}
//#endregion
export { CerminPage as component };
