import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as ArrowLeft, i as Minus, n as Plus, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { i as Route$2, o as cn } from "./router-BpXJR4av.mjs";
import { t as Button } from "./button-CSTjc5OR.mjs";
import { _ as roundToPlace, a as expandedForm, c as formatId, d as isPrime, f as lcm, g as primeFactors, h as placeLabels, i as euclidSteps, l as fromDigits, m as parseIdNumber, n as PracticeQuiz, o as factorsOf, p as numberToWordsId, r as digitsOf, s as formatFrac, t as Input, u as gcd, v as simplifyFrac } from "./practice-quiz-D0S_bD9T.mjs";
import { i as getLesson, o as nextLesson, r as getJalur } from "./content-pItgeMuQ.mjs";
import { n as useProgress } from "./progress-COz1HOFS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/belajar._lessonId-D02jxzrJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FactorLab({ mode, start = 24 }) {
	const [raw, setRaw] = (0, import_react.useState)(String(start));
	const n = Math.max(1, Math.min(60, parseIdNumber(raw) ?? start));
	const facts = factorsOf(n);
	const [width, setWidth] = (0, import_react.useState)(facts.includes(start) && start <= 24 ? 6 : facts[1] ?? 1);
	const valid = n % width === 0;
	const height = valid ? n / width : 0;
	const cells = (0, import_react.useMemo)(() => Array.from({ length: n }, (_, i) => i), [n]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Bilangan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5 max-w-40",
					inputMode: "numeric",
					value: raw,
					onChange: (e) => {
						setRaw(e.target.value);
						const v = parseIdNumber(e.target.value);
						if (v && v > 0) {
							const f = factorsOf(v);
							setWidth(f[Math.min(1, f.length - 1)] ?? 1);
						}
					}
				})]
			}),
			mode !== "tree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: width === f ? "default" : "secondary",
						onClick: () => setWidth(f),
						children: [
							f,
							" × ",
							n / f
						]
					}, f))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid w-fit gap-1",
						style: { gridTemplateColumns: `repeat(${width}, 14px)` },
						children: cells.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("size-3.5 rounded-[2px]", valid ? "bg-primary" : "bg-surface-2") }, i))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: valid ? `${width} kolom × ${height} baris = ${n}. Susunan ini rapi: ${width} faktor ${n}.` : `${width} tidak membagi ${n}. Ada sisa — bukan faktor.`
				})
			] }) : null,
			mode === "prime" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-primary-soft px-3 py-2 text-sm",
				children: n === 1 ? "1 hanya punya satu faktor. Bukan prima, bukan majemuk." : isPrime(n) ? `${n} prima: hanya 1 × ${n}. Tidak bisa jadi kotak yang lebih gemuk.` : `${n} majemuk. Faktor: ${facts.join(", ")}. Bahan baku prima: ${primeFactors(n).join(" × ")}.`
			}) : null,
			mode === "rectangles" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Ada ",
					facts.length,
					" faktor, berarti ",
					facts.length,
					" cara berbaris rapi (termasuk 1 × ",
					n,
					")."
				]
			}) : null,
			mode === "tree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactorTree, { n }) : null
		]
	});
}
function FactorTree({ n }) {
	const facts = factorsOf(n).filter((f) => f !== 1 && f !== n);
	const [split, setSplit] = (0, import_react.useState)(facts[0] ?? null);
	const other = split ? n / split : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Pilih pasangan faktor untuk memecah ",
					n,
					". Lanjut pecah yang masih majemuk di kepala — daunnya harus prima."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: facts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: n === 1 ? "1 tidak dipecah." : `${n} prima — daun pohon.`
				}) : facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: split === f ? "default" : "secondary",
					onClick: () => setSplit(f),
					children: [
						f,
						" × ",
						n / f
					]
				}, f))
			}),
			split && other ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-2 py-2 font-display",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-md border border-border px-3 py-1",
						children: n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-px bg-border-strong" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { v: split }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { v: other })]
					})
				]
			}) : null,
			n > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Resep prima ",
					n,
					": ",
					primeFactors(n).join(" × "),
					"."
				]
			}) : null
		]
	});
}
function Leaf({ v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-md border px-3 py-1", isPrime(v) ? "border-primary bg-primary-soft" : "border-border"),
		children: [v, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-sans font-medium uppercase tracking-wide text-muted",
			children: isPrime(v) ? "prima" : "pecah lagi"
		})]
	});
}
function Bar({ n, d, label, muted }) {
	const den = Math.max(1, d);
	const num = Math.max(0, n);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display tabular-nums",
				children: formatFrac(num, den)
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-10 overflow-hidden rounded-md border border-border",
			children: Array.from({ length: den }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-full flex-1 border-r border-border last:border-r-0", i < num ? muted ? "bg-surface-2" : "bg-primary" : "bg-bg-elevated") }, i))
		})]
	});
}
function Stepper({ label, value, min, max, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-24 text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "secondary",
				className: "size-9",
				onClick: () => onChange(Math.max(min, value - 1)),
				"aria-label": `Kurangi ${label}`,
				children: "−"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center font-display tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "secondary",
				className: "size-9",
				onClick: () => onChange(Math.min(max, value + 1)),
				"aria-label": `Tambah ${label}`,
				children: "+"
			})
		]
	});
}
function FractionLab({ mode, a = [1, 4], b = [1, 3] }) {
	const [n, setN] = (0, import_react.useState)(a[0]);
	const [d, setD] = (0, import_react.useState)(a[1]);
	const [n2, setN2] = (0, import_react.useState)(b[0]);
	const [d2, setD2] = (0, import_react.useState)(b[1]);
	const [mul, setMul] = (0, import_react.useState)(2);
	const [equalized, setEqualized] = (0, import_react.useState)(false);
	const [ctx, setCtx] = (0, import_react.useState)("waktu");
	const s = simplifyFrac(n, d);
	const common = lcm(d, d2);
	const e1n = n * (common / d);
	const e2n = n2 * (common / d2);
	const sumN = e1n + e2n;
	const sumS = simplifyFrac(sumN, common);
	if (mode === "shade") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n,
				d,
				label: "Utuh yang dipotong sama besar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Pembilang",
				value: n,
				min: 0,
				max: d,
				onChange: setN
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Penyebut",
				value: d,
				min: 1,
				max: 12,
				onChange: (v) => {
					setD(v);
					setN((cur) => Math.min(cur, v));
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					n,
					"/",
					d,
					" artinya ",
					n,
					" dari ",
					d,
					" potong sama. Nama hemat: ",
					s.d === 1 ? s.n : `${s.n}/${s.d}`,
					".",
					s.n === s.d ? " Itu seluruh utuh." : ""
				]
			})
		]
	});
	if (mode === "equiv") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n,
				d,
				label: "Nama awal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n: n * mul,
				d: d * mul,
				label: `Dikali ${mul}/${mul}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Pengali",
				value: mul,
				min: 1,
				max: 8,
				onChange: setMul
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Pembilang awal",
				value: n,
				min: 1,
				max: 8,
				onChange: setN
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Penyebut awal",
				value: d,
				min: n,
				max: 12,
				onChange: setD
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					n,
					"/",
					d,
					" = ",
					n * mul,
					"/",
					d * mul,
					". Potongan lebih halus, jumlah yang diarsir sama. Menyederhanakan adalah jalan pulang: bagi dengan FPB ",
					gcd(n * mul, d * mul),
					"."
				]
			})
		]
	});
	if (mode === "compare") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n: equalized ? e1n : n,
				d: equalized ? common : d,
				label: "Hana"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n: equalized ? e2n : n2,
				d: equalized ? common : d2,
				label: "Rafi"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Hana atas",
						value: n,
						min: 1,
						max: d,
						onChange: setN
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Hana bawah",
						value: d,
						min: 2,
						max: 12,
						onChange: (v) => {
							setD(v);
							setN((c) => Math.min(c, v));
							setEqualized(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Rafi atas",
						value: n2,
						min: 1,
						max: d2,
						onChange: setN2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Rafi bawah",
						value: d2,
						min: 2,
						max: 12,
						onChange: (v) => {
							setD2(v);
							setN2((c) => Math.min(c, v));
							setEqualized(false);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: equalized ? "default" : "secondary",
				onClick: () => setEqualized((v) => !v),
				children: equalized ? "Kembalikan potongan asli" : `Samakan potongan (per-${common})`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					e1n === e2n ? "Sama banyak." : e1n > e2n ? `${n}/${d} lebih besar (${e1n}/${common} > ${e2n}/${common}).` : `${n2}/${d2} lebih besar (${e2n}/${common} > ${e1n}/${common}).`,
					" ",
					"Pemenang tidak boleh berubah hanya karena potongan diperhalus."
				]
			})
		]
	});
	if (mode === "add") {
		const overflow = sumN > common;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n,
					d,
					label: `${n}/${d}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n: n2,
					d: d2,
					label: `${n2}/${d2}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium uppercase tracking-wide text-muted",
					children: ["Bahasa yang sama — per ", common]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n: e1n,
					d: common,
					label: `${e1n}/${common}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n: e2n,
					d: common,
					label: `${e2n}/${common}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n: Math.min(sumN, common),
					d: common,
					label: "Gabungan (satu utuh)"
				}),
				overflow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					n: sumN - common,
					d: common,
					label: "Kelebihan di utuh berikutnya"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "A atas",
							value: n,
							min: 1,
							max: 8,
							onChange: setN
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "A bawah",
							value: d,
							min: 2,
							max: 12,
							onChange: setD
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "B atas",
							value: n2,
							min: 1,
							max: 8,
							onChange: setN2
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
							label: "B bawah",
							value: d2,
							min: 2,
							max: 12,
							onChange: setD2
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-md bg-primary-soft px-3 py-2 text-sm",
					children: [
						n,
						"/",
						d,
						" + ",
						n2,
						"/",
						d2,
						" = ",
						e1n,
						"/",
						common,
						" + ",
						e2n,
						"/",
						common,
						" = ",
						sumN,
						"/",
						common,
						sumS.n !== sumN ? ` = ${sumS.d === 1 ? sumS.n : `${sumS.n}/${sumS.d}`}` : "",
						". Bukan ",
						n + n2,
						"/",
						d + d2,
						"."
					]
				})
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LifeMode, {
		ctx,
		setCtx,
		n,
		d,
		setN,
		setD,
		n2,
		d2
	});
}
function LifeMode({ ctx, setCtx, n, d, setN, setD, n2, d2 }) {
	const minutes = (0, import_react.useMemo)(() => Math.round(n / d * 60), [n, d]);
	const cakes = 24;
	const given = Math.round(n / d * cakes);
	const zakat = Math.round(n / d * 40);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"waktu",
					"berbagi",
					"sedekah"
				].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: ctx === c ? "default" : "secondary",
					onClick: () => setCtx(c),
					children: c === "waktu" ? "Waktu" : c === "berbagi" ? "Berbagi kue" : "Sedekah panen"
				}, c))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				n,
				d,
				label: `Pecahan ${n}/${d}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Pembilang",
				value: n,
				min: 1,
				max: d,
				onChange: setN
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
				label: "Penyebut",
				value: d,
				min: 2,
				max: 10,
				onChange: (v) => {
					setD(v);
					setN(Math.min(n, v));
				}
			}),
			ctx === "waktu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-normal text-muted",
				children: [
					"Utuhnya 1 jam = 60 menit. ",
					n,
					"/",
					d,
					" jam = ",
					minutes,
					" menit.",
					n2 && d2 ? ` Kalau ditambah ${n2}/${d2} jam, samakan dulu bahasanya.` : ""
				]
			}) : null,
			ctx === "berbagi" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-normal text-muted",
				children: [
					"Utuhnya 24 kue. ",
					n,
					"/",
					d,
					" dari 24 = ",
					given,
					" kue. Sisa ",
					1 - n / d > 0 ? `${formatFrac(d - n, d)} × 24 = ${cakes - given}` : 0,
					"."
				]
			}) : null,
			ctx === "sedekah" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-normal text-muted",
				children: [
					"Utuhnya 40 kg panen. ",
					n,
					"/",
					d,
					" disedekahkan = ",
					zakat,
					" kg. Sepersepuluh adalah 1 dari 10 bagian sama."
				]
			}) : null
		]
	});
}
function GcdLcmLab({ mode, a: a0 = 18, b: b0 = 24, story }) {
	const [rawA, setRawA] = (0, import_react.useState)(String(a0));
	const [rawB, setRawB] = (0, import_react.useState)(String(b0));
	const [view, setView] = (0, import_react.useState)(mode === "lcm" ? "lcm" : "gcd");
	const a = Math.max(1, Math.min(120, parseIdNumber(rawA) ?? a0));
	const b = Math.max(1, Math.min(120, parseIdNumber(rawB) ?? b0));
	const g = gcd(a, b);
	const k = lcm(a, b);
	const fa = factorsOf(a);
	const fb = factorsOf(b);
	const common = fa.filter((x) => fb.includes(x));
	const steps = euclidSteps(a, b);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			story ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal text-muted",
				children: story
			}) : null,
			mode === "choose" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: view === "gcd" ? "default" : "secondary",
					onClick: () => setView("gcd"),
					children: "Ini berbagi — FPB"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: view === "lcm" ? "default" : "secondary",
					onClick: () => setView("lcm"),
					children: "Ini bertemu — KPK"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["A", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5 w-24",
						inputMode: "numeric",
						value: rawA,
						onChange: (e) => setRawA(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["B", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5 w-24",
						inputMode: "numeric",
						value: rawB,
						onChange: (e) => setRawB(e.target.value)
					})]
				})]
			}),
			(mode === "gcd" || view === "gcd") && mode !== "lcm" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactorList, {
							label: `Faktor ${a}`,
							items: fa,
							common,
							max: g
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactorList, {
							label: `Faktor ${b}`,
							items: fb,
							common,
							max: g
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-md bg-primary-soft px-3 py-2 text-sm",
						children: [
							"Irisan: ",
							common.join(", ") || "—",
							". Terbesar ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: g
							}),
							" — itu FPB."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
							children: "Langkah Euclid"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "space-y-1 text-sm tabular-nums text-fg",
							children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								s.a,
								" = ",
								s.q,
								" × ",
								s.b,
								" + ",
								s.r,
								s.r === 0 ? " → sisa 0, berhenti." : ""
							] }, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								"Pembagi terakhir sebelum sisa 0 adalah FPB = ",
								g,
								". Sisa adalah yang tersisa setelah kotak besar menempel."
							]
						})
					] })
				]
			}) : null,
			(mode === "lcm" || view === "lcm") && mode !== "gcd" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LcmHops, {
				a,
				b,
				k
			}) : null,
			mode === "choose" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Angka yang sama bisa menjawab ",
					g,
					" (FPB, berbagi) atau ",
					k,
					" (KPK, bertemu). Pilih pertanyaan dulu."
				]
			}) : null
		]
	});
}
function FactorList({ label, items, common, max }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-bg-elevated p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1.5",
			children: items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("rounded-full px-2 py-0.5 text-sm tabular-nums", n === max ? "bg-primary text-primary-fg" : common.includes(n) ? "bg-primary-soft text-primary" : "bg-surface text-muted"),
				children: n
			}, n))
		})]
	});
}
function LcmHops({ a, b, k }) {
	const max = Math.min(Math.max(k * 2, a * 3, b * 3), 72);
	const ticks = (0, import_react.useMemo)(() => Array.from({ length: max + 1 }, (_, i) => i), [max]);
	const marksA = new Set(ticks.filter((t) => t > 0 && t % a === 0));
	const marksB = new Set(ticks.filter((t) => t > 0 && t % b === 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Loncatan ",
					a,
					" dan ",
					b,
					". Titik yang diinjak berdua — kelipatan persekutuan. Yang pertama: KPK = ",
					k,
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-[640px] space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HopRow, {
						label: `+${a}`,
						ticks,
						marks: marksA,
						other: marksB
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HopRow, {
						label: `+${b}`,
						ticks,
						marks: marksB,
						other: marksA
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Rumus ringkas: ",
					a,
					" × ",
					b,
					" / FPB(",
					a,
					",",
					b,
					") = ",
					a * b,
					" / ",
					gcd(a, b),
					" = ",
					k,
					". Rumus ini menyingkat irisan loncatan, bukan menggantinya."
				]
			})
		]
	});
}
function HopRow({ label, ticks, marks, other }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-8 shrink-0 text-xs font-medium text-muted tabular-nums",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-1",
			children: ticks.map((t) => {
				const on = marks.has(t);
				const both = on && other.has(t);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("size-2 rounded-full", both ? "bg-primary" : on ? "bg-fg" : "bg-surface-2") }), t % 6 === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 text-[9px] text-subtle tabular-nums",
						children: formatId(t)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-3" })]
				}, t);
			})
		})]
	});
}
var LABELS = placeLabels(6);
function DigitColumn({ label, short, value, highlight, onInc, onDec }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex min-w-0 flex-1 flex-col items-center gap-2 rounded-lg border px-1 py-3", highlight ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-14 w-full max-w-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full flex-col-reverse gap-0.5",
					children: Array.from({ length: 9 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-[5px] rounded-full", i < value ? "bg-primary" : "bg-surface-2") }, i))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-2xl tabular-nums leading-none",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-0.5 text-center text-[10px] font-medium uppercase tracking-wide text-muted leading-tight",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden sm:inline",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sm:hidden",
					children: short
				})]
			}),
			onInc && onDec ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Kurangi ${label}`,
					onClick: onDec,
					className: "flex size-9 items-center justify-center rounded-sm border border-border bg-bg text-fg hover:bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Tambah ${label}`,
					onClick: onInc,
					className: "flex size-9 items-center justify-center rounded-sm border border-border bg-bg text-fg hover:bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
				})]
			}) : null
		]
	});
}
function Board({ value, onChange, highlightIndex, readOnly }) {
	const digits = digitsOf(value, 6);
	const setDigit = (i, next) => {
		if (!onChange) return;
		const copy = [...digits];
		copy[i] = Math.min(9, Math.max(0, next));
		onChange(fromDigits(copy));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1.5 sm:gap-2",
		children: LABELS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigitColumn, {
			label: p.long,
			short: p.short,
			value: digits[i] ?? 0,
			highlight: highlightIndex === i,
			onInc: readOnly ? void 0 : () => setDigit(i, (digits[i] ?? 0) + 1),
			onDec: readOnly ? void 0 : () => setDigit(i, (digits[i] ?? 0) - 1)
		}, p.key))
	});
}
function firstDiffIndex(a, b) {
	const da = digitsOf(a, 6);
	const db = digitsOf(b, 6);
	for (let i = 0; i < 6; i++) if (da[i] !== db[i]) return i;
	return null;
}
function OperatePanel({ a0, b0, op0 }) {
	const [a, setA] = (0, import_react.useState)(a0);
	const [b, setB] = (0, import_react.useState)(b0);
	const [op, setOp] = (0, import_react.useState)(op0);
	const [col, setCol] = (0, import_react.useState)(-1);
	const [carry, setCarry] = (0, import_react.useState)(0);
	const [out, setOut] = (0, import_react.useState)(Array(7).fill(-1));
	const [msg, setMsg] = (0, import_react.useState)("Mulai dari satuan, di kanan.");
	const da = digitsOf(a, 6);
	const db = digitsOf(b, 6);
	const reset = (na = a, nb = b, nop = op) => {
		setA(na);
		setB(nb);
		setOp(nop);
		setCol(-1);
		setCarry(0);
		setOut(Array(7).fill(-1));
		setMsg("Mulai dari satuan, di kanan.");
	};
	const next = () => {
		const i = col + 1;
		if (i > 6) return;
		const fromRight = 5 - i;
		if (i === 6) {
			if (carry) {
				const nextOut = [...out];
				nextOut[0] = carry;
				setOut(nextOut);
				setMsg(`Sisa simpanan ${carry} menulis digit baru di kiri. Hasil ${formatId(op === "+" ? a + b : a - b)}.`);
			} else setMsg(`Selesai. Hasil ${formatId(op === "+" ? a + b : a - b)}.`);
			setCol(6);
			setCarry(0);
			return;
		}
		const av = da[fromRight] ?? 0;
		const bv = db[fromRight] ?? 0;
		const nextOut = [...out];
		if (op === "+") {
			const sum = av + bv + carry;
			const digit = sum % 10;
			const nextCarry = Math.floor(sum / 10);
			nextOut[fromRight + 1] = digit;
			setOut(nextOut);
			setCarry(nextCarry);
			setCol(i);
			setMsg(nextCarry ? `${av} + ${bv}${carry ? ` + simpanan ${carry}` : ""} = ${sum}. Tulis ${digit}, ikat 10 menjadi 1 ${LABELS[fromRight - 1]?.long ?? "di kiri"}.` : `${av} + ${bv}${carry ? ` + simpanan ${carry}` : ""} = ${sum}. Tulis ${digit}, tidak ada ikatan.`);
		} else {
			let top = av - carry;
			let borrowed = 0;
			if (top < bv) {
				top += 10;
				borrowed = 1;
			}
			const digit = top - bv;
			nextOut[fromRight + 1] = digit;
			setOut(nextOut);
			setCarry(borrowed);
			setCol(i);
			setMsg(borrowed ? `${av}${carry ? ` (sudah dipinjam ${carry})` : ""} kurang dari ${bv}, jadi pinjam 10. ${top} − ${bv} = ${digit}. Rumah kiri akan berkurang 1.` : `${av}${carry ? ` − pinjaman ${carry}` : ""} − ${bv} = ${digit}.`);
		}
	};
	const resultDigits = out;
	const expected = op === "+" ? a + b : a - b;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: op === "+" ? "default" : "secondary",
						onClick: () => reset(a, b, "+"),
						children: "Jumlah"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: op === "-" ? "default" : "secondary",
						onClick: () => reset(Math.max(a, b), Math.min(a, b), "-"),
						children: "Kurang"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => reset(),
						children: "Ulangi langkah"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-72 text-center font-display text-lg tabular-nums",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-[10px] font-medium uppercase tracking-wide text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-8" }), LABELS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-1 pb-2",
							children: p.short
						}, p.key))]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {}), da.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1",
							children: d
						}, `a${i}`))] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-muted",
							children: op
						}), db.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1",
							children: d
						}, `b${i}`))] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {}), LABELS.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-primary",
								children: resultDigits[i + 1] >= 0 ? resultDigits[i + 1] : "·"
							}, `o${i}`))]
						})
					] })]
				}), resultDigits[0] > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Digit tambahan di kiri: ",
						resultDigits[0],
						". Hasil ",
						formatId(expected),
						"."
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal text-muted",
				children: msg
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: next,
				disabled: col >= 6,
				children: col < 0 ? "Jumlahkan satuan" : col >= 5 ? "Selesaikan" : "Kolom berikutnya"
			})
		]
	});
}
function PlaceValueLab({ mode, start = 125450, other = 12405, op = "+" }) {
	const [n, setN] = (0, import_react.useState)(start);
	const [m, setM] = (0, import_react.useState)(other);
	const diff = (0, import_react.useMemo)(() => firstDiffIndex(n, m), [n, m]);
	if (mode === "operate") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OperatePanel, {
		a0: start,
		b0: other,
		op0: op
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
				value: n,
				onChange: setN,
				highlightIndex: mode === "compare" ? diff : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-3xl tabular-nums tracking-tight",
					children: formatId(n)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: numberToWordsId(n)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-mono text-xs text-subtle",
					children: expandedForm(n)
				})
			] }),
			mode === "compare" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 border-t border-border pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
						value: m,
						onChange: setM,
						highlightIndex: diff
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-3xl tabular-nums tracking-tight",
						children: formatId(m)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: numberToWordsId(m)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md bg-primary-soft px-3 py-2 text-sm text-fg",
						children: n === m ? "Sama besar. Tidak ada rumah yang berbeda." : diff === null ? "" : n > m ? `${formatId(n)} lebih besar. Rumah pertama yang berbeda dari kiri: ${LABELS[diff]?.long}.` : `${formatId(m)} lebih besar. Rumah pertama yang berbeda dari kiri: ${LABELS[diff]?.long}.`
					})
				]
			}) : null
		]
	});
}
var PLACES = [
	{
		value: 10,
		label: "Puluhan"
	},
	{
		value: 100,
		label: "Ratusan"
	},
	{
		value: 1e3,
		label: "Ribuan"
	},
	{
		value: 1e4,
		label: "Puluhan ribu"
	},
	{
		value: 1e5,
		label: "Ratusan ribu"
	}
];
function RoundLab({ start = 48750 }) {
	const [raw, setRaw] = (0, import_react.useState)(String(start));
	const [place, setPlace] = (0, import_react.useState)(1e3);
	const n = parseIdNumber(raw) ?? start;
	const rounded = roundToPlace(n, place);
	const low = Math.floor(n / place) * place;
	const high = low + place;
	const mid = low + place / 2;
	const t = high === low ? .5 : (n - low) / (high - low);
	const note = (0, import_react.useMemo)(() => {
		if (n === rounded) return "Angka ini sudah tepat di satuan yang dipilih.";
		if (n === mid) return `Tepat di tengah ${formatId(low)} dan ${formatId(high)}. Kesepakatan sekolah: naik ke ${formatId(high)}.`;
		if (n > mid) return `Lebih dekat ke ${formatId(high)} (jarak ${formatId(high - n)} vs ${formatId(n - low)}).`;
		return `Lebih dekat ke ${formatId(low)} (jarak ${formatId(n - low)} vs ${formatId(high - n)}).`;
	}, [
		n,
		rounded,
		mid,
		low,
		high
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block flex-1 text-sm font-medium",
					children: ["Bilangan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						inputMode: "numeric",
						value: raw,
						onChange: (e) => setRaw(e.target.value)
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PLACES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: place === p.value ? "default" : "secondary",
					onClick: () => setPlace(p.value),
					children: p.label
				}, p.value))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-border bg-bg-elevated px-4 py-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-8 right-0 left-0 h-px bg-border-strong" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-6 left-0 h-5 w-px bg-border-strong" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-6 right-0 left-1/2 h-5 w-px -translate-x-1/2 bg-subtle" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-6 right-0 h-5 w-px bg-border-strong" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-5 size-3 -translate-x-1/2 rounded-full bg-primary",
							style: { left: `${Math.min(100, Math.max(0, t * 100))}%` }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-0 left-0 text-xs text-muted tabular-nums",
							children: formatId(low)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-0 left-1/2 -translate-x-1/2 text-xs text-subtle tabular-nums",
							children: formatId(mid)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-0 right-0 text-xs text-muted tabular-nums",
							children: formatId(high)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("absolute top-11 -translate-x-1/2 font-display text-sm tabular-nums", t > .85 ? "translate-x-[-90%]" : t < .15 ? "translate-x-0" : ""),
							style: { left: `${Math.min(100, Math.max(0, t * 100))}%` },
							children: formatId(n)
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-2xl tabular-nums",
				children: [
					formatId(n),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-2 text-subtle",
						children: "→"
					}),
					formatId(rounded)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-normal text-muted",
				children: note
			})
		]
	});
}
function Explore({ config }) {
	switch (config.lab) {
		case "place-value": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceValueLab, {
			mode: config.mode,
			start: config.start,
			other: config.other,
			op: config.op
		});
		case "round": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundLab, { start: config.start });
		case "factor": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FactorLab, {
			mode: config.mode,
			start: config.start
		});
		case "gcd-lcm": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GcdLcmLab, {
			mode: config.mode,
			a: config.a,
			b: config.b,
			story: config.story
		});
		case "fraction": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FractionLab, {
			mode: config.mode,
			a: config.a,
			b: config.b
		});
		default: return null;
	}
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md border border-border bg-bg-elevated px-3 py-2.5 text-base text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:opacity-50", className),
		...props
	});
}
var PHASES = [
	{
		id: "mindful",
		label: "Niat"
	},
	{
		id: "story",
		label: "Cerita"
	},
	{
		id: "explore",
		label: "Gali"
	},
	{
		id: "practice",
		label: "Latihan"
	},
	{
		id: "reflect",
		label: "Cermin"
	}
];
function LessonPlayer({ lesson }) {
	const [phase, setPhase] = (0, import_react.useState)(0);
	const [notice, setNotice] = (0, import_react.useState)("");
	const [customNotice, setCustomNotice] = (0, import_react.useState)("");
	const [storyThought, setStoryThought] = (0, import_react.useState)("");
	const [reflections, setReflections] = (0, import_react.useState)(["", ""]);
	const [practice, setPractice] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const saveLesson = useProgress((s) => s.saveLesson);
	const addReflection = useProgress((s) => s.addReflection);
	const jalur = getJalur(lesson.jalurId);
	const nxt = nextLesson(lesson.id);
	const noticeValue = notice === "__custom" ? customNotice : notice;
	const canNext = (0, import_react.useMemo)(() => {
		if (phase === 0) return noticeValue.trim().length > 0;
		if (phase === 1) return storyThought.trim().length > 0;
		if (phase === 3) return practice !== null;
		return true;
	}, [
		phase,
		noticeValue,
		storyThought,
		practice
	]);
	const persist = () => {
		const text = reflections.filter((t) => t.trim()).join("\n\n");
		saveLesson(lesson.id, {
			at: (/* @__PURE__ */ new Date()).toISOString(),
			practiceCorrect: practice?.correct ?? 0,
			practiceTotal: practice?.total ?? lesson.practice.length,
			reflected: text.length > 0,
			notice: noticeValue,
			storyThought
		});
		if (text) addReflection({
			lessonId: lesson.id,
			jalurId: lesson.jalurId,
			text
		});
		setSaved(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl px-4 pb-24 pt-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/jalur/$jalurId",
					params: { jalurId: lesson.jalurId },
					className: "flex size-11 items-center justify-center rounded-md border border-border bg-bg-elevated text-fg hover:bg-surface",
					"aria-label": "Kembali ke jalur",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted",
						children: [
							jalur?.title,
							" · Pelajaran ",
							lesson.order
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-xl leading-snug sm:text-2xl",
						children: lesson.title
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mb-8 flex gap-1",
				children: PHASES.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							if (i <= phase) setPhase(i);
						},
						className: "w-full text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-1 rounded-full", i <= phase ? "bg-primary" : "bg-surface-2") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("mt-2 hidden text-[10px] font-medium uppercase tracking-wide sm:block", i === phase ? "text-fg" : "text-subtle"),
							children: p.label
						})]
					})
				}, p.id))
			}),
			phase === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-primary",
						children: "Berkesadaran"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-snug",
						children: lesson.mindful.notice
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: lesson.mindful.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [lesson.mindful.chips.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setNotice(c),
							className: cn("rounded-lg border px-4 py-3 text-left text-sm leading-snug", notice === c ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated hover:bg-surface"),
							children: c
						}, c)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setNotice("__custom"),
							className: cn("rounded-lg border px-4 py-3 text-left text-sm", notice === "__custom" ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated hover:bg-surface"),
							children: "Aku ingin menulis sendiri"
						})]
					}),
					notice === "__custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: customNotice,
						onChange: (e) => setCustomNotice(e.target.value),
						placeholder: "Yang kuperhatikan…"
					}) : null
				]
			}) : null,
			phase === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-primary",
						children: "Bermakna"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl leading-snug",
						children: lesson.story.title
					}),
					lesson.story.body.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-normal text-fg/90",
						children: p
					}, p)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg border border-border bg-surface px-4 py-3 text-sm leading-normal",
						children: lesson.story.ask
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: storyThought,
						onChange: (e) => setStoryThought(e.target.value),
						placeholder: "Pikiranmu, belum perlu benar…"
					})
				]
			}) : null,
			phase === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-primary",
						children: "Mendalam"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-normal text-muted",
						children: lesson.explore.caption
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border bg-bg-elevated p-4 sm:p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Explore, { config: lesson.explore })
					})
				]
			}) : null,
			phase === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rise-in",
				children: practice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xl",
						children: [
							practice.correct,
							" dari ",
							practice.total,
							" tepat pada percobaan pertama yang dikunci."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Yang penting bukan skor. Baca lagi penjelasan pada soal yang terasa goyah."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PracticeQuiz, {
					items: lesson.practice,
					onDone: (correct, total) => setPractice({
						correct,
						total
					})
				})
			}) : null,
			phase === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rise-in space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-primary",
						children: "Cermin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-snug",
						children: lesson.intent
					}),
					lesson.reflect.prompts.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm leading-normal text-fg",
							children: p
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: reflections[i] ?? "",
							onChange: (e) => setReflections((prev) => {
								const next = [...prev];
								next[i] = e.target.value;
								return next;
							}),
							placeholder: "Tulis pelan-pelan"
						})]
					}, p)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md bg-primary-soft px-4 py-3 text-sm leading-normal",
						children: lesson.reflect.takeaway
					}),
					saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row",
						children: [nxt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/belajar/$lessonId",
								params: { lessonId: nxt.id },
								children: ["Pelajaran berikutnya", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/jalur/$jalurId",
								params: { jalurId: lesson.jalurId },
								children: "Kembali ke jalur"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cermin",
								children: "Buka cermin"
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: persist,
						children: "Simpan refleksi"
					})
				]
			}) : null,
			phase < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setPhase((p) => Math.max(0, p - 1)),
					disabled: phase === 0,
					children: "Kembali"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setPhase((p) => p + 1),
					disabled: !canNext,
					children: ["Lanjut", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})]
			}) : null
		]
	});
}
function BelajarPage() {
	const { lessonId } = Route$2.useParams();
	const lesson = getLesson(lessonId);
	if (!lesson) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl",
			children: "Pelajaran tidak ada"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-block text-sm text-primary",
			children: "Beranda"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonPlayer, { lesson });
}
//#endregion
export { BelajarPage as component };
