import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Check, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { o as cn, r as Route$1 } from "./router-BpXJR4av.mjs";
import { t as Button } from "./button-CSTjc5OR.mjs";
import { a as lessonsFor, r as getJalur } from "./content-pItgeMuQ.mjs";
import { n as useProgress } from "./progress-COz1HOFS.mjs";
import { n as Card, r as CardContent, s as Progress, t as Badge } from "./progress-DZx-qzbq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jalur._jalurId-Ch3A7_3W.js
var import_jsx_runtime = require_jsx_runtime();
function JalurPage() {
	const { jalurId } = Route$1.useParams();
	const jalur = getJalur(jalurId);
	const completed = useProgress((s) => s.completed);
	if (!jalur) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl",
			children: "Jalur tidak ada"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-block text-sm text-primary",
			children: "Beranda"
		})]
	});
	const lessons = lessonsFor(jalur.id);
	const done = lessons.filter((l) => completed[l.id]).length;
	const next = lessons.find((l) => !completed[l.id]) ?? lessons[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.18em] text-primary",
				children: "Jalur belajar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl tracking-tight",
				children: jalur.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: jalur.subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-base leading-normal text-fg/90",
				children: jalur.why
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-lg text-primary",
				children: jalur.pillar
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 max-w-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex justify-between text-xs font-medium uppercase tracking-wide text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pelajaran" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [
							done,
							"/",
							lessons.length
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: done / lessons.length * 100 })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/belajar/$lessonId",
						params: { lessonId: next.id },
						children: [done === 0 ? "Mulai pelajaran 1" : "Lanjutkan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/latihan/$jalurId",
						params: { jalurId: jalur.id },
						children: "Latihan campuran"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10 space-y-3",
				children: lessons.map((l) => {
					const rec = completed[l.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/belajar/$lessonId",
						params: { lessonId: l.id },
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "transition-colors hover:border-border-strong",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "flex items-start gap-4 p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cn("mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full border text-sm tabular-nums", rec ? "border-primary bg-primary-soft text-primary" : "border-border text-muted"),
									children: rec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : l.order
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "font-display text-lg leading-snug",
											children: l.title
										}), rec?.reflected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Dicerminkan" }) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-normal text-muted",
										children: l.intent
									})]
								})]
							})
						})
					}) }, l.id);
				})
			})
		]
	});
}
//#endregion
export { JalurPage as component };
