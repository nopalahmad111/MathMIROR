import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-COz1HOFS.js
var todayKey = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var useProgress = create()(persist((set, get) => ({
	learnerName: "",
	niat: "",
	onboardingDone: false,
	lastMindfulAt: null,
	mindfulStarts: 0,
	completed: {},
	reflections: [],
	setName: (learnerName) => set({ learnerName }),
	setNiat: (niat) => set({ niat }),
	completeOnboarding: (learnerName, niat) => set({
		learnerName: learnerName.trim(),
		niat,
		onboardingDone: true,
		lastMindfulAt: todayKey(),
		mindfulStarts: get().mindfulStarts + 1
	}),
	markMindful: () => set({
		lastMindfulAt: todayKey(),
		mindfulStarts: get().mindfulStarts + 1
	}),
	saveLesson: (lessonId, record) => set({ completed: {
		...get().completed,
		[lessonId]: record
	} }),
	addReflection: (entry) => set({ reflections: [{
		...entry,
		id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
		at: (/* @__PURE__ */ new Date()).toISOString()
	}, ...get().reflections].slice(0, 40) }),
	resetAll: () => set({
		learnerName: "",
		niat: "",
		onboardingDone: false,
		lastMindfulAt: null,
		mindfulStarts: 0,
		completed: {},
		reflections: []
	})
}), { name: "bening-progress-v1" }));
function mindfulDoneToday(lastMindfulAt) {
	return lastMindfulAt === todayKey();
}
//#endregion
export { useProgress as n, mindfulDoneToday as t };
