import { createFileRoute } from "@tanstack/react-router";
import { PILLARS } from "@/lib/content";

export const Route = createFileRoute("/panduan")({ component: PanduanPage });

function PanduanPage() {
  return (
    <main className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">Untuk guru dan orang tua</p>
      <h1 className="mt-3 font-display text-4xl tracking-tight">Tiga napas belajar</h1>
      <p className="mt-4 text-base leading-normal text-muted">
        Bening mengikuti pembelajaran mendalam: berkesadaran (mindful), bermakna (meaningful), dan menggali
        mengapa (deep). Anak kelas 5 MI tidak hanya dilatih cepat — ia dilatih melihat.
      </p>

      <section className="mt-12 space-y-10">
        {PILLARS.map((p) => (
          <article key={p.id}>
            <h2 className="font-display text-2xl">{p.title}</h2>
            <p className="mt-2 text-base leading-normal text-fg/90">{p.body}</p>
          </article>
        ))}
      </section>

      <section className="mt-12 space-y-4">
        <h2 className="font-display text-2xl">Bagaimana sebuah pelajaran berjalan</h2>
        <ol className="list-decimal space-y-3 pl-5 text-sm leading-normal text-fg/90">
          <li>
            <span className="font-medium">Niat.</span> Anak memperhatikan sesuatu yang kecil — sering kali
            miskonsepsi — sebelum rumus muncul.
          </li>
          <li>
            <span className="font-medium">Cerita.</span> Hana dan Rafi di madrasah: zakat, barisan, resep, jadwal
            mengaji. Pengetahuan menempel pada kehidupan.
          </li>
          <li>
            <span className="font-medium">Gali.</span> Papan nilai tempat, loncatan KPK, batang pecahan. Anak
            mengubah-ubah, memperhatikan apa yang tetap dan apa yang berubah.
          </li>
          <li>
            <span className="font-medium">Latihan.</span> Sedikit soal, banyak penjelasan. Salah bukan gagal —
            pintu ke mengapa.
          </li>
          <li>
            <span className="font-medium">Cermin.</span> Dua pertanyaan metakognitif. Jejaknya tersimpan di
            perangkat ini, bukan di akun.
          </li>
        </ol>
      </section>

      <section className="mt-12 space-y-3">
        <h2 className="font-display text-2xl">Cakupan materi</h2>
        <ul className="space-y-2 text-sm leading-normal text-muted">
          <li>Bilangan cacah hingga ratusan ribu — nilai tempat, banding, operasi, pembulatan.</li>
          <li>FPB dan KPK — faktor, prima, berbagi vs bertemu, memilih alat.</li>
          <li>Pecahan — makna, senilai, banding, jumlah-kurang, konteks kehidupan.</li>
        </ul>
      </section>

      <p className="mt-12 text-sm leading-normal text-muted">
        Progres tersimpan hanya di peramban ini. Cocok untuk stasiun kelas, belajar mandiri, atau pendampingan
        di rumah. Tidak perlu akun.
      </p>
    </main>
  );
}
