import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { getJalur, lessonsFor } from "@/lib/content";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/jalur/$jalurId")({ component: JalurPage });

function JalurPage() {
  const { jalurId } = Route.useParams();
  const jalur = getJalur(jalurId);
  const completed = useProgress((s) => s.completed);

  if (!jalur) {
    return (
      <main className="mx-auto max-w-lg px-6 py-16 text-center">
        <h1 className="font-display text-2xl">Jalur tidak ada</h1>
        <Link to="/" className="mt-4 inline-block text-sm text-primary">
          Beranda
        </Link>
      </main>
    );
  }

  const lessons = lessonsFor(jalur.id);
  const done = lessons.filter((l) => completed[l.id]).length;
  const next = lessons.find((l) => !completed[l.id]) ?? lessons[0];

  return (
    <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-12">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">Jalur belajar</p>
      <h1 className="mt-3 font-display text-4xl tracking-tight">{jalur.title}</h1>
      <p className="mt-2 text-muted">{jalur.subtitle}</p>
      <p className="mt-5 max-w-2xl text-base leading-normal text-fg/90">{jalur.why}</p>
      <p className="mt-3 font-display text-lg text-primary">{jalur.pillar}</p>

      <div className="mt-8 max-w-sm">
        <div className="mb-2 flex justify-between text-xs font-medium uppercase tracking-wide text-muted">
          <span>Pelajaran</span>
          <span className="tabular-nums">
            {done}/{lessons.length}
          </span>
        </div>
        <Progress value={(done / lessons.length) * 100} />
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {next ? (
          <Button asChild>
            <Link to="/belajar/$lessonId" params={{ lessonId: next.id }}>
              {done === 0 ? "Mulai pelajaran 1" : "Lanjutkan"}
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        ) : null}
        <Button variant="secondary" asChild>
          <Link to="/latihan/$jalurId" params={{ jalurId: jalur.id }}>
            Latihan campuran
          </Link>
        </Button>
      </div>

      <ol className="mt-10 space-y-3">
        {lessons.map((l) => {
          const rec = completed[l.id];
          return (
            <li key={l.id}>
              <Link to="/belajar/$lessonId" params={{ lessonId: l.id }} className="block">
                <Card className="transition-colors hover:border-border-strong">
                  <CardContent className="flex items-start gap-4 p-5">
                    <div
                      className={cn(
                        "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full border text-sm tabular-nums",
                        rec ? "border-primary bg-primary-soft text-primary" : "border-border text-muted",
                      )}
                    >
                      {rec ? <Check className="size-4" /> : l.order}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="font-display text-lg leading-snug">{l.title}</h2>
                        {rec?.reflected ? <Badge>Dicerminkan</Badge> : null}
                      </div>
                      <p className="mt-1 text-sm leading-normal text-muted">{l.intent}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </li>
          );
        })}
      </ol>
    </main>
  );
}
