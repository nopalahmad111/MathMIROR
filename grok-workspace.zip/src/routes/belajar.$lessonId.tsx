import { createFileRoute, Link } from "@tanstack/react-router";
import { LessonPlayer } from "@/components/lesson-player";
import { getLesson } from "@/lib/content";

export const Route = createFileRoute("/belajar/$lessonId")({ component: BelajarPage });

function BelajarPage() {
  const { lessonId } = Route.useParams();
  const lesson = getLesson(lessonId);
  if (!lesson) {
    return (
      <main className="mx-auto max-w-lg px-6 py-16 text-center">
        <h1 className="font-display text-2xl">Pelajaran tidak ada</h1>
        <Link to="/" className="mt-4 inline-block text-sm text-primary">
          Beranda
        </Link>
      </main>
    );
  }
  return <LessonPlayer lesson={lesson} />;
}
