import { createFileRoute, Link } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { getLesson } from "@/lib/content";
import { useProgress } from "@/lib/progress";

export const Route = createFileRoute("/cermin")({ component: CerminPage });

function CerminPage() {
  const reflections = useProgress((s) => s.reflections);
  const resetAll = useProgress((s) => s.resetAll);

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">Berkesadaran</p>
      <h1 className="mt-3 font-display text-4xl tracking-tight">Cermin</h1>
      <p className="mt-3 max-w-xl text-base leading-normal text-muted">
        Catatan yang kamu tulis setelah belajar. Bukan nilai. Jejak nalar.
      </p>

      {reflections.length === 0 ? (
        <p className="mt-10 text-sm text-muted">
          Belum ada refleksi. Selesaikan satu pelajaran sampai langkah Cermin.
        </p>
      ) : (
        <ol className="mt-10 space-y-4">
          {reflections.map((r) => {
            const lesson = getLesson(r.lessonId);
            return (
              <li key={r.id}>
                <Card>
                  <CardContent className="p-5">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted">
                      {lesson?.title ?? r.lessonId}
                    </p>
                    <p className="mt-3 whitespace-pre-wrap text-sm leading-normal">{r.text}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <p className="text-xs text-subtle">
                        {new Date(r.at).toLocaleDateString("id-ID", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}
                      </p>
                      {lesson ? (
                        <Link
                          to="/belajar/$lessonId"
                          params={{ lessonId: lesson.id }}
                          className="text-xs font-medium text-primary"
                        >
                          Buka lagi
                        </Link>
                      ) : null}
                    </div>
                  </CardContent>
                </Card>
              </li>
            );
          })}
        </ol>
      )}

      <button
        type="button"
        className="mt-16 text-xs text-subtle underline-offset-4 hover:text-muted hover:underline"
        onClick={() => {
          if (window.confirm("Hapus nama, niat, dan semua jejak belajar di perangkat ini?")) resetAll();
        }}
      >
        Mulai ulang jejak di perangkat ini
      </button>
    </main>
  );
}
