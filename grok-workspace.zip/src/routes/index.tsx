import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Mark } from "@/components/mark";
import { Onboarding } from "@/components/onboarding";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { JALUR, PILLARS, lessonsFor } from "@/lib/content";
import { greetingId } from "@/lib/greeting";
import { mindfulDoneToday, useProgress } from "@/lib/progress";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const onboardingDone = useProgress((s) => s.onboardingDone);
  const learnerName = useProgress((s) => s.learnerName);
  const niat = useProgress((s) => s.niat);
  const completed = useProgress((s) => s.completed);
  const lastMindfulAt = useProgress((s) => s.lastMindfulAt);
  const markMindful = useProgress((s) => s.markMindful);
  const reflections = useProgress((s) => s.reflections);

  if (!onboardingDone) {
    return <Onboarding />;
  }

  const totalLessons = JALUR.reduce((n, j) => n + lessonsFor(j.id).length, 0);
  const doneCount = Object.keys(completed).length;
  const greeted = `${greetingId()}${learnerName ? `, ${learnerName}` : ""}`;

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      <section className="star-field -mx-4 rounded-none px-4 py-8 sm:-mx-0 sm:rounded-2xl sm:border sm:border-border sm:px-10 sm:py-12">
        <div className="flex items-center gap-3 text-primary">
          <Mark className="size-9" />
          <span className="text-xs font-medium uppercase tracking-[0.18em]">Kelas 5 MI</span>
        </div>
        <h1 className="mt-5 font-display text-4xl leading-tight tracking-tight sm:text-5xl">{greeted}.</h1>
        <p className="mt-3 max-w-xl text-base leading-normal text-muted">
          {niat || "Belajar berkesadaran, bermakna, dan mendalam."}
        </p>
        <div className="mt-8 max-w-sm">
          <div className="mb-2 flex justify-between text-xs font-medium uppercase tracking-wide text-muted">
            <span>Kedalaman jalur</span>
            <span className="tabular-nums">
              {doneCount}/{totalLessons} pelajaran
            </span>
          </div>
          <Progress value={totalLessons ? (doneCount / totalLessons) * 100 : 0} />
        </div>
      </section>

      {!mindfulDoneToday(lastMindfulAt) ? (
        <div className="mt-6 flex flex-col gap-3 rounded-xl border border-border bg-bg-elevated p-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm leading-normal text-muted">
            Satu napas sebelum angka. Pikiran yang tenang lebih mudah paham.
          </p>
          <Button variant="secondary" onClick={markMindful}>
            Sudah kuambil
          </Button>
        </div>
      ) : null}

      <section className="mt-12">
        <h2 className="font-display text-2xl tracking-tight">Tiga jalur</h2>
        <p className="mt-1 text-sm text-muted">Bilangan cacah, FPB & KPK, pecahan — kurikulum kelas 5.</p>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {JALUR.map((j) => {
            const lessons = lessonsFor(j.id);
            const done = lessons.filter((l) => completed[l.id]).length;
            return (
              <Link key={j.id} to="/jalur/$jalurId" params={{ jalurId: j.id }} className="group block">
                <Card className="h-full transition-colors group-hover:border-border-strong">
                  <CardHeader>
                    <Badge variant="outline">
                      {done}/{lessons.length}
                    </Badge>
                    <CardTitle className="mt-3">{j.title}</CardTitle>
                    <CardDescription>{j.subtitle}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-normal text-muted">{j.blurb}</p>
                    <Progress className="mt-5" value={(done / lessons.length) * 100} />
                    <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                      Masuk jalur
                      <ArrowRight className="size-3.5" />
                    </span>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="mt-14 grid gap-8 md:grid-cols-3">
        {PILLARS.map((p) => (
          <div key={p.id}>
            <h3 className="font-display text-lg">{p.title}</h3>
            <p className="mt-2 text-sm leading-normal text-muted">{p.body}</p>
          </div>
        ))}
      </section>

      {reflections[0] ? (
        <section className="mt-14">
          <div className="mb-4 flex items-baseline justify-between">
            <h2 className="font-display text-2xl">Cermin terakhir</h2>
            <Link to="/cermin" className="text-sm font-medium text-primary">
              Semua
            </Link>
          </div>
          <Card>
            <CardContent className="p-5">
              <p className="text-sm leading-normal whitespace-pre-wrap">{reflections[0].text}</p>
              <p className="mt-3 text-xs text-subtle">
                {new Date(reflections[0].at).toLocaleDateString("id-ID", {
                  day: "numeric",
                  month: "long",
                })}
              </p>
            </CardContent>
          </Card>
        </section>
      ) : null}
    </main>
  );
}
