import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PracticeQuiz } from "@/components/practice-quiz";
import { Button } from "@/components/ui/button";
import { getJalur } from "@/lib/content";
import type { JalurId } from "@/lib/content/types";
import { generatePractice } from "@/lib/generators";

export const Route = createFileRoute("/latihan/$jalurId")({ component: LatihanPage });

function LatihanPage() {
  const { jalurId } = Route.useParams();
  const jalur = getJalur(jalurId);
  const [seed, setSeed] = useState(0);
  const [done, setDone] = useState<{ correct: number; total: number } | null>(null);
  const items = useMemo(
    () => (jalur ? generatePractice(jalur.id as JalurId, 6) : []),
    [jalur, seed],
  );

  if (!jalur) {
    return (
      <main className="mx-auto max-w-lg px-6 py-16 text-center">
        <h1 className="font-display text-2xl">Jalur tidak ada</h1>
        <Link to="/" className="mt-4 inline-block text-sm text-primary">
          Beranda
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-primary">Latihan campuran</p>
      <h1 className="mt-3 font-display text-3xl tracking-tight">{jalur.title}</h1>
      <p className="mt-2 text-sm text-muted">
        Soal baru setiap putaran. Baca penjelasan meski sudah tepat — itu bagian mendalamnya.
      </p>
      <div className="mt-8 rounded-xl border border-border bg-bg-elevated p-5">
        {done ? (
          <div className="space-y-4">
            <p className="font-display text-2xl">
              {done.correct} dari {done.total} tepat.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={() => {
                  setDone(null);
                  setSeed((s) => s + 1);
                }}
              >
                Putaran baru
              </Button>
              <Button variant="secondary" asChild>
                <Link to="/jalur/$jalurId" params={{ jalurId: jalur.id }}>
                  Kembali ke jalur
                </Link>
              </Button>
            </div>
          </div>
        ) : (
          <PracticeQuiz items={items} onDone={(correct, total) => setDone({ correct, total })} />
        )}
      </div>
    </main>
  );
}
