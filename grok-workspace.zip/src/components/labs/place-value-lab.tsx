import { Minus, Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  digitsOf,
  expandedForm,
  formatId,
  fromDigits,
  numberToWordsId,
  placeLabels,
} from "@/lib/math";
import { cn } from "@/lib/utils";

const LABELS = placeLabels(6);

function DigitColumn({
  label,
  short,
  value,
  highlight,
  onInc,
  onDec,
}: {
  label: string;
  short: string;
  value: number;
  highlight?: boolean;
  onInc?: () => void;
  onDec?: () => void;
}) {
  return (
    <div
      className={cn(
        "flex min-w-0 flex-1 flex-col items-center gap-2 rounded-lg border px-1 py-3",
        highlight ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated",
      )}
    >
      <div className="h-14 w-full max-w-10">
        <div className="flex h-full flex-col-reverse gap-0.5">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "h-[5px] rounded-full",
                i < value ? "bg-primary" : "bg-surface-2",
              )}
            />
          ))}
        </div>
      </div>
      <div className="font-display text-2xl tabular-nums leading-none">{value}</div>
      <div className="px-0.5 text-center text-[10px] font-medium uppercase tracking-wide text-muted leading-tight">
        <span className="hidden sm:inline">{label}</span>
        <span className="sm:hidden">{short}</span>
      </div>
      {onInc && onDec ? (
        <div className="flex gap-1">
          <button
            type="button"
            aria-label={`Kurangi ${label}`}
            onClick={onDec}
            className="flex size-9 items-center justify-center rounded-sm border border-border bg-bg text-fg hover:bg-surface"
          >
            <Minus className="size-3.5" />
          </button>
          <button
            type="button"
            aria-label={`Tambah ${label}`}
            onClick={onInc}
            className="flex size-9 items-center justify-center rounded-sm border border-border bg-bg text-fg hover:bg-surface"
          >
            <Plus className="size-3.5" />
          </button>
        </div>
      ) : null}
    </div>
  );
}

function Board({
  value,
  onChange,
  highlightIndex,
  readOnly,
}: {
  value: number;
  onChange?: (n: number) => void;
  highlightIndex?: number | null;
  readOnly?: boolean;
}) {
  const digits = digitsOf(value, 6);
  const setDigit = (i: number, next: number) => {
    if (!onChange) return;
    const copy = [...digits];
    copy[i] = Math.min(9, Math.max(0, next));
    onChange(fromDigits(copy));
  };
  return (
    <div className="flex gap-1.5 sm:gap-2">
      {LABELS.map((p, i) => (
        <DigitColumn
          key={p.key}
          label={p.long}
          short={p.short}
          value={digits[i] ?? 0}
          highlight={highlightIndex === i}
          onInc={readOnly ? undefined : () => setDigit(i, (digits[i] ?? 0) + 1)}
          onDec={readOnly ? undefined : () => setDigit(i, (digits[i] ?? 0) - 1)}
        />
      ))}
    </div>
  );
}

function firstDiffIndex(a: number, b: number): number | null {
  const da = digitsOf(a, 6);
  const db = digitsOf(b, 6);
  for (let i = 0; i < 6; i++) {
    if (da[i] !== db[i]) return i;
  }
  return null;
}

function OperatePanel({ a0, b0, op0 }: { a0: number; b0: number; op0: "+" | "-" }) {
  const [a, setA] = useState(a0);
  const [b, setB] = useState(b0);
  const [op, setOp] = useState<"+" | "-">(op0);
  const [col, setCol] = useState(-1);
  const [carry, setCarry] = useState(0);
  const [out, setOut] = useState<number[]>(Array(7).fill(-1));
  const [msg, setMsg] = useState("Mulai dari satuan, di kanan.");

  const da = digitsOf(a, 6);
  const db = digitsOf(b, 6);

  const reset = (na = a, nb = b, nop = op) => {
    setA(na);
    setB(nb);
    setOp(nop);
    setCol(-1);
    setCarry(0);
    setOut(Array(7).fill(-1));
    setMsg("Mulai dari satuan, di kanan.");
  };

  const next = () => {
    const i = col + 1;
    if (i > 6) return;
    const fromRight = 5 - i;
    if (i === 6) {
      if (carry) {
        const nextOut = [...out];
        nextOut[0] = carry;
        setOut(nextOut);
        setMsg(`Sisa simpanan ${carry} menulis digit baru di kiri. Hasil ${formatId(op === "+" ? a + b : a - b)}.`);
      } else {
        setMsg(`Selesai. Hasil ${formatId(op === "+" ? a + b : a - b)}.`);
      }
      setCol(6);
      setCarry(0);
      return;
    }
    const av = da[fromRight] ?? 0;
    const bv = db[fromRight] ?? 0;
    const nextOut = [...out];
    if (op === "+") {
      const sum = av + bv + carry;
      const digit = sum % 10;
      const nextCarry = Math.floor(sum / 10);
      nextOut[fromRight + 1] = digit;
      setOut(nextOut);
      setCarry(nextCarry);
      setCol(i);
      setMsg(
        nextCarry
          ? `${av} + ${bv}${carry ? ` + simpanan ${carry}` : ""} = ${sum}. Tulis ${digit}, ikat 10 menjadi 1 ${LABELS[fromRight - 1]?.long ?? "di kiri"}.`
          : `${av} + ${bv}${carry ? ` + simpanan ${carry}` : ""} = ${sum}. Tulis ${digit}, tidak ada ikatan.`,
      );
    } else {
      let top = av - carry;
      let borrowed = 0;
      if (top < bv) {
        top += 10;
        borrowed = 1;
      }
      const digit = top - bv;
      nextOut[fromRight + 1] = digit;
      setOut(nextOut);
      setCarry(borrowed);
      setCol(i);
      setMsg(
        borrowed
          ? `${av}${carry ? ` (sudah dipinjam ${carry})` : ""} kurang dari ${bv}, jadi pinjam 10. ${top} − ${bv} = ${digit}. Rumah kiri akan berkurang 1.`
          : `${av}${carry ? ` − pinjaman ${carry}` : ""} − ${bv} = ${digit}.`,
      );
    }
  };

  const resultDigits = out;
  const expected = op === "+" ? a + b : a - b;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant={op === "+" ? "default" : "secondary"} onClick={() => reset(a, b, "+")}>
          Jumlah
        </Button>
        <Button size="sm" variant={op === "-" ? "default" : "secondary"} onClick={() => reset(Math.max(a, b), Math.min(a, b), "-")}>
          Kurang
        </Button>
        <Button size="sm" variant="outline" onClick={() => reset()}>
          Ulangi langkah
        </Button>
      </div>
      <div className="overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3">
        <table className="w-full min-w-72 text-center font-display text-lg tabular-nums">
          <thead>
            <tr className="text-[10px] font-medium uppercase tracking-wide text-muted">
              <th className="w-8" />
              {LABELS.map((p) => (
                <th key={p.key} className="px-1 pb-2">
                  {p.short}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td />
              {da.map((d, i) => (
                <td key={`a${i}`} className="py-1">
                  {d}
                </td>
              ))}
            </tr>
            <tr>
              <td className="text-muted">{op}</td>
              {db.map((d, i) => (
                <td key={`b${i}`} className="py-1">
                  {d}
                </td>
              ))}
            </tr>
            <tr className="border-t border-border">
              <td />
              {LABELS.map((_, i) => (
                <td key={`o${i}`} className="py-2 text-primary">
                  {resultDigits[i + 1] >= 0 ? resultDigits[i + 1] : "·"}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
        {resultDigits[0] > 0 ? (
          <p className="mt-2 text-sm text-muted">
            Digit tambahan di kiri: {resultDigits[0]}. Hasil {formatId(expected)}.
          </p>
        ) : null}
      </div>
      <p className="text-sm leading-normal text-muted">{msg}</p>
      <Button onClick={next} disabled={col >= 6}>
        {col < 0 ? "Jumlahkan satuan" : col >= 5 ? "Selesaikan" : "Kolom berikutnya"}
      </Button>
    </div>
  );
}

export function PlaceValueLab({
  mode,
  start = 125450,
  other = 12405,
  op = "+",
}: {
  mode: "build" | "compare" | "operate";
  start?: number;
  other?: number;
  op?: "+" | "-";
}) {
  const [n, setN] = useState(start);
  const [m, setM] = useState(other);
  const diff = useMemo(() => firstDiffIndex(n, m), [n, m]);

  if (mode === "operate") {
    return <OperatePanel a0={start} b0={other} op0={op} />;
  }

  return (
    <div className="space-y-5">
      <Board
        value={n}
        onChange={setN}
        highlightIndex={mode === "compare" ? diff : null}
      />
      <div>
        <div className="font-display text-3xl tabular-nums tracking-tight">{formatId(n)}</div>
        <p className="mt-1 text-sm text-muted">{numberToWordsId(n)}</p>
        <p className="mt-1 font-mono text-xs text-subtle">{expandedForm(n)}</p>
      </div>
      {mode === "compare" ? (
        <div className="space-y-5 border-t border-border pt-5">
          <Board value={m} onChange={setM} highlightIndex={diff} />
          <div>
            <div className="font-display text-3xl tabular-nums tracking-tight">{formatId(m)}</div>
            <p className="mt-1 text-sm text-muted">{numberToWordsId(m)}</p>
          </div>
          <p className="rounded-md bg-primary-soft px-3 py-2 text-sm text-fg">
            {n === m
              ? "Sama besar. Tidak ada rumah yang berbeda."
              : diff === null
                ? ""
                : n > m
                  ? `${formatId(n)} lebih besar. Rumah pertama yang berbeda dari kiri: ${LABELS[diff]?.long}.`
                  : `${formatId(m)} lebih besar. Rumah pertama yang berbeda dari kiri: ${LABELS[diff]?.long}.`}
          </p>
        </div>
      ) : null}
    </div>
  );
}
