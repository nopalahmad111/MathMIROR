import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { factorsOf, isPrime, parseIdNumber, primeFactors } from "@/lib/math";
import { cn } from "@/lib/utils";

export function FactorLab({
  mode,
  start = 24,
}: {
  mode: "rectangles" | "prime" | "tree";
  start?: number;
}) {
  const [raw, setRaw] = useState(String(start));
  const n = Math.max(1, Math.min(60, parseIdNumber(raw) ?? start));
  const facts = factorsOf(n);
  const [width, setWidth] = useState(facts.includes(start) && start <= 24 ? 6 : facts[1] ?? 1);
  const valid = n % width === 0;
  const height = valid ? n / width : 0;

  const cells = useMemo(() => Array.from({ length: n }, (_, i) => i), [n]);

  return (
    <div className="space-y-5">
      <label className="block text-sm font-medium">
        Bilangan
        <Input
          className="mt-1.5 max-w-40"
          inputMode="numeric"
          value={raw}
          onChange={(e) => {
            setRaw(e.target.value);
            const v = parseIdNumber(e.target.value);
            if (v && v > 0) {
              const f = factorsOf(v);
              setWidth(f[Math.min(1, f.length - 1)] ?? 1);
            }
          }}
        />
      </label>

      {mode !== "tree" ? (
        <>
          <div className="flex flex-wrap gap-1.5">
            {facts.map((f) => (
              <Button
                key={f}
                size="sm"
                variant={width === f ? "default" : "secondary"}
                onClick={() => setWidth(f)}
              >
                {f} × {n / f}
              </Button>
            ))}
          </div>
          <div className="overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3">
            <div
              className="grid w-fit gap-1"
              style={{ gridTemplateColumns: `repeat(${width}, 14px)` }}
            >
              {cells.map((i) => (
                <div
                  key={i}
                  className={cn(
                    "size-3.5 rounded-[2px]",
                    valid ? "bg-primary" : "bg-surface-2",
                  )}
                />
              ))}
            </div>
          </div>
          <p className="text-sm text-muted">
            {valid
              ? `${width} kolom × ${height} baris = ${n}. Susunan ini rapi: ${width} faktor ${n}.`
              : `${width} tidak membagi ${n}. Ada sisa — bukan faktor.`}
          </p>
        </>
      ) : null}

      {mode === "prime" ? (
        <p className="rounded-md bg-primary-soft px-3 py-2 text-sm">
          {n === 1
            ? "1 hanya punya satu faktor. Bukan prima, bukan majemuk."
            : isPrime(n)
              ? `${n} prima: hanya 1 × ${n}. Tidak bisa jadi kotak yang lebih gemuk.`
              : `${n} majemuk. Faktor: ${facts.join(", ")}. Bahan baku prima: ${primeFactors(n).join(" × ")}.`}
        </p>
      ) : null}

      {mode === "rectangles" ? (
        <p className="text-sm text-muted">
          Ada {facts.length} faktor, berarti {facts.length} cara berbaris rapi (termasuk 1 × {n}).
        </p>
      ) : null}

      {mode === "tree" ? <FactorTree n={n} /> : null}
    </div>
  );
}

function FactorTree({ n }: { n: number }) {
  const facts = factorsOf(n).filter((f) => f !== 1 && f !== n);
  const [split, setSplit] = useState<number | null>(facts[0] ?? null);
  const other = split ? n / split : null;
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted">Pilih pasangan faktor untuk memecah {n}. Lanjut pecah yang masih majemuk di kepala — daunnya harus prima.</p>
      <div className="flex flex-wrap gap-1.5">
        {facts.length === 0 ? (
          <span className="text-sm text-muted">
            {n === 1 ? "1 tidak dipecah." : `${n} prima — daun pohon.`}
          </span>
        ) : (
          facts.map((f) => (
            <Button
              key={f}
              size="sm"
              variant={split === f ? "default" : "secondary"}
              onClick={() => setSplit(f)}
            >
              {f} × {n / f}
            </Button>
          ))
        )}
      </div>
      {split && other ? (
        <div className="flex flex-col items-center gap-2 py-2 font-display">
          <div className="rounded-md border border-border px-3 py-1">{n}</div>
          <div className="h-6 w-px bg-border-strong" />
          <div className="flex gap-8">
            <Leaf v={split} />
            <Leaf v={other} />
          </div>
        </div>
      ) : null}
      {n > 1 ? (
        <p className="text-sm text-muted">
          Resep prima {n}: {primeFactors(n).join(" × ")}.
        </p>
      ) : null}
    </div>
  );
}

function Leaf({ v }: { v: number }) {
  return (
    <div
      className={cn(
        "rounded-md border px-3 py-1",
        isPrime(v) ? "border-primary bg-primary-soft" : "border-border",
      )}
    >
      {v}
      <div className="text-[10px] font-sans font-medium uppercase tracking-wide text-muted">
        {isPrime(v) ? "prima" : "pecah lagi"}
      </div>
    </div>
  );
}
