import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { formatFrac, gcd, lcm, simplifyFrac } from "@/lib/math";
import { cn } from "@/lib/utils";

function Bar({
  n,
  d,
  label,
  muted,
}: {
  n: number;
  d: number;
  label?: string;
  muted?: boolean;
}) {
  const den = Math.max(1, d);
  const num = Math.max(0, n);
  return (
    <div className="space-y-1.5">
      {label ? (
        <div className="flex items-baseline justify-between text-sm">
          <span className="text-muted">{label}</span>
          <span className="font-display tabular-nums">{formatFrac(num, den)}</span>
        </div>
      ) : null}
      <div className="flex h-10 overflow-hidden rounded-md border border-border">
        {Array.from({ length: den }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-full flex-1 border-r border-border last:border-r-0",
              i < num ? (muted ? "bg-surface-2" : "bg-primary") : "bg-bg-elevated",
            )}
          />
        ))}
      </div>
    </div>
  );
}

function Stepper({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-24 text-sm text-muted">{label}</span>
      <Button size="icon" variant="secondary" className="size-9" onClick={() => onChange(Math.max(min, value - 1))} aria-label={`Kurangi ${label}`}>
        −
      </Button>
      <span className="w-8 text-center font-display tabular-nums">{value}</span>
      <Button size="icon" variant="secondary" className="size-9" onClick={() => onChange(Math.min(max, value + 1))} aria-label={`Tambah ${label}`}>
        +
      </Button>
    </div>
  );
}

export function FractionLab({
  mode,
  a = [1, 4],
  b = [1, 3],
}: {
  mode: "shade" | "equiv" | "compare" | "add" | "life";
  a?: [number, number];
  b?: [number, number];
}) {
  const [n, setN] = useState(a[0]);
  const [d, setD] = useState(a[1]);
  const [n2, setN2] = useState(b[0]);
  const [d2, setD2] = useState(b[1]);
  const [mul, setMul] = useState(2);
  const [equalized, setEqualized] = useState(false);
  const [ctx, setCtx] = useState<"waktu" | "berbagi" | "sedekah">("waktu");

  const s = simplifyFrac(n, d);
  const common = lcm(d, d2);
  const e1n = n * (common / d);
  const e2n = n2 * (common / d2);
  const sumN = e1n + e2n;
  const sumS = simplifyFrac(sumN, common);

  if (mode === "shade") {
    return (
      <div className="space-y-5">
        <Bar n={n} d={d} label="Utuh yang dipotong sama besar" />
        <Stepper label="Pembilang" value={n} min={0} max={d} onChange={setN} />
        <Stepper
          label="Penyebut"
          value={d}
          min={1}
          max={12}
          onChange={(v) => {
            setD(v);
            setN((cur) => Math.min(cur, v));
          }}
        />
        <p className="text-sm text-muted">
          {n}/{d} artinya {n} dari {d} potong sama. Nama hemat: {s.d === 1 ? s.n : `${s.n}/${s.d}`}.
          {s.n === s.d ? " Itu seluruh utuh." : ""}
        </p>
      </div>
    );
  }

  if (mode === "equiv") {
    return (
      <div className="space-y-5">
        <Bar n={n} d={d} label="Nama awal" />
        <Bar n={n * mul} d={d * mul} label={`Dikali ${mul}/${mul}`} />
        <Stepper label="Pengali" value={mul} min={1} max={8} onChange={setMul} />
        <Stepper label="Pembilang awal" value={n} min={1} max={8} onChange={setN} />
        <Stepper label="Penyebut awal" value={d} min={n} max={12} onChange={setD} />
        <p className="text-sm text-muted">
          {n}/{d} = {n * mul}/{d * mul}. Potongan lebih halus, jumlah yang diarsir sama. Menyederhanakan adalah
          jalan pulang: bagi dengan FPB {gcd(n * mul, d * mul)}.
        </p>
      </div>
    );
  }

  if (mode === "compare") {
    return (
      <div className="space-y-5">
        <Bar n={equalized ? e1n : n} d={equalized ? common : d} label="Hana" />
        <Bar n={equalized ? e2n : n2} d={equalized ? common : d2} label="Rafi" />
        <div className="grid gap-2 sm:grid-cols-2">
          <Stepper label="Hana atas" value={n} min={1} max={d} onChange={setN} />
          <Stepper label="Hana bawah" value={d} min={2} max={12} onChange={(v) => { setD(v); setN((c) => Math.min(c, v)); setEqualized(false); }} />
          <Stepper label="Rafi atas" value={n2} min={1} max={d2} onChange={setN2} />
          <Stepper label="Rafi bawah" value={d2} min={2} max={12} onChange={(v) => { setD2(v); setN2((c) => Math.min(c, v)); setEqualized(false); }} />
        </div>
        <Button variant={equalized ? "default" : "secondary"} onClick={() => setEqualized((v) => !v)}>
          {equalized ? "Kembalikan potongan asli" : `Samakan potongan (per-${common})`}
        </Button>
        <p className="text-sm text-muted">
          {e1n === e2n
            ? "Sama banyak."
            : e1n > e2n
              ? `${n}/${d} lebih besar (${e1n}/${common} > ${e2n}/${common}).`
              : `${n2}/${d2} lebih besar (${e2n}/${common} > ${e1n}/${common}).`}{" "}
          Pemenang tidak boleh berubah hanya karena potongan diperhalus.
        </p>
      </div>
    );
  }

  if (mode === "add") {
    const overflow = sumN > common;
    return (
      <div className="space-y-5">
        <Bar n={n} d={d} label={`${n}/${d}`} />
        <Bar n={n2} d={d2} label={`${n2}/${d2}`} />
        <p className="text-xs font-medium uppercase tracking-wide text-muted">Bahasa yang sama — per {common}</p>
        <Bar n={e1n} d={common} label={`${e1n}/${common}`} />
        <Bar n={e2n} d={common} label={`${e2n}/${common}`} />
        <Bar n={Math.min(sumN, common)} d={common} label="Gabungan (satu utuh)" />
        {overflow ? (
          <Bar n={sumN - common} d={common} label="Kelebihan di utuh berikutnya" />
        ) : null}
        <div className="grid gap-2 sm:grid-cols-2">
          <Stepper label="A atas" value={n} min={1} max={8} onChange={setN} />
          <Stepper label="A bawah" value={d} min={2} max={12} onChange={setD} />
          <Stepper label="B atas" value={n2} min={1} max={8} onChange={setN2} />
          <Stepper label="B bawah" value={d2} min={2} max={12} onChange={setD2} />
        </div>
        <p className="rounded-md bg-primary-soft px-3 py-2 text-sm">
          {n}/{d} + {n2}/{d2} = {e1n}/{common} + {e2n}/{common} = {sumN}/{common}
          {sumS.n !== sumN ? ` = ${sumS.d === 1 ? sumS.n : `${sumS.n}/${sumS.d}`}` : ""}. Bukan {n + n2}/{d + d2}.
        </p>
      </div>
    );
  }

  return <LifeMode ctx={ctx} setCtx={setCtx} n={n} d={d} setN={setN} setD={setD} n2={n2} d2={d2} />;
}

function LifeMode({
  ctx,
  setCtx,
  n,
  d,
  setN,
  setD,
  n2,
  d2,
}: {
  ctx: "waktu" | "berbagi" | "sedekah";
  setCtx: (c: "waktu" | "berbagi" | "sedekah") => void;
  n: number;
  d: number;
  setN: (n: number) => void;
  setD: (d: number) => void;
  n2: number;
  d2: number;
}) {
  const minutes = useMemo(() => Math.round((n / d) * 60), [n, d]);
  const cakes = 24;
  const given = Math.round((n / d) * cakes);
  const harvest = 40;
  const zakat = Math.round((n / d) * harvest);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {(["waktu", "berbagi", "sedekah"] as const).map((c) => (
          <Button key={c} size="sm" variant={ctx === c ? "default" : "secondary"} onClick={() => setCtx(c)}>
            {c === "waktu" ? "Waktu" : c === "berbagi" ? "Berbagi kue" : "Sedekah panen"}
          </Button>
        ))}
      </div>
      <Bar n={n} d={d} label={`Pecahan ${n}/${d}`} />
      <Stepper label="Pembilang" value={n} min={1} max={d} onChange={setN} />
      <Stepper label="Penyebut" value={d} min={2} max={10} onChange={(v) => { setD(v); setN(Math.min(n, v)); }} />
      {ctx === "waktu" ? (
        <p className="text-sm leading-normal text-muted">
          Utuhnya 1 jam = 60 menit. {n}/{d} jam = {minutes} menit.
          {n2 && d2 ? ` Kalau ditambah ${n2}/${d2} jam, samakan dulu bahasanya.` : ""}
        </p>
      ) : null}
      {ctx === "berbagi" ? (
        <p className="text-sm leading-normal text-muted">
          Utuhnya 24 kue. {n}/{d} dari 24 = {given} kue. Sisa {(1 - n / d) > 0 ? `${formatFrac(d - n, d)} × 24 = ${cakes - given}` : 0}.
        </p>
      ) : null}
      {ctx === "sedekah" ? (
        <p className="text-sm leading-normal text-muted">
          Utuhnya 40 kg panen. {n}/{d} disedekahkan = {zakat} kg. Sepersepuluh adalah 1 dari 10 bagian sama.
        </p>
      ) : null}
    </div>
  );
}
