import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatId, parseIdNumber, roundToPlace } from "@/lib/math";
import { cn } from "@/lib/utils";

const PLACES = [
  { value: 10, label: "Puluhan" },
  { value: 100, label: "Ratusan" },
  { value: 1000, label: "Ribuan" },
  { value: 10000, label: "Puluhan ribu" },
  { value: 100000, label: "Ratusan ribu" },
];

export function RoundLab({ start = 48750 }: { start?: number }) {
  const [raw, setRaw] = useState(String(start));
  const [place, setPlace] = useState(1000);
  const n = parseIdNumber(raw) ?? start;
  const rounded = roundToPlace(n, place);
  const low = Math.floor(n / place) * place;
  const high = low + place;
  const mid = low + place / 2;
  const t = high === low ? 0.5 : (n - low) / (high - low);

  const note = useMemo(() => {
    if (n === rounded) return "Angka ini sudah tepat di satuan yang dipilih.";
    if (n === mid)
      return `Tepat di tengah ${formatId(low)} dan ${formatId(high)}. Kesepakatan sekolah: naik ke ${formatId(high)}.`;
    if (n > mid)
      return `Lebih dekat ke ${formatId(high)} (jarak ${formatId(high - n)} vs ${formatId(n - low)}).`;
    return `Lebih dekat ke ${formatId(low)} (jarak ${formatId(n - low)} vs ${formatId(high - n)}).`;
  }, [n, rounded, mid, low, high]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <label className="block flex-1 text-sm font-medium">
          Bilangan
          <Input
            className="mt-1.5"
            inputMode="numeric"
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
          />
        </label>
      </div>
      <div className="flex flex-wrap gap-2">
        {PLACES.map((p) => (
          <Button
            key={p.value}
            size="sm"
            variant={place === p.value ? "default" : "secondary"}
            onClick={() => setPlace(p.value)}
          >
            {p.label}
          </Button>
        ))}
      </div>
      <div className="rounded-lg border border-border bg-bg-elevated px-4 py-5">
        <div className="relative h-16">
          <div className="absolute top-8 right-0 left-0 h-px bg-border-strong" />
          <div className="absolute top-6 left-0 h-5 w-px bg-border-strong" />
          <div className="absolute top-6 right-0 left-1/2 h-5 w-px -translate-x-1/2 bg-subtle" />
          <div className="absolute top-6 right-0 h-5 w-px bg-border-strong" />
          <div
            className="absolute top-5 size-3 -translate-x-1/2 rounded-full bg-primary"
            style={{ left: `${Math.min(100, Math.max(0, t * 100))}%` }}
          />
          <div className="absolute top-0 left-0 text-xs text-muted tabular-nums">{formatId(low)}</div>
          <div className="absolute top-0 left-1/2 -translate-x-1/2 text-xs text-subtle tabular-nums">
            {formatId(mid)}
          </div>
          <div className="absolute top-0 right-0 text-xs text-muted tabular-nums">{formatId(high)}</div>
          <div
            className={cn(
              "absolute top-11 -translate-x-1/2 font-display text-sm tabular-nums",
              t > 0.85 ? "translate-x-[-90%]" : t < 0.15 ? "translate-x-0" : "",
            )}
            style={{ left: `${Math.min(100, Math.max(0, t * 100))}%` }}
          >
            {formatId(n)}
          </div>
        </div>
      </div>
      <p className="font-display text-2xl tabular-nums">
        {formatId(n)}
        <span className="mx-2 text-subtle">→</span>
        {formatId(rounded)}
      </p>
      <p className="text-sm leading-normal text-muted">{note}</p>
    </div>
  );
}
