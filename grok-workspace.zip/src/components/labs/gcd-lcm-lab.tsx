import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { euclidSteps, factorsOf, formatId, gcd, lcm, parseIdNumber } from "@/lib/math";
import { cn } from "@/lib/utils";

export function GcdLcmLab({
  mode,
  a: a0 = 18,
  b: b0 = 24,
  story,
}: {
  mode: "gcd" | "lcm" | "choose";
  a?: number;
  b?: number;
  story?: string;
}) {
  const [rawA, setRawA] = useState(String(a0));
  const [rawB, setRawB] = useState(String(b0));
  const [view, setView] = useState<"gcd" | "lcm">(mode === "lcm" ? "lcm" : "gcd");
  const a = Math.max(1, Math.min(120, parseIdNumber(rawA) ?? a0));
  const b = Math.max(1, Math.min(120, parseIdNumber(rawB) ?? b0));
  const g = gcd(a, b);
  const k = lcm(a, b);
  const fa = factorsOf(a);
  const fb = factorsOf(b);
  const common = fa.filter((x) => fb.includes(x));
  const steps = euclidSteps(a, b);

  return (
    <div className="space-y-5">
      {story ? <p className="text-sm leading-normal text-muted">{story}</p> : null}
      {mode === "choose" ? (
        <div className="flex gap-2">
          <Button size="sm" variant={view === "gcd" ? "default" : "secondary"} onClick={() => setView("gcd")}>
            Ini berbagi — FPB
          </Button>
          <Button size="sm" variant={view === "lcm" ? "default" : "secondary"} onClick={() => setView("lcm")}>
            Ini bertemu — KPK
          </Button>
        </div>
      ) : null}
      <div className="flex gap-3">
        <label className="text-sm font-medium">
          A
          <Input className="mt-1.5 w-24" inputMode="numeric" value={rawA} onChange={(e) => setRawA(e.target.value)} />
        </label>
        <label className="text-sm font-medium">
          B
          <Input className="mt-1.5 w-24" inputMode="numeric" value={rawB} onChange={(e) => setRawB(e.target.value)} />
        </label>
      </div>

      {(mode === "gcd" || view === "gcd") && mode !== "lcm" ? (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <FactorList label={`Faktor ${a}`} items={fa} common={common} max={g} />
            <FactorList label={`Faktor ${b}`} items={fb} common={common} max={g} />
          </div>
          <p className="rounded-md bg-primary-soft px-3 py-2 text-sm">
            Irisan: {common.join(", ") || "—"}. Terbesar <span className="font-medium">{g}</span> — itu FPB.
          </p>
          <div>
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Langkah Euclid</p>
            <ol className="space-y-1 text-sm tabular-nums text-fg">
              {steps.map((s, i) => (
                <li key={i}>
                  {s.a} = {s.q} × {s.b} + {s.r}
                  {s.r === 0 ? " → sisa 0, berhenti." : ""}
                </li>
              ))}
            </ol>
            <p className="mt-2 text-sm text-muted">
              Pembagi terakhir sebelum sisa 0 adalah FPB = {g}. Sisa adalah yang tersisa setelah kotak besar menempel.
            </p>
          </div>
        </div>
      ) : null}

      {(mode === "lcm" || view === "lcm") && mode !== "gcd" ? (
        <LcmHops a={a} b={b} k={k} />
      ) : null}

      {mode === "choose" ? (
        <p className="text-sm text-muted">
          Angka yang sama bisa menjawab {g} (FPB, berbagi) atau {k} (KPK, bertemu). Pilih pertanyaan dulu.
        </p>
      ) : null}
    </div>
  );
}

function FactorList({
  label,
  items,
  common,
  max,
}: {
  label: string;
  items: number[];
  common: number[];
  max: number;
}) {
  return (
    <div className="rounded-lg border border-border bg-bg-elevated p-3">
      <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">{label}</p>
      <div className="flex flex-wrap gap-1.5">
        {items.map((n) => (
          <span
            key={n}
            className={cn(
              "rounded-full px-2 py-0.5 text-sm tabular-nums",
              n === max
                ? "bg-primary text-primary-fg"
                : common.includes(n)
                  ? "bg-primary-soft text-primary"
                  : "bg-surface text-muted",
            )}
          >
            {n}
          </span>
        ))}
      </div>
    </div>
  );
}

function LcmHops({ a, b, k }: { a: number; b: number; k: number }) {
  const max = Math.min(Math.max(k * 2, a * 3, b * 3), 72);
  const ticks = useMemo(() => Array.from({ length: max + 1 }, (_, i) => i), [max]);
  const marksA = new Set(ticks.filter((t) => t > 0 && t % a === 0));
  const marksB = new Set(ticks.filter((t) => t > 0 && t % b === 0));
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted">
        Loncatan {a} dan {b}. Titik yang diinjak berdua — kelipatan persekutuan. Yang pertama: KPK = {k}.
      </p>
      <div className="overflow-x-auto rounded-lg border border-border bg-bg-elevated p-3">
        <div className="min-w-[640px] space-y-3">
          <HopRow label={`+${a}`} ticks={ticks} marks={marksA} other={marksB} />
          <HopRow label={`+${b}`} ticks={ticks} marks={marksB} other={marksA} />
        </div>
      </div>
      <p className="text-sm text-muted">
        Rumus ringkas: {a} × {b} / FPB({a},{b}) = {a * b} / {gcd(a, b)} = {k}. Rumus ini menyingkat irisan loncatan, bukan
        menggantinya.
      </p>
    </div>
  );
}

function HopRow({
  label,
  ticks,
  marks,
  other,
}: {
  label: string;
  ticks: number[];
  marks: Set<number>;
  other: Set<number>;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-8 shrink-0 text-xs font-medium text-muted tabular-nums">{label}</span>
      <div className="flex flex-1">
        {ticks.map((t) => {
          const on = marks.has(t);
          const both = on && other.has(t);
          return (
            <div key={t} className="flex flex-1 flex-col items-center">
              <div
                className={cn(
                  "size-2 rounded-full",
                  both ? "bg-primary" : on ? "bg-fg" : "bg-surface-2",
                )}
              />
              {t % 6 === 0 ? (
                <span className="mt-1 text-[9px] text-subtle tabular-nums">{formatId(t)}</span>
              ) : (
                <span className="mt-1 h-3" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
