import type { ExploreConfig } from "@/lib/content/types";
import { FactorLab } from "./factor-lab";
import { FractionLab } from "./fraction-lab";
import { GcdLcmLab } from "./gcd-lcm-lab";
import { PlaceValueLab } from "./place-value-lab";
import { RoundLab } from "./round-lab";

export function Explore({ config }: { config: ExploreConfig }) {
  switch (config.lab) {
    case "place-value":
      return (
        <PlaceValueLab
          mode={config.mode}
          start={config.start}
          other={config.other}
          op={config.op}
        />
      );
    case "round":
      return <RoundLab start={config.start} />;
    case "factor":
      return <FactorLab mode={config.mode} start={config.start} />;
    case "gcd-lcm":
      return (
        <GcdLcmLab mode={config.mode} a={config.a} b={config.b} story={config.story} />
      );
    case "fraction":
      return <FractionLab mode={config.mode} a={config.a} b={config.b} />;
    default:
      return null;
  }
}
