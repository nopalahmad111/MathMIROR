import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useMemo, useState } from "react";
import { Explore } from "@/components/labs/explore";
import { PracticeQuiz } from "@/components/practice-quiz";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { getJalur, nextLesson } from "@/lib/content";
import type { Lesson } from "@/lib/content/types";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

const PHASES = [
  { id: "mindful", label: "Niat" },
  { id: "story", label: "Cerita" },
  { id: "explore", label: "Gali" },
  { id: "practice", label: "Latihan" },
  { id: "reflect", label: "Cermin" },
] as const;

export function LessonPlayer({ lesson }: { lesson: Lesson }) {
  const [phase, setPhase] = useState(0);
  const [notice, setNotice] = useState("");
  const [customNotice, setCustomNotice] = useState("");
  const [storyThought, setStoryThought] = useState("");
  const [reflections, setReflections] = useState(["", ""]);
  const [practice, setPractice] = useState<{ correct: number; total: number } | null>(null);
  const [saved, setSaved] = useState(false);
  const saveLesson = useProgress((s) => s.saveLesson);
  const addReflection = useProgress((s) => s.addReflection);
  const jalur = getJalur(lesson.jalurId);
  const nxt = nextLesson(lesson.id);
  const noticeValue = notice === "__custom" ? customNotice : notice;

  const canNext = useMemo(() => {
    if (phase === 0) return noticeValue.trim().length > 0;
    if (phase === 1) return storyThought.trim().length > 0;
    if (phase === 3) return practice !== null;
    return true;
  }, [phase, noticeValue, storyThought, practice]);

  const persist = () => {
    const text = reflections.filter((t) => t.trim()).join("\n\n");
    saveLesson(lesson.id, {
      at: new Date().toISOString(),
      practiceCorrect: practice?.correct ?? 0,
      practiceTotal: practice?.total ?? lesson.practice.length,
      reflected: text.length > 0,
      notice: noticeValue,
      storyThought,
    });
    if (text) {
      addReflection({ lessonId: lesson.id, jalurId: lesson.jalurId, text });
    }
    setSaved(true);
  };

  return (
    <div className="mx-auto max-w-2xl px-4 pb-24 pt-6 sm:px-6">
      <div className="mb-6 flex items-center gap-3">
        <Link
          to="/jalur/$jalurId"
          params={{ jalurId: lesson.jalurId }}
          className="flex size-11 items-center justify-center rounded-md border border-border bg-bg-elevated text-fg hover:bg-surface"
          aria-label="Kembali ke jalur"
        >
          <ArrowLeft className="size-4" />
        </Link>
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wide text-muted">
            {jalur?.title} · Pelajaran {lesson.order}
          </p>
          <h1 className="font-display text-xl leading-snug sm:text-2xl">{lesson.title}</h1>
        </div>
      </div>

      <ol className="mb-8 flex gap-1">
        {PHASES.map((p, i) => (
          <li key={p.id} className="flex-1">
            <button
              type="button"
              onClick={() => {
                if (i <= phase) setPhase(i);
              }}
              className="w-full text-left"
            >
              <div
                className={cn(
                  "h-1 rounded-full",
                  i <= phase ? "bg-primary" : "bg-surface-2",
                )}
              />
              <span
                className={cn(
                  "mt-2 hidden text-[10px] font-medium uppercase tracking-wide sm:block",
                  i === phase ? "text-fg" : "text-subtle",
                )}
              >
                {p.label}
              </span>
            </button>
          </li>
        ))}
      </ol>

      {phase === 0 ? (
        <section className="rise-in space-y-5">
          <p className="text-xs font-medium uppercase tracking-wide text-primary">Berkesadaran</p>
          <p className="font-display text-2xl leading-snug">{lesson.mindful.notice}</p>
          <p className="text-sm text-muted">{lesson.mindful.prompt}</p>
          <div className="grid gap-2">
            {lesson.mindful.chips.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setNotice(c)}
                className={cn(
                  "rounded-lg border px-4 py-3 text-left text-sm leading-snug",
                  notice === c ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated hover:bg-surface",
                )}
              >
                {c}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setNotice("__custom")}
              className={cn(
                "rounded-lg border px-4 py-3 text-left text-sm",
                notice === "__custom" ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated hover:bg-surface",
              )}
            >
              Aku ingin menulis sendiri
            </button>
          </div>
          {notice === "__custom" ? (
            <Textarea
              value={customNotice}
              onChange={(e) => setCustomNotice(e.target.value)}
              placeholder="Yang kuperhatikan…"
            />
          ) : null}
        </section>
      ) : null}

      {phase === 1 ? (
        <section className="rise-in space-y-5">
          <p className="text-xs font-medium uppercase tracking-wide text-primary">Bermakna</p>
          <h2 className="font-display text-2xl leading-snug">{lesson.story.title}</h2>
          {lesson.story.body.map((p) => (
            <p key={p} className="text-base leading-normal text-fg/90">
              {p}
            </p>
          ))}
          <p className="rounded-lg border border-border bg-surface px-4 py-3 text-sm leading-normal">
            {lesson.story.ask}
          </p>
          <Textarea
            value={storyThought}
            onChange={(e) => setStoryThought(e.target.value)}
            placeholder="Pikiranmu, belum perlu benar…"
          />
        </section>
      ) : null}

      {phase === 2 ? (
        <section className="rise-in space-y-5">
          <p className="text-xs font-medium uppercase tracking-wide text-primary">Mendalam</p>
          <p className="text-sm leading-normal text-muted">{lesson.explore.caption}</p>
          <div className="rounded-xl border border-border bg-bg-elevated p-4 sm:p-5">
            <Explore config={lesson.explore} />
          </div>
        </section>
      ) : null}

      {phase === 3 ? (
        <section className="rise-in">
          {practice ? (
            <div className="space-y-4">
              <p className="font-display text-2xl">
                {practice.correct} dari {practice.total} tepat pada percobaan pertama yang dikunci.
              </p>
              <p className="text-sm text-muted">
                Yang penting bukan skor. Baca lagi penjelasan pada soal yang terasa goyah.
              </p>
            </div>
          ) : (
            <PracticeQuiz
              items={lesson.practice}
              onDone={(correct, total) => setPractice({ correct, total })}
            />
          )}
        </section>
      ) : null}

      {phase === 4 ? (
        <section className="rise-in space-y-5">
          <p className="text-xs font-medium uppercase tracking-wide text-primary">Cermin</p>
          <p className="font-display text-2xl leading-snug">{lesson.intent}</p>
          {lesson.reflect.prompts.map((p, i) => (
            <label key={p} className="block space-y-2">
              <span className="text-sm leading-normal text-fg">{p}</span>
              <Textarea
                value={reflections[i] ?? ""}
                onChange={(e) =>
                  setReflections((prev) => {
                    const next = [...prev];
                    next[i] = e.target.value;
                    return next;
                  })
                }
                placeholder="Tulis pelan-pelan"
              />
            </label>
          ))}
          <p className="rounded-md bg-primary-soft px-4 py-3 text-sm leading-normal">{lesson.reflect.takeaway}</p>
          {saved ? (
            <div className="flex flex-col gap-3 sm:flex-row">
              {nxt ? (
                <Button asChild>
                  <Link to="/belajar/$lessonId" params={{ lessonId: nxt.id }}>
                    Pelajaran berikutnya
                    <ArrowRight className="size-4" />
                  </Link>
                </Button>
              ) : (
                <Button asChild>
                  <Link to="/jalur/$jalurId" params={{ jalurId: lesson.jalurId }}>
                    Kembali ke jalur
                  </Link>
                </Button>
              )}
              <Button variant="secondary" asChild>
                <Link to="/cermin">Buka cermin</Link>
              </Button>
            </div>
          ) : (
            <Button onClick={persist}>Simpan refleksi</Button>
          )}
        </section>
      ) : null}

      {phase < 4 ? (
        <div className="mt-10 flex items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => setPhase((p) => Math.max(0, p - 1))} disabled={phase === 0}>
            Kembali
          </Button>
          <Button onClick={() => setPhase((p) => p + 1)} disabled={!canNext}>
            Lanjut
            <ArrowRight className="size-4" />
          </Button>
        </div>
      ) : null}
    </div>
  );
}
