import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, House, PenLine } from "lucide-react";
import type { ReactNode } from "react";
import { Mark } from "@/components/mark";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Beranda", icon: House },
  { to: "/cermin", label: "Cermin", icon: PenLine },
  { to: "/panduan", label: "Panduan", icon: BookOpen },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const onboardingDone = useProgress((s) => s.onboardingDone);
  const hideChrome = pathname.startsWith("/belajar/") || !onboardingDone;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-20 border-b border-border/80 bg-bg/90 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5 text-fg">
            <Mark className="size-7" />
            <span className="font-display text-lg tracking-tight">Bening</span>
          </Link>
          {onboardingDone ? (
            <nav className="hidden items-center gap-1 sm:flex">
              {NAV.map((item) => {
                const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={cn(
                      "rounded-md px-3 py-2 text-sm font-medium",
                      active ? "bg-surface text-fg" : "text-muted hover:bg-surface hover:text-fg",
                    )}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          ) : null}
        </div>
      </header>
      <div className={cn(hideChrome ? "" : "pb-20 sm:pb-8")}>{children}</div>
      {!hideChrome ? (
        <nav className="fixed right-0 bottom-0 left-0 z-20 border-t border-border bg-bg/95 sm:hidden">
          <ul className="mx-auto grid max-w-lg grid-cols-3">
            {NAV.map((item) => {
              const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={cn(
                      "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                      active ? "text-primary" : "text-muted",
                    )}
                  >
                    <Icon className="size-5" strokeWidth={1.75} />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      ) : null}
    </div>
  );
}
