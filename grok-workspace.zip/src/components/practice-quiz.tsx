import { Check, ChevronRight, Lightbulb } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { answersMatch } from "@/lib/check-answer";
import type { PracticeItem } from "@/lib/content/types";
import { cn } from "@/lib/utils";

export function PracticeQuiz({
  items,
  onDone,
}: {
  items: PracticeItem[];
  onDone: (correct: number, total: number) => void;
}) {
  const [index, setIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [typed, setTyped] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [ok, setOk] = useState<boolean | null>(null);
  const [hintOn, setHintOn] = useState(false);
  const [tried, setTried] = useState(false);

  const item = items[index];
  if (!item) return null;
  const last = index === items.length - 1;

  const submit = (value: string) => {
    const match = answersMatch(item.answer, value, item.equivalentOk);
    setOk(match);
    setRevealed(true);
    if (match && !tried) setCorrectCount((c) => c + 1);
    setTried(true);
  };

  const goNext = () => {
    if (last) {
      onDone(correctCount, items.length);
      return;
    }
    setIndex((i) => i + 1);
    setSelected(null);
    setTyped("");
    setRevealed(false);
    setOk(null);
    setHintOn(false);
    setTried(false);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between text-xs font-medium uppercase tracking-wide text-muted">
        <span>
          Soal {index + 1} / {items.length}
        </span>
        <span className="tabular-nums">
          Tepat {correctCount}
        </span>
      </div>
      <p className="font-display text-xl leading-snug">{item.prompt}</p>

      {item.kind === "mc" && item.options ? (
        <div className="grid gap-2">
          {item.options.map((opt) => {
            const chosen = selected === opt;
            const show = revealed && chosen;
            const isAns = revealed && answersMatch(item.answer, opt, item.equivalentOk);
            return (
              <button
                key={opt}
                type="button"
                disabled={revealed && ok === true}
                onClick={() => {
                  setSelected(opt);
                  if (!revealed) submit(opt);
                  else if (!ok) submit(opt);
                }}
                className={cn(
                  "min-h-12 rounded-lg border px-4 py-3 text-left text-sm leading-snug transition-colors",
                  isAns
                    ? "border-primary bg-success-soft"
                    : show && !ok
                      ? "border-danger bg-danger-soft"
                      : "border-border bg-bg-elevated hover:bg-surface",
                )}
              >
                {opt}
              </button>
            );
          })}
        </div>
      ) : (
        <form
          className="flex flex-col gap-2 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            submit(typed);
          }}
        >
          <Input
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            placeholder={item.placeholder ?? "Jawaban"}
            disabled={revealed && ok === true}
            autoComplete="off"
          />
          <Button type="submit" variant="secondary" disabled={!typed.trim() || (revealed && ok === true)}>
            Periksa
          </Button>
        </form>
      )}

      {hintOn && !revealed ? (
        <p className="rounded-md border border-border bg-warn-soft px-3 py-2 text-sm text-warn">{item.hint}</p>
      ) : null}

      {revealed ? (
        <div
          className={cn(
            "rounded-lg border px-4 py-3 text-sm leading-normal",
            ok ? "border-primary/30 bg-success-soft" : "border-danger/30 bg-danger-soft",
          )}
        >
          <p className="mb-1 font-medium">{ok ? "Tepat." : `Belum. Jawaban: ${item.answer}`}</p>
          <p className="text-fg/90">{item.why}</p>
        </div>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {!revealed ? (
          <Button variant="ghost" size="sm" onClick={() => setHintOn(true)}>
            <Lightbulb className="size-4" />
            Petunjuk
          </Button>
        ) : null}
        {revealed && !ok && item.kind === "input" ? (
          <Button variant="ghost" size="sm" onClick={() => { setRevealed(false); setOk(null); }}>
            Coba lagi
          </Button>
        ) : null}
        {revealed ? (
          <Button onClick={goNext}>
            {last ? (
              <>
                Selesai
                <Check className="size-4" />
              </>
            ) : (
              <>
                Lanjut
                <ChevronRight className="size-4" />
              </>
            )}
          </Button>
        ) : null}
      </div>
    </div>
  );
}
