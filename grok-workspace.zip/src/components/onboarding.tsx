import { useEffect, useRef, useState } from "react";
import { Mark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NIAT_CHIPS } from "@/lib/content";
import { useProgress } from "@/lib/progress";
import { cn } from "@/lib/utils";

export function Onboarding() {
  const complete = useProgress((s) => s.completeOnboarding);
  const [step, setStep] = useState<"breath" | "name">("breath");
  const [phase, setPhase] = useState<"in" | "out">("in");
  const [count, setCount] = useState(0);
  const [name, setName] = useState("");
  const [niat, setNiat] = useState(NIAT_CHIPS[0] ?? "");
  const timers = useRef<number[]>([]);

  useEffect(() => {
    return () => {
      timers.current.forEach((id) => window.clearTimeout(id));
    };
  }, []);

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  };

  const startBreath = () => {
    setCount(1);
    setPhase("in");
    later(() => setPhase("out"), 4000);
    later(() => {
      setCount(2);
      setPhase("in");
    }, 8000);
    later(() => setPhase("out"), 12000);
    later(() => {
      setCount(3);
      setPhase("in");
    }, 16000);
    later(() => setPhase("out"), 20000);
    later(() => setStep("name"), 24000);
  };

  return (
    <main className="star-field mx-auto flex min-h-[calc(100dvh-3.5rem)] max-w-lg flex-col justify-center px-5 py-8 pb-24">
      {step === "breath" ? (
        <div className="flex flex-col items-center text-center">
          <Mark className="size-14" />
          <h1 className="mt-6 font-display text-4xl tracking-tight">Bening</h1>
          <p className="mt-2 text-sm text-muted">Matematika kelas 5 MI</p>
          <p className="mt-8 max-w-sm text-base leading-normal text-fg/90">
            Belajar pelan. Berkesadaran, bermakna, mendalam — bukan cepat selesai.
          </p>
          <div className="relative mt-8 flex size-32 items-center justify-center sm:mt-12 sm:size-40">
            <div
              className={cn(
                "size-24 rounded-full border border-primary/40 bg-primary-soft sm:size-28",
                count > 0 && "breathe-circle",
              )}
            />
            {count > 0 ? (
              <p className="absolute font-display text-lg">
                {phase === "in" ? "Tarik napas" : "Buang napas"}
                <span className="mt-1 block text-xs font-sans uppercase tracking-wide text-muted">
                  {count} / 3
                </span>
              </p>
            ) : null}
          </div>
          <div className="mt-10 flex w-full flex-col gap-2">
            {count === 0 ? (
              <Button className="w-full" size="lg" onClick={startBreath}>
                Tiga napas dulu
              </Button>
            ) : null}
            <Button className="w-full" size="lg" variant={count === 0 ? "ghost" : "secondary"} onClick={() => setStep("name")}>
              Saya sudah siap
            </Button>
          </div>
        </div>
      ) : (
        <form
          className="rise-in space-y-6"
          onSubmit={(e) => {
            e.preventDefault();
            if (name.trim()) complete(name.trim(), niat);
          }}
        >
          <h2 className="font-display text-3xl tracking-tight">Siapa namamu?</h2>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nama panggilan"
            autoComplete="nickname"
            required
          />
          <div>
            <p className="mb-3 text-sm font-medium">Niat belajar</p>
            <div className="grid gap-2">
              {NIAT_CHIPS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setNiat(c)}
                  className={cn(
                    "rounded-lg border px-4 py-3 text-left text-sm leading-snug",
                    niat === c ? "border-primary bg-primary-soft" : "border-border bg-bg-elevated hover:bg-surface",
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
          <Button type="submit" className="w-full" size="lg" disabled={!name.trim()}>
            Mulai belajar
          </Button>
        </form>
      )}
    </main>
  );
}
