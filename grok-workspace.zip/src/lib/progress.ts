import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { JalurId } from "@/lib/content/types";

export type LessonRecord = {
  at: string;
  practiceCorrect: number;
  practiceTotal: number;
  reflected: boolean;
  notice?: string;
  storyThought?: string;
};

export type Reflection = {
  id: string;
  lessonId: string;
  jalurId: JalurId;
  text: string;
  at: string;
};

export type ProgressState = {
  learnerName: string;
  niat: string;
  onboardingDone: boolean;
  lastMindfulAt: string | null;
  mindfulStarts: number;
  completed: Record<string, LessonRecord>;
  reflections: Reflection[];
  setName: (name: string) => void;
  setNiat: (niat: string) => void;
  completeOnboarding: (name: string, niat: string) => void;
  markMindful: () => void;
  saveLesson: (lessonId: string, record: LessonRecord) => void;
  addReflection: (entry: Omit<Reflection, "id" | "at">) => void;
  resetAll: () => void;
};

const todayKey = () => new Date().toISOString().slice(0, 10);

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      learnerName: "",
      niat: "",
      onboardingDone: false,
      lastMindfulAt: null,
      mindfulStarts: 0,
      completed: {},
      reflections: [],
      setName: (learnerName) => set({ learnerName }),
      setNiat: (niat) => set({ niat }),
      completeOnboarding: (learnerName, niat) =>
        set({
          learnerName: learnerName.trim(),
          niat,
          onboardingDone: true,
          lastMindfulAt: todayKey(),
          mindfulStarts: get().mindfulStarts + 1,
        }),
      markMindful: () =>
        set({
          lastMindfulAt: todayKey(),
          mindfulStarts: get().mindfulStarts + 1,
        }),
      saveLesson: (lessonId, record) =>
        set({
          completed: { ...get().completed, [lessonId]: record },
        }),
      addReflection: (entry) =>
        set({
          reflections: [
            {
              ...entry,
              id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
              at: new Date().toISOString(),
            },
            ...get().reflections,
          ].slice(0, 40),
        }),
      resetAll: () =>
        set({
          learnerName: "",
          niat: "",
          onboardingDone: false,
          lastMindfulAt: null,
          mindfulStarts: 0,
          completed: {},
          reflections: [],
        }),
    }),
    { name: "bening-progress-v1" },
  ),
);

export function mindfulDoneToday(lastMindfulAt: string | null): boolean {
  return lastMindfulAt === todayKey();
}
