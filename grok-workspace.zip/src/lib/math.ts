export function gcd(a: number, b: number): number {
  a = Math.abs(Math.trunc(a));
  b = Math.abs(Math.trunc(b));
  while (b !== 0) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

export function lcm(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return Math.abs(a * b) / gcd(a, b);
}

export function isPrime(n: number): boolean {
  const x = Math.trunc(n);
  if (x < 2) return false;
  if (x % 2 === 0) return x === 2;
  for (let i = 3; i * i <= x; i += 2) {
    if (x % i === 0) return false;
  }
  return true;
}

export function factorsOf(n: number): number[] {
  n = Math.abs(Math.trunc(n));
  if (n === 0) return [];
  const small: number[] = [];
  const large: number[] = [];
  for (let i = 1; i * i <= n; i++) {
    if (n % i === 0) {
      small.push(i);
      if (i * i !== n) large.push(n / i);
    }
  }
  return small.concat(large.reverse());
}

export function primeFactors(n: number): number[] {
  n = Math.abs(Math.trunc(n));
  const out: number[] = [];
  for (let p = 2; p * p <= n; p++) {
    while (n % p === 0) {
      out.push(p);
      n /= p;
    }
  }
  if (n > 1) out.push(n);
  return out;
}

export function uniquePrimes(n: number): number[] {
  return [...new Set(primeFactors(n))];
}

export function simplifyFrac(n: number, d: number): { n: number; d: number } {
  if (d === 0) return { n, d };
  const g = gcd(n, d);
  let nn = n / g;
  let dd = d / g;
  if (dd < 0) {
    nn = -nn;
    dd = -dd;
  }
  return { n: nn, d: dd };
}

export function roundToPlace(n: number, place: number): number {
  if (place <= 0) return n;
  return Math.round(n / place) * place;
}

export function digitsOf(n: number, width = 6): number[] {
  const s = Math.abs(Math.trunc(n)).toString().padStart(width, "0");
  return s.slice(-width).split("").map(Number);
}

export function fromDigits(digits: number[]): number {
  return digits.reduce((acc, d) => acc * 10 + d, 0);
}

const ONES = [
  "",
  "satu",
  "dua",
  "tiga",
  "empat",
  "lima",
  "enam",
  "tujuh",
  "delapan",
  "sembilan",
];

export function threeToWords(n: number): string {
  if (n <= 0) return "";
  const r = Math.floor(n / 100);
  const t = n % 100;
  const parts: string[] = [];
  if (r === 1) parts.push("seratus");
  else if (r > 1) parts.push(`${ONES[r]} ratus`);
  if (t === 0) return parts.join(" ");
  if (t === 10) parts.push("sepuluh");
  else if (t === 11) parts.push("sebelas");
  else if (t < 10) parts.push(ONES[t] ?? "");
  else if (t < 20) parts.push(`${ONES[t - 10]} belas`);
  else {
    const pul = Math.floor(t / 10);
    const sat = t % 10;
    parts.push(`${ONES[pul]} puluh${sat ? ` ${ONES[sat]}` : ""}`);
  }
  return parts.join(" ");
}

export function numberToWordsId(n: number): string {
  if (n === 0) return "nol";
  if (n < 0) return `negatif ${numberToWordsId(-n)}`;
  if (n >= 1_000_000) return formatId(n);
  const ribu = Math.floor(n / 1000);
  const sisa = n % 1000;
  const parts: string[] = [];
  if (ribu === 1) parts.push("seribu");
  else if (ribu > 0) parts.push(`${threeToWords(ribu)} ribu`);
  if (sisa > 0) parts.push(threeToWords(sisa));
  return parts.join(" ");
}

export function formatId(n: number): string {
  const sign = n < 0 ? "-" : "";
  return sign + Math.trunc(Math.abs(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function parseIdNumber(raw: string): number | null {
  const t = raw.trim().replace(/\s/g, "").replace(/\./g, "").replace(/_/g, "");
  if (!/^-?\d+$/.test(t)) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function parseFrac(raw: string): { n: number; d: number } | null {
  const t = raw.trim().replace(/\s+/g, " ");
  const mixed = t.match(/^(-?\d+)\s+(\d+)\s*\/\s*(\d+)$/);
  if (mixed) {
    const w = Number(mixed[1]);
    const n = Number(mixed[2]);
    const d = Number(mixed[3]);
    if (!d || !Number.isFinite(w + n + d)) return null;
    const sign = w < 0 ? -1 : 1;
    return { n: sign * (Math.abs(w) * d + n), d };
  }
  const f = t.match(/^(-?\d+)\s*\/\s*(-?\d+)$/);
  if (f) {
    const n = Number(f[1]);
    const d = Number(f[2]);
    if (!d || !Number.isFinite(n + d)) return null;
    return { n, d };
  }
  const whole = parseIdNumber(t);
  if (whole !== null) return { n: whole, d: 1 };
  return null;
}

export function fracEqual(
  a: { n: number; d: number },
  b: { n: number; d: number },
): boolean {
  return a.n * b.d === b.n * a.d;
}

export function formatFrac(n: number, d: number, mixed = false): string {
  const s = simplifyFrac(n, d);
  if (s.d === 1) return String(s.n);
  if (mixed && Math.abs(s.n) > s.d) {
    const w = Math.trunc(s.n / s.d);
    const r = Math.abs(s.n % s.d);
    if (r === 0) return String(w);
    return `${w} ${r}/${s.d}`;
  }
  return `${s.n}/${s.d}`;
}

export function placeLabels(width = 6): { key: string; short: string; long: string; value: number }[] {
  const all = [
    { key: "ratusan-ribu", short: "Ratus rb", long: "Ratusan ribu", value: 100_000 },
    { key: "puluhan-ribu", short: "Puluh rb", long: "Puluhan ribu", value: 10_000 },
    { key: "ribuan", short: "Ribu", long: "Ribuan", value: 1_000 },
    { key: "ratusan", short: "Ratus", long: "Ratusan", value: 100 },
    { key: "puluhan", short: "Puluh", long: "Puluhan", value: 10 },
    { key: "satuan", short: "Satuan", long: "Satuan", value: 1 },
  ];
  return all.slice(6 - width);
}

export function expandedForm(n: number): string {
  const parts: string[] = [];
  const digits = digitsOf(n, 6);
  const labels = placeLabels(6);
  digits.forEach((d, i) => {
    if (d === 0) return;
    parts.push(formatId(d * labels[i]!.value));
  });
  return parts.length ? parts.join(" + ") : "0";
}

export function euclidSteps(a: number, b: number): { a: number; b: number; q: number; r: number }[] {
  let x = Math.abs(Math.trunc(a));
  let y = Math.abs(Math.trunc(b));
  const steps: { a: number; b: number; q: number; r: number }[] = [];
  while (y !== 0) {
    const q = Math.floor(x / y);
    const r = x % y;
    steps.push({ a: x, b: y, q, r });
    x = y;
    y = r;
  }
  return steps;
}
