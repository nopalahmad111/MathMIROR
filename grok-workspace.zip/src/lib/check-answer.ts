import { fracEqual, parseFrac, parseIdNumber, simplifyFrac } from "@/lib/math";

function normalizeText(s: string): string {
  return s
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[.]/g, "")
    .replace(/[–—]/g, "-");
}

export function answersMatch(
  expected: string,
  given: string,
  equivalentOk = false,
): boolean {
  const e = expected.trim();
  const g = given.trim();
  if (!g) return false;
  if (normalizeText(e) === normalizeText(g)) return true;

  const ne = parseIdNumber(e);
  const ng = parseIdNumber(g);
  if (ne !== null && ng !== null && !e.includes("/") && !g.includes("/")) {
    return ne === ng;
  }

  const fe = parseFrac(e);
  const fg = parseFrac(g);
  if (fe && fg) {
    if (equivalentOk) return fracEqual(fe, fg);
    const se = simplifyFrac(fe.n, fe.d);
    return fg.n === se.n && fg.d === se.d;
  }
  return false;
}
