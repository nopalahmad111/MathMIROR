export type JalurId = "bilangan" | "fpb-kpk" | "pecahan";

export type PracticeItem = {
  id: string;
  prompt: string;
  kind: "mc" | "input";
  options?: string[];
  answer: string;
  hint: string;
  why: string;
  equivalentOk?: boolean;
  placeholder?: string;
};

export type ExploreConfig =
  | { lab: "place-value"; mode: "build" | "compare" | "operate"; start?: number; other?: number; op?: "+" | "-" }
  | { lab: "round"; start: number }
  | { lab: "factor"; mode: "rectangles" | "prime" | "tree"; start: number }
  | { lab: "gcd-lcm"; mode: "gcd" | "lcm" | "choose"; a: number; b: number; story?: string }
  | {
      lab: "fraction";
      mode: "shade" | "equiv" | "compare" | "add" | "life";
      a?: [number, number];
      b?: [number, number];
    };

export type Lesson = {
  id: string;
  jalurId: JalurId;
  order: number;
  title: string;
  intent: string;
  mindful: {
    notice: string;
    prompt: string;
    chips: string[];
  };
  story: {
    title: string;
    body: string[];
    ask: string;
  };
  explore: ExploreConfig & { caption: string };
  practice: PracticeItem[];
  reflect: {
    prompts: string[];
    takeaway: string;
  };
};

export type Jalur = {
  id: JalurId;
  title: string;
  subtitle: string;
  blurb: string;
  why: string;
  pillar: string;
};
