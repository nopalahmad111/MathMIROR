import { BILANGAN_LESSONS } from "./bilangan";
import { FPB_LESSONS } from "./fpb-kpk";
import { PECAHAN_LESSONS } from "./pecahan";
import type { Jalur, JalurId, Lesson } from "./types";

export type { Jalur, JalurId, Lesson, PracticeItem, ExploreConfig } from "./types";

export const JALUR: Jalur[] = [
  {
    id: "bilangan",
    title: "Bilangan cacah",
    subtitle: "Hingga ratusan ribu",
    blurb: "Membaca wajah angka, membandingkan dari kiri, dan memakai operasi sebagai penukaran sepuluh — bukan hafalan langkah.",
    why: "Supaya 305.042 bukan deret digit, melainkan tiga ratus lima ribu yang bisa ditaksir, dijumlah, dan diceritakan.",
    pillar: "Nilai tempat adalah rumah makna.",
  },
  {
    id: "fpb-kpk",
    title: "FPB dan KPK",
    subtitle: "Berbagi dan bertemu",
    blurb: "Faktor menyusun, prima adalah bahan baku, FPB berbagi paling besar, KPK adalah loncatan yang berpapasan.",
    why: "Supaya kamu tidak tertukar rumus: soal berbagi memakai FPB, soal pertemuan memakai KPK.",
    pillar: "Pilih alat setelah paham pertanyaan.",
  },
  {
    id: "pecahan",
    title: "Bilangan pecahan",
    subtitle: "Bagian dari utuh",
    blurb: "Pecahan adalah hubungan. Senilai, banding, jumlah — semuanya soal menyamakan bahasa potongan.",
    why: "Supaya 1/2 + 1/3 tidak pernah lagi menjadi 2/5, dan seperempat jam punya satuan.",
    pillar: "Tanpa utuh yang jelas, pecahan menggantung.",
  },
];

export const ALL_LESSONS: Lesson[] = [
  ...BILANGAN_LESSONS,
  ...FPB_LESSONS,
  ...PECAHAN_LESSONS,
];

export function lessonsFor(jalurId: JalurId): Lesson[] {
  return ALL_LESSONS.filter((l) => l.jalurId === jalurId).sort((a, b) => a.order - b.order);
}

export function getLesson(id: string): Lesson | undefined {
  return ALL_LESSONS.find((l) => l.id === id);
}

export function getJalur(id: string): Jalur | undefined {
  return JALUR.find((j) => j.id === id);
}

export function nextLesson(id: string): Lesson | undefined {
  const current = getLesson(id);
  if (!current) return undefined;
  return lessonsFor(current.jalurId).find((l) => l.order === current.order + 1);
}

export const NIAT_CHIPS = [
  "Hari ini aku ingin paham, bukan cepat selesai",
  "Aku akan memperhatikan hal kecil",
  "Aku boleh salah dulu, lalu memperbaiki",
  "Aku akan menghubungkan pelajaran dengan hidupku",
];

export const PILLARS = [
  {
    id: "mindful",
    title: "Berkesadaran",
    body: "Berhenti sejenak. Perhatikan apa yang kamu lihat, bukan yang biasa kamu lakukan. Bahasa bersyarat: 'bisa jadi', 'tergantung'.",
  },
  {
    id: "meaningful",
    title: "Bermakna",
    body: "Setiap ide menempel pada cerita: pasar, masjid, resep, barisan. Pengetahuan baru mengait pada yang sudah kamu tahu.",
  },
  {
    id: "deep",
    title: "Mendalam",
    body: "Bukan menghafal langkah. Menggali mengapa, memakai beberapa gambar, dan memindahkan ide ke soal yang belum pernah dilihat.",
  },
] as const;
